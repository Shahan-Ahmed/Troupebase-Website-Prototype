<script>
window.location = "https://troupebase.com";
</script>
<?php
class Dbh{
private $host = "localhost:3306";
private $user = "tbAdmin";
private $pwd = "tbAdmin7895#";
private $dbName = "troupebase";
	
protected function connect(){
$dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbName;
$pdo = new PDO($dsn, $this->user, $this->pwd);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$pdo->setAttribute( PDO::ATTR_EMULATE_PREPARES, false );
return $pdo;
$pdo = null;
}
}
?>
<?php
require_once("../classes/dbh.class.php");

class Location extends Dbh{
	
	

	
	public function getLocations($value){
	
	$sql = "SELECT * FROM cities WHERE (name LIKE ?) OR (StateName LIKE ?) OR (countryName = ?) LIMIT 60";
	$stmt = $this->connect()->prepare($sql);
	$needle = '%'.$value;
	if($stmt->execute([$needle, $needle, $needle])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
<?php
require_once("dbh.class.php");
require_once("user.class.php");




class Message extends Dbh{

	
	
	//UPDATE LAST MESSAGE DATE
	public function updateLastMessageDate($id, $unix){
		$sql = "UPDATE activeChats SET lastMessage = ? WHERE chatID = ?";
		$stmt = $this->connect()->prepare($sql);
		
		$stmt->execute([$unix, $id]);
		
		
	}
	
	
	
	
	
	
	
	
	//GET LATEST MESSAGES
	public function getlatestmessages($id, $lastMessageDate){
	
	$sql = "SELECT * FROM messages WHERE chatID = ? AND dateTime > ? ORDER BY dateTime";
	$stmt = $this->connect()->prepare($sql);
		
		if($stmt->execute([$id, $lastMessageDate])){
		$result = $stmt->fetchAll();
		return $result;
		}else{
		return "error";
		}
		
		
		
	}

	
	
	
	
	
	
		//SEND ATTACHMENT
	public function sendAttachment($uniqueID, $userLoggedIn, $id, $message, $dateTime, $file, $smallImageDestination, $type){
	
		if($smallImageDestination == "null" || $smallImageDestination == "undefined"){
		$smallImageDestination == "null";
		}
		
	$sql = "INSERT INTO messages (id, body, dateTime, chatID, userFrom, file, filePreview, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
		
		if($stmt->execute([$uniqueID, $message, $dateTime, $id, $userLoggedIn, $file, $smallImageDestination, $type])){
			
			return "success";
			
		}else{
		return "error";
		}
		
	}
	
		

	
	
	
	
	
	
	
	
	//SEND
	public function send($uniqueID, $userLoggedIn, $id, $message, $dateTime){
	
	$sql = "INSERT INTO messages (id, body, dateTime, chatID, userFrom, file, filePreview) VALUES (?, ?, ?, ?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
		
		if($stmt->execute([$uniqueID, $message, $dateTime, $id, $userLoggedIn, "null", "null"])){
			
			return "success";
			
		}else{
		return "error";
		}
		
	}
	
	
	
	
	
	
	
	
	
	//GET CONVO
	public function getConvo($userLoggedIn, $start, $id){
	$sql = "SELECT * FROM messages WHERE chatID = ? ORDER BY dateTime DESC LIMIT ?, 20";
	$stmt = $this->connect()->prepare($sql);
		
		if($stmt->execute([$id, $start])){
		$result = $stmt->fetchAll();
		return $result;
		}else{
		return "error";
		}
		
	}
	
	
	
	
	//ADD MESSAGE
	public function addMessage($userLoggedIn, $uniqueID, $message, $dateTime){
		$sql = "INSERT INTO messages (id, body, dateTime, chatID, userFrom, file, filePreview) VALUES (?, ?, ?, ?, ?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		
		if($stmt->execute([$uniqueID, $message, $dateTime, $uniqueID, $userLoggedIn, "null", "null"])){
		return "success";
		}else{
		return "error";
		}
		
	}


	
	//SEND NEW MESSAGE
	public function insertNewMessage($userLoggedIn, $id, $uniqueID, $dateTime)
	{
	
		
	$sql = "INSERT INTO activeChats (userA, userB, dateTime, chatID, deleted) VALUES (?, ?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);

	
		
	if($stmt->execute([$userLoggedIn, $id, $dateTime, $uniqueID, ","])){
	return "success";
	}else{
	return "error";
	}


		
	}
	
	
	
	
	
	
	
	
	
	//CHECK IF ALREADY CHATTING
	public function checkIfAlreadyChatting($userLoggedIn, $id)
	{
		
			$sql = "SELECT chatID FROM activeChats WHERE (userA = ? AND userB = ?) OR (userA = ? AND userB = ?) AND deleted NOT LIKE ?";
			$needle = '%,'.$userLoggedIn.',%';
			$stmt = $this->connect()->prepare($sql);
			$stmt->execute([$userLoggedIn, $id, $id, $userLoggedIn, $needle]);
		
			$result = $stmt->fetchAll();
		
			return $result;
		
	}
	
	
	
	
	
	
	
	//LEAVE CONVO
	public function leaveConvo($currentConvo)
	{
			
		$sql = "UPDATE activeMessages SET deleted = CONCAT(deleted, ?) WHERE id = ? AND (userA = ? OR userB = ?)";
		$needleOne = $this->userLoggedIn.',';
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$needleOne, $currentConvo, $this->userLoggedIn, $this->userLoggedIn]);
	
	}
	//leave convo
	
	
	
	
	
	
	
	
	//UPDATE CONVO
	public function updateConvo($convoID, $start)
	{
	
		$sql = "SELECT * FROM messages WHERE messageID = ? ORDER BY dateTime DESC LIMIT ?, 15";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$convoID, $start]);
		
		$result = $stmt->fetchAll();
		
		return $result;
	
	}
	//update convo
	
	
	
	
	
	//GET ACTIVE
	public function getActiveChats($userLoggedIn, $start)
	{
		
		

		$sql = "SELECT * FROM activeChats WHERE (userA = ? OR userB = ?) AND deleted NOT LIKE ? ORDER BY lastMessage DESC LIMIT ?, 15";
		$needle = ','.$this->userLoggedIn.',';
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $userLoggedIn, $needle, $start])){
		
		$result = $stmt->fetchAll();
		return $result;
			
			
		}else{
		return "error";
		}
		
		

	
	}

	
	
	
	
		public function getLastMessage($id)//GET LAST
		{
		
			$sql = "SELECT body FROM messages WHERE chatID = ? ORDER BY dateTime DESC LIMIT 1";
			$stmt = $this->connect()->prepare($sql);
			$stmt->execute([$id]);
			
			$lastMessage = $stmt->fetchAll();
			
			foreach($lastMessage as $last)
			{
			
				$last = $last['body'];
				
			}
			
			return $last;
		
		}//get last message
	
	
	
	
	
	
		//LOAD CONVO
		public function loadConvo($id)
		{
			
			

			$sql = "SELECT * FROM messages WHERE messageID = ? ORDER BY dateTime DESC LIMIT ?, 20";
			$stmt = $this->connect()->prepare($sql);
			$stmt->execute([$id, $this->start]);
			
			$convos = $stmt->fetchAll();
			
			return $convos;
			
		}
		//load convo
	
	
	
	
	public function activeMessagesSetViewed($id)
	{
	
		$sql = "UPDATE activeMessages SET viewed = REPLACE(viewed, ?, ?) WHERE id = ? AND (userA = ? OR userB = ?)";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = ','.$this->userLoggedIn.'.no,';
		$needleTwo = ','.$this->userLoggedIn.'.yes,';
		$stmt->execute([$needleOne, $needleTwo, $id, $this->userLoggedIn, $this->userLoggedIn]);
		
		
		
	}
	
	
	public function updateConvoViews($id)
	{
	
		$sql = "UPDATE messages SET viewed = 1 WHERE messageID = ? AND userFrom != ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$id, $this->userLoggedIn]);
		
		
		
	}
	
	
	

}

















<?php
require_once("dbh.class.php");

class Notification extends Dbh{

	
	
	
	
	
	
	
	
		//IGNORE POST COMMENT
	public function deleteNotification($noteID, $userFrom){
		$sql = "DELETE FROM notifications WHERE id = ? AND userFrom = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$noteID, $userFrom])){
		
			return "success";
		
		}else{
		return "error";
		}
	}
	
	
	
	
	//DELETE CAPTION TAG
	public function deleteCaptionTag($userLoggedIn, $username, $userFrom, $postDate, $postID){
	$sql = "UPDATE posts SET taggedString = REPLACE(taggedString, ?, ?) WHERE id = ? AND user = ?";
	$stmt = $this->connect()->prepare($sql);
		
		$stringToReplace = ','.$username.',';
		$replaceWith = ',';
		if($stmt->execute([$stringToReplace, $replaceWith, $postID, $userFrom])){
			
		return "success";
			
			
		}else{
		return "error";
		}
	}
	
	
	
	//IGNORE POST COMMENT
	public function ignorePostComment($userFrom, $postDate, $postID){
		$sql = "DELETE FROM postComments WHERE user = ? AND dateTime = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userFrom, $postDate])){
		
			return "success";
		
		}else{
		return "error";
		}
	}
	
	

	//DENY NOTIFICATION
	public function denyNotification($userLoggedIn, $notificationID){
	$sql = "UPDATE notifications SET deleted = ? WHERE id = ? AND userTo = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([1, $notificationID, $userLoggedIn])){
		
			return "success";
			
		}else{
		return "error";
		}
	}
	
	
	
	//REPORT NOTIFICATIONS
	public function reportNotification($userLoggedIn, $notificationID){
	$sql = "UPDATE notifications SET deleted = ?, reported = ? WHERE id = ? AND userTo = ?";
	$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([1, 1, $notificationID, $userLoggedIn])){
			
				return "success";
		
		}else{
				return "error";
		}
	}
	
	
	
	
	
	
	
	
	//INSERT COMMENT REPLY NOTIFICATION
	public function insertCommentReply($commentID, $postID, $user, $body, $userLoggedIn, $date){
	

		$sql = "INSERT INTO notifications (userFrom, userTo, postID, dateTime, type, comment, postType, commentID) VALUES (?,?,?,?,?,?,?,?)";
		$stmt = $this->connect()->prepare($sql);
		$type = 'commentReply';
		$postType = "null";
		$stmt->execute([$userLoggedIn, $user, $postID, $date, $type, $body, $postType, $commentID]);
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	//ADD TO COLLAB LIST
	public function addToCollabList($userLoggedIn, $postID)
	{
		$date = time();
		
		$sql = "INSERT INTO collabs (user, postID, dateTime) VALUES (?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $postID, $date])){
			
				return "success";
		
		}else{
				return "error";
		}
		
	}
	
	
	
	
	
	
	//checkAlreadyAddedToCollabs
	public function checkAlreadyAddedToCollabs($userLoggedIn, $postID){
	
		
		$sql = "SELECT user FROM collabs WHERE user = ? AND postID = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $postID])){
		$result = $stmt->fetchAll();
		return count($result);
		}else{
		return "error";
		}
		
	}
	
	
	
	
	
	
	
	
//SET ACCEPTED TO ONE
public function setAcceptedToOne($notificationID){

	$sql = "UPDATE notifications SET accepted = ? WHERE id = ?";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([1, $notificationID])){
			
		return "success";
		
	}else{
	return "error";
	}
	
	
	

}
	
	
	

	
	
//CHECK FOR UNREAD NOTIFICATIONS
	
	
	
	
	
	
//GET NOTIFICAIONS
public function getNotifications($userLoggedIn, $username, $start){
	
	$sql = "SELECT * FROM notifications WHERE (userTo = ? OR userTo = ?) AND userFrom != ? AND deleted = ? AND reported = ? ORDER BY dateTime DESC LIMIT ?, 20";
	$stmt = $this->connect()->prepare($sql);
	
		if($stmt->execute([$userLoggedIn, $username, $userLoggedIn, 0, 0, $start])){
			
		$result = $stmt->fetchAll();
		return $result;
			
		}else{
		return "error";
		}
}
	
	
	
	
//RETURN NOTIFICATION
public function returnNotification($noteID){
	
$sql = "SELECT * FROM notifications WHERE id = ?";
$stmt = $this->connect()->prepare($sql);
	
		if($stmt->execute([$noteID])){
			
			$result = $stmt->fetch();
		return $result;
			
		}else{
		return "error";
		}
	
	
}
	
	
	
	
	
}
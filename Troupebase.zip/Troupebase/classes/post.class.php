<?php
require_once("../classes/dbh.class.php");

class Post extends Dbh{
	
	
	
	
//IGNORE PROJECT RESPONSE
public function ignoreProjResp($id, $projectID){
$sql = "DELETE FROM applicants WHERE id = ? AND projectID = ?";
$stmt = $this->connect()->prepare($sql);	
if($stmt->execute([$id, $projectID])){
	
return "success";
	
}else{
return "error";
}		
}
	
	
	
	
	
	
	
	
	
	//GET PROJECT RESPONSES
public function getProjectResponses($start, $id){
$sql = "SELECT * FROM applicants WHERE projectID = ? ORDER BY dateTime DESC LIMIT ?, 20";
$stmt = $this->connect()->prepare($sql);		
if($stmt->execute([$id, $start])){
	
	$result = $stmt->fetchAll();
			return $result;
	
	}
	
	
}
	
	
	
	
	
	
	
	//GET USERS MEDIA POST ONLY
public function getUserMediaPostsOnly($userLoggedIn, $user, $start){	
	
	$sql = "SELECT id, user, file, coverPhoto, type, filter, details, dateTime, smallimage, requiredTalent, city, state, country FROM posts WHERE user = ? AND reports < 3 AND type != ? AND deleted = 0 AND complete = 1 AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		$stmt = $this->connect()->prepare($sql);
		$typeDoesNotEqual = "pg";
		$needleOne = "%,".$userLoggedIn.",%";
		if($stmt->execute([$user, $typeDoesNotEqual, $needleOne, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
	
	
}
	
	
	
	
	
	
	
	
	
//GET PROJECTS BY TALENT AND LOCATION
public function getProjectsByTalAndLoc($start, $userLoggedIn, $city, $state, $country, $talent){

$reportStringNeedle = "%,".$userLoggedIn.",%";
$requiredTalent = "%,".$talent.",%";
$typePG = "pg";
$deleted = 0;
$sql = "SELECT * FROM posts WHERE type = ? AND requiredTalent LIKE ? AND city = ? AND state = ? AND country = ? AND deleted = ? AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
$stmt = $this->connect()->prepare($sql);		
if($stmt->execute([$typePG, $requiredTalent, $city, $state, $country, $deleted, $reportStringNeedle, $start])){
	

$result = $stmt->fetchAll();
return $result;
	
	
}else{
return "error";
}	
	
	
}		
	
	
	
	
	
	
	
	
	
	
//GET PROJECTS BY COUNTRY
public function getProjectsByTalent($start, $userLoggedIn, $city, $state, $country, $talent){

$reportStringNeedle = "%,".$userLoggedIn.",%";
$requiredTalent = "%,".$talent.",%";
$typePG = "pg";
$deleted = 0;
$sql = "SELECT * FROM posts WHERE type = ? AND requiredTalent LIKE ? AND deleted = ? AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
$stmt = $this->connect()->prepare($sql);		
if($stmt->execute([$typePG, $requiredTalent, $deleted, $reportStringNeedle, $start])){
	

$result = $stmt->fetchAll();
return $result;
	
	
}else{
return "error";
}	
	
	
}		
	
	
	
	
	
//GET PROJECTS BY COUNTRY
public function getProjectsByLocation($start, $userLoggedIn, $city, $state, $country){

	
$reportStringNeedle = "%,".$userLoggedIn.",%";
$typePG = "pg";
$deleted = 0;
$sql = "SELECT * FROM posts WHERE type = ? AND city = ? AND state = ? AND country = ? AND deleted = ? AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
$stmt = $this->connect()->prepare($sql);		
if($stmt->execute([$typePG, $city, $state, $country, $deleted, $reportStringNeedle, $start])){
	

$result = $stmt->fetchAll();
return $result;
	
	
}else{
return "error";
}	
	
	
}	
	
	
	
	
	
	
	

	
	
	
	
	

	
//GET ALL PROJECTS DATE ORDER	
public function getProjectGoalsAll($userLoggedIn, $start){	
$reportStringNeedle = "%,".$userLoggedIn.",%";
$typePG = "pg";
$deleted = 0;
$sql = "SELECT * FROM posts WHERE type = ? AND deleted = ? AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
$stmt = $this->connect()->prepare($sql);		
if($stmt->execute([$typePG, $deleted, $reportStringNeedle, $start])){
	

$result = $stmt->fetchAll();
return $result;
	
	
}else{
return "error";
}
}
	

	
	
	
	
//GET PROJECT GOAL	
public function getAProjectGoal($userLoggedIn, $id){		

$sql = "SELECT * FROM posts WHERE id = ?";
$stmt = $this->connect()->prepare($sql);		
if($stmt->execute([$id])){
	

$result = $stmt->fetch();
return $result;
	
	
}else{
return "error";
}
}	
	
	
	
	
//GET POSTS DISCOVER FILTERED
	
public function getPostsForDisTalentLocation($start, $userLoggedIn, $city, $state, $country, $talent){
$sql = "SELECT id, user, file, coverPhoto, type, filter, smallimage FROM posts WHERE reports < 3 AND deleted = 0 AND complete = 1 AND (type = 'a' OR type = 'p' OR type='v') AND (city = ? AND state = ? AND country = ?) AND usersTalents LIKE ? AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		
$stmt = $this->connect()->prepare($sql);
$needleOne = "%,".$userLoggedIn.",%";
$needleTwo = "%".$talent.",%";
if($stmt->execute([$city, $state, $country, $needleTwo, $needleOne, $start])){
		
$result = $stmt->fetchAll();
return $result;
			
}else{
return "error";
}	
}
	
	
			
		
public function getPostsForDiscoverByTalent($start, $userLoggedIn, $talent){
$sql = "SELECT id, user, file, coverPhoto, type, filter, smallimage FROM posts WHERE reports < 3 AND deleted = 0 AND complete = 1 AND (type = 'a' OR type = 'p' OR type='v') AND usersTalents LIKE ? AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		
$stmt = $this->connect()->prepare($sql);
$needleOne = "%".$talent.",%";
$needleTwo = "%,".$userLoggedIn.",%";
if($stmt->execute([$needleOne, $needleTwo, $start])){
		
$result = $stmt->fetchAll();
return $result;
			
}else{
return "error";
}	
}		
		
		
		
public function getPostsForDiscoverByLocation($start, $userLoggedIn, $city, $state, $country){
$sql = "SELECT id, user, file, coverPhoto, type, filter, smallimage FROM posts WHERE reports < 3 AND deleted = 0 AND complete = 1 AND (type = 'a' OR type = 'p' OR type='v') AND (city = ? AND state = ? AND country = ?) AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		
$stmt = $this->connect()->prepare($sql);
$needleOne = "%,".$userLoggedIn.",%";
if($stmt->execute([$city, $state, $country, $needleOne, $start])){
		
$result = $stmt->fetchAll();
return $result;
			
}else{
return "error";
}	
}
	
	
	
	
	
	
	
//GET POST FOR DISCOVER
public function getPostsForDiscover($start, $userLoggedIn){
$sql = "SELECT id, user, file, coverPhoto, type, filter, smallimage FROM posts WHERE reports < 3 AND deleted = 0 AND complete = 1 AND (type = 'a' OR type = 'p' OR type='v') AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		
$stmt = $this->connect()->prepare($sql);
$needleOne = "%,".$userLoggedIn.",%";
if($stmt->execute([$needleOne, $start])){
		
$result = $stmt->fetchAll();
return $result;
			
}else{
return "error";
}
}
	
	
	
	
	
	
	
	//GET ALL PROJECTS LAST APPLIED ORDER	
public function getProjectGoalsByLastApplied($user, $userLoggedIn, $start){	
		$sql = "SELECT * FROM posts WHERE user = ? AND type = ? AND reports < 3 AND deleted = 0 AND complete = 1 AND reportString NOT LIKE ? ORDER BY lastApplied DESC LIMIT ?, 20";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = "%,".$userLoggedIn.",%";
		if($stmt->execute([$user, "pg", $needleOne, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
}
		
	
	
	
	
	
	
	
	
	
	//GET PROJECT GOAL POSTS
	public function getProjectGoals($user, $userLoggedIn, $start)
	{
	
		$sql = "SELECT * FROM posts WHERE user = ? AND type = ? AND reports < 3 AND deleted = 0 AND complete = 1 AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = "%,".$userLoggedIn.",%";
		if($stmt->execute([$user, "pg", $needleOne, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
	}
	
	
	
	
	
	
	//CHECK IF ALREADY SHARED
	public function checkAlreadyShared($userLoggedIn, $user, $projectID)
	{
	
		$sql = "SELECT * FROM sharedPosts WHERE userFrom = ? AND userTo = ? AND postID = ? LIMIT 1";
		$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $projectID])){
	
		$result = $stmt->fetchAll();
			return count($result);
		
	}
		
	}
	
	
	
	
	
	
	
			//SHARE PROJECT
	public function shareTheProject($userLoggedIn, $user, $projectID, $date)
	{

	$sql = "INSERT INTO sharedPosts (userFrom, userTo, postID, dateTime) VALUES (?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $projectID, $date])){
	
		return "success";
		
	}else{
	return "error";
	}

	}
	
	
	
	
	
	
	
	
	
	
	
	//REPORT POS
public function reportpost($id, $userLoggedIn){
$sql = "UPDATE posts SET reports = reports + 1, reportString = CONCAT(reportString, ?) WHERE id = ?";
$stmt = $this->connect()->prepare($sql);
	
$string = $userLoggedIn.',';
	
if($stmt->execute([$string, $id])){		
return "success";		
}else{
return "error";
}
	
}
	
	
	
	
	
	//DELETE POST
	public function deletepost($id, $userLoggedIn){
	$sql = "UPDATE posts SET deleted = ? WHERE id = ? AND user = ?";
	$stmt = $this->connect()->prepare($sql);	
	if($stmt->execute([1, $id, $userLoggedIn])){
			
		return "success";
			
	}else{
		return "error";
	}
	}
	
	
	
	
	
	//DELETE COMMENT REPLY
	public function deleteCommentReply($userLoggedIn, $dateTime){
	$sql = "UPDATE postComments SET deleted = ? WHERE user= ? AND dateTime = ?";
	$stmt = $this->connect()->prepare($sql);	
	if($stmt->execute([1, $userLoggedIn, $dateTime])){
			
		return "success";
			
	}else{
		return "error";
	}
	
	}
	
	
	
	
	//GET COMMENT REPLIES
	public function getCommentReplies($userLoggedIn, $commentID, $postID, $start){

		
		$sql = "SELECT * FROM postComments WHERE replyTo = ? AND fromPost = ? AND reports < ? AND reportString NOT LIKE ? AND deleted = ? ORDER BY dateTime DESC LIMIT ?, 10";
		$stmt = $this->connect()->prepare($sql);
		$n1 = 3;
		$n2 = ','.$userLoggedIn.',';
		if($stmt->execute([$commentID, $postID, $n1, $n2, 0, $start])){
			
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	//POST COMMENT REPLY
	public function postCommentReply($userLoggedIn, $commentID, $postID, $body, $date){
	
		$sql = "INSERT INTO postComments (user, dateTime, details, reportString, replyTo, fromPost) VALUES (?,?,?,?,?,?)";
		$stmt = $this->connect()->prepare($sql);
		$n1 = ','; 
		if($stmt->execute([$userLoggedIn, $date, $body, $n1, $commentID, $postID])){
		
			return "success";
		
		}else{
			return "error";
		}
	}
	
	
	
	
	
	//GET TOTAL COLLABORATIONS
	public function getTotalCollaborations($postID){
		
		$sql = "SELECT id FROM collabs WHERE postID = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$postID]);
			
		$result = $stmt->fetchAll();
		return $result;
	}
	
	
	
	//GET COLLABORATIONS
	public function getCollaborations($postID, $start, $limit){
		
		$sql = "SELECT user FROM collabs WHERE postID = ? ORDER BY dateTime DESC LIMIT ?, ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$postID, $start, $limit]);
			
		$result = $stmt->fetchAll();
		return $result;
	}
	
	
	
	
	//GET POST PREVIEW PHOTO
		public function getPreviewPhoto($id){
	
		$sql = "SELECT smallimage, coverPhoto, dateTime, type FROM posts WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$id]);	
		
		$result = $stmt->fetch();
			
			return $result;
	}
	
	
	
	//REPORT COMMENT
	public function reportComment($userLoggedIn, $commentID){
	
		$sql = "UPDATE postComments SET reportString = CONCAT(reportString, ?), reports = reports + ? WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$needle = $userLoggedIn.',';
		$stmt->execute([$needle, 1, $commentID]);
		
	}
	
	
	
	//DELETE COMMENT
	public function deleteComment($userLoggedIn, $commentID){
	
		$sql = "UPDATE postComments SET deleted = ? WHERE user = ? AND id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([1, $userLoggedIn, $commentID]);
		
	}
	
	
	
	//GET THE COMMENT
	public function getTheComment($commentID){
	$sql = "SELECT * FROM postComments WHERE id = ? LIMIT 1";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$commentID])){
	$result = $stmt->fetch();
			return $result;
	
	}else{
	return "error";
	}
	}
	
	
	
	
	
	
	//GET COMMENTS
	public function getComments($userLoggedIn, $postID, $start){
	
		
		$sql = "SELECT * FROM postComments WHERE postID = ? AND reports < ? AND reportString NOT LIKE ? AND deleted = ? ORDER BY dateTime DESC LIMIT ?, 10";
		$stmt = $this->connect()->prepare($sql);
		$n1 = 3;
		$n2 = ','.$userLoggedIn.',';
		if($stmt->execute([$postID, $n1, $n2, 0, $start])){
			
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
	
	}
	
	
	
	
	
	
	
	
	
	//ADD COMMENT @ NOTICE
	public function insertAtNotice($userFrom, $userTo, $postID, $date, $type, $comment, $postType){
	
		$date = time();
		$sql = "INSERT INTO notifications (userFrom, userTo, postID, dateTime, type, comment, postType) VALUES (?,?,?,?,?,?,?)";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userFrom, $userTo, $postID, $date, $type, $comment, $postType]);
		
		
	}
	
	
	
	
	
	//INSERT COMMENT NOTE
	public function insertCommentNote($userFrom, $userTo, $postID, $date, $type, $comment, $postType)
	{
		$sql = "INSERT INTO notifications (userFrom, userTo, postID, dateTime, type, comment, postType) VALUES (?,?,?,?,?,?,?)";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userFrom, $userTo, $postID, $date, $type, $comment, $postType]);
		
	}
	
	
	
	
	
	//ADD COMMENT
	public function addComment($postID, $postComment, $userLoggedIn, $postCommentTagString, $date)
	{
		
		$sql = "INSERT INTO postComments (user, postID, dateTime, details, reportString, tagged) VALUES (?, ?, ?, ?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		$needle = ',';
		if($stmt->execute([$userLoggedIn, $postID, $date, $postComment, $needle, $postCommentTagString])){
			
			return "success";
			
		}else{
		return "error";
		}
	}
	
	
	
	
	
	
	
	//GET USERS WHO LIKED THE POST
	public function getlikedusers($postID, $start)
	{
	
		$sql = "SELECT id, user, dateTime FROM likes WHERE postID = ? ORDER BY dateTime DESC LIMIT ?, 14";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$postID, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
	}
	
	//CHECK LIKE
	public function checklike($userLoggedIn, $postID)
	{
		
		$sql = "SELECT id FROM likes WHERE user = ? AND postID = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn, $postID]);
		
		$result = $stmt->fetch();
			
			return $result;
		
	}
	
	
	
	//LIKE
	public function like($userLoggedIn, $postID)
	{
		$date = time();
		$sql = "INSERT INTO likes (user, postID, dateTime) VALUES (?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $postID, $date])){
		
		$sql = "UPDATE posts SET stars = stars + 1 WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$postID]);
			
		}
		
	}
	//unlike
	public function unlike($userLoggedIn, $postID)
	{
		$sql = "DELETE FROM likes WHERE (user = ? AND postID = ?)";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $postID])){
		
			$sql = "UPDATE posts SET stars = stars - 1 WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$postID]);
			
		}
		
	}
	
	//GET A POST
	public function getPost($postID, $userLoggedIn)
	{
	
		$sql = "SELECT * FROM posts WHERE id = ? AND reportString NOT LIKE ?";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = "%,".$userLoggedIn.",%";
		if($stmt->execute([$postID, $needleOne])){
			
		$result = $stmt->fetch();
			
			return $result;
		
		}else{
		return "error";
		}
		
		
	}
	
	
	
	//GET POSTS
	public function getPosts($user, $userLoggedIn, $start)
	{
	
		$sql = "SELECT * FROM posts WHERE user = ? AND reports < 3 AND deleted = 0 AND complete = 1 AND reportString NOT LIKE ? ORDER BY dateTime DESC LIMIT ?, 20";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = "%,".$userLoggedIn.",%";
		if($stmt->execute([$user, $needleOne, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
	}
	
	

	
	
	
	//INSERT POST
	public function insertPost($uniqueID, $userLoggedIn, $fileDB, $caption, $type, $filter, $coverPhoto, $videoFit, $taggedString, $optionalPostLink, $smallImageDestination, $city, $state, $country, $userTalents)
	{
		
		$dateTime = time();
		
		$sql = "INSERT INTO posts (id, user, file, details, type, dateTime, filter, complete, coverPhoto, reportString, videoFit, taggedString, link, smallimage, city, state, country, usersTalents) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		$reportString = ",";
		$complete = 1;
		if($stmt->execute([$uniqueID, $userLoggedIn, $fileDB, $caption, $type, $dateTime, $filter, $complete, $coverPhoto, $reportString, $videoFit, $taggedString, $optionalPostLink, $smallImageDestination, $city, $state, $country, $userTalents])){		
			
		
		return "success";
			
		}else{
		return "error";
		}
	
		
}
	
	
	
	
	
	
	//INSERT CAPTION TAGS
public function insertCaptionTags($userLoggedIn, $postID, $type, $taggedString)
{		
$tags = explode(',', $taggedString);
foreach($tags as $tag){			
$userTo = $tag;
$dateTime = time();
if($userTo !== ""){
$sql = "INSERT INTO notifications (userFrom, userTo, postID, dateTime, type) VALUES (?, ?, ?, ?, ?)";
$stmt = $this->connect()->prepare($sql);
$stmt->execute([$userLoggedIn, $userTo, $postID, $dateTime, $type]);
}
}
}
	
	
	
	
	
	
	
	
	//INSERT WORKED WITH TAGS
	public function insertWorkedWithNotification($userLoggedIn, $postID, $type, $workedWithString)
	{
		$tags = explode(',', $workedWithString);
		foreach($tags as $tag){
			
		$userTo = $tag;
		$dateTime = time();
			
			if($userTo !== ""){
				
				$sql = "INSERT INTO notifications (userFrom, userTo, postID, dateTime, type) VALUES (?,?,?,?,?)";
				$stmt = $this->connect()->prepare($sql);
				$stmt->execute([$userLoggedIn, $userTo, $postID, $dateTime, $type]);
				
			}
			
			
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	
}
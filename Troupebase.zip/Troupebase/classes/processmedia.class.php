<?php

//RESIZE FUNCTION
function resize_image($file, $max_resolution, $ext){
if($ext == "jpg" || $ext == "jpeg"){
$original_image = imagecreatefromjpeg($file);
}
if($ext == "png"){
$original_image = imagecreatefrompng($file);
}

//RESOLUTION
$original_width = imagesx($original_image);
$original_height = imagesy($original_image);

if($original_width > 600 || $original_height > 600){
//TRY WIDTH FIRST
$ratio = $max_resolution / $original_width;
$new_width = $max_resolution;
$new_height = $original_height * $ratio;
	
	
//if that didnt work
if($new_height > $max_resolution){
$ratio = $max_resolution / $original_height;
$new_height = $max_resolution;
$new_width = $original_width * $ratio;
}
	
	
if($original_image){
	
$new_image = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($new_image, $original_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
imagejpeg($new_image, $file, 90);	
	
}	
}
}









////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


















//CREATE TINY IMAGE FUNCTION
function createSmallImage($file, $smallImageDestination, $smallImageDestinationDB, $max_resolution, $coverExt, $userLoggedIn, $date){
	
$original_image = imagecreatefromjpeg($file);
if($ext == "jpg" || $ext == "jpeg"){
$original_image = imagecreatefromjpeg($file);
}
if($ext == "png"){
$original_image = imagecreatefrompng($file);
}

//RESOLUTION
$original_width = imagesx($original_image);
$original_height = imagesy($original_image);
	
if($original_width > 400 || $original_height > 400){
//TRY WIDTH FIRST
$ratio = $max_resolution / $original_width;
$new_width = $max_resolution;
$new_height = $original_height * $ratio;
	
	
//if that didnt work
if($new_height > $max_resolution){
$ratio = $max_resolution / $original_height;
$new_height = $max_resolution;
$new_width = $original_width * $ratio;
}

if($original_image){
	
$new_image = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($new_image, $original_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
	
if(imagejpeg($new_image, $smallImageDestination, 90)){
return $smallImageDestinationDB;
}else{
return "error";
}
	
}else{
return "error";
}	
}else{
$smallImageDestinationDB = "";
return $smallImageDestinationDB;
}
}









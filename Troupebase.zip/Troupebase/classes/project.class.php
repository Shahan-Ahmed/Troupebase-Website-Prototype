<?php
require_once("dbh.class.php");

class Project extends Dbh{

	
	
	//DELETE MY PROJECT RESPONSE
	public function deleteMyPGResponse($userLoggedIn, $projectID){
	$sql = "DELETE FROM applicants WHERE user = ? AND projectID = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $projectID])){
		return "success";
		}else{
		return "error";
		}
	}
	
	
	
	
	
	//GET MY PROJECT RESPONSES
	public function getMyResponses($userLoggedIn, $start){
	
		
			$sql = "SELECT projectID, message FROM applicants WHERE user = ? ORDER BY dateTime DESC LIMIT ?, 20";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $start])){
			
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "error";
		}
		
		
		
	}
	
	

	
	
	
	
	
	
	//DELETE RESPONSE
	public function deleteResponse($userLoggedIn, $id){
	$sql = "DELETE FROM applicants WHERE user = ? AND projectID = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $id])){
			
			return "success";
			
		}else{
		return "error";
		}
	}
	
	
	
	
	//GET PROJECT RESPONSE
	public function getProjectResponse($userLoggedIn, $projectID){
	$sql = "SELECT * FROM applicants WHERE user = ? AND projectID= ? AND ignored = ? AND deleted = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $projectID, 0, 0])){
			
			$result = $stmt->fetch();
			return $result;
			
		}else{
		return "error";
		}
	
	}
	
	
	
	
	
	
	
	
	//CHECK IF RESPONSE ALREADY SENT
	public function checkIfResponseSent($userLoggedIn, $projectID){
	
		$sql = "SELECT id FROM applicants WHERE user = ? AND projectID = ? AND ignored = ? AND deleted = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $projectID, 0, 0])){
			
			$result = $stmt->fetchAll();
			return count($result);
			
		}else{
		return "error";
		}
		
		
	}
	
	
	
	
	//UPDATE LAST APPLIED
	public function updateProjectLastApplied($date, $projectID){
	$sql = "UPDATE posts SET lastApplied = ? WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$date, $projectID])){
		return "success"; 
		}else{
		return "error";
		}
	}
	
	
	
	
	//INSERT PROJECT GOAL RESPONSE
	public function insertProjectResponse($userLoggedIn, $projectID, $date, $message){
	
		$sql = "INSERT INTO applicants (projectID, user, dateTime, message) VALUES (?, ?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$projectID, $userLoggedIn, $date, $message])){
		return "success"; 
		}else{
		return "error";
		}
		
	}
	
	
	
	
	
	
	
	
	//GET TOTAL RESPONSES
	public function getTotalResponses($projectID){
	
		$sql = "SELECT count(*) FROM applicants WHERE projectID = ? AND ignored = ? AND reported = ? AND deleted = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$projectID, 0, 0, 0])){
			
			$result = $stmt->fetchColumn();
			return $result;
			
		}else{
		return "error";
		}
	
	}
	
	
	
	
	//CHECK IF ALREADY SHARED
	public function checkAlreadyShared($userLoggedIn, $user, $projectID)
	{
	
		$sql = "SELECT * FROM sharedProjects WHERE userFrom = ? AND userTo = ? AND projectID = ? LIMIT 1";
		$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $projectID])){
	
		$result = $stmt->fetchAll();
			return count($result);
		
	}
		
	}
	
	
	
	
	
		//SHARE PROJECT
	public function shareProjectGoal($userLoggedIn, $user, $projectID, $date)
	{

	$sql = "INSERT INTO sharedProjects (userFrom, userTo, projectID, dateTime) VALUES (?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $projectID, $date])){
	
		return "success";
		
	}else{
	return "error";
	}

	}
	
	
	
	
	
	
	
	
	//DELETE PROJECT'
	public function deleteProjectGoal($userLoggedIn, $id)
	{
	$sql = "UPDATE projectGoals SET deleted = ? WHERE user = ? AND id = ?";
	$stmt = $this->connect()->prepare($sql);
	$stmt->execute([1, $userLoggedIn, $id]);
	}
	
	
	
	
	//CHECK APPLIED
	public function checkApplied($userLoggedIn, $id)
	{
	
		$sql = "SELECT id FROM applicants WHERE user = ? AND projectID = ? AND deleted = ? LIMIT 1";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn, $id, 0]);
		
			$result = $stmt->fetchAll();
			return count($result);
		
		
	}
	
	
	
	

	
	
	
	
	
	
	
	//INSERT PROJECT
	public function insertProject($uniqueID, $userLoggedIn, $city, $state, $country, $subject, $details, $selectedTalentsPG, $userLoggedInTalents){
		
		$type = 'pg';
		$videoFit = 'null';
		$comma = ',';
		$nul = 'null';
		$dateTime = time();
		
		$sql = "INSERT INTO posts (id, user, file, details, type, dateTime, complete, coverPhoto, reportString, videoFit, taggedString, subject, requiredTalent, state, lastApplied, smallImage, city, country, usersTalents) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$uniqueID, $userLoggedIn, $nul, $details, $type, $dateTime, 1, $nul, $comma, $nul, $comma, $subject, $selectedTalentsPG, $state, $dateTime, $nul, $city, $country, $userLoggedInTalents])){
			
		return "success";
			
		}else{
		return "error";
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
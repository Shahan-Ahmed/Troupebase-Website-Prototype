<?php
require_once("dbh.class.php");

class Register extends Dbh{
	

	

	

	public function checkexisting($email)
	{
	
		$sql = "SELECT email FROM users WHERE email = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$email]);
		
		$result = $stmt->fetchAll();
		
		return $result;
	
	}

	
		public function createaccount($name, $email, $hashedPwd)
	{
			
			
	
			$sql = "INSERT INTO users (email, name, password, messageReceipt, pgVis, signUpDate, talentString) VALUES (?,?,?,?,?,?,?)";
			$stmt = $this->connect()->prepare($sql);
			$blocked = ',';
			$talentStringDefault = ',';
			$date = time();
			if($stmt->execute([$email, $name, $hashedPwd, 1, 1, $date, $talentStringDefault]))
			{
				return "success";
				
			}else{
				return "failed";
			}
	
	}
	
	
	
	
	//INSERT SESSION
	public function insertsession($name, $email, $hashedPwd)
	{
	
				
				
	}
	

}












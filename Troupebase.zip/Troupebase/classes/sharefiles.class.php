<?php
require_once("dbh.class.php");


class Share extends Dbh{
    public $userLoggedIn = "";
	public $fileDestDb = "";
	public $previewdestdb = "";
	public $currentConvo = "";
    public $originalName = "";
	

    public function __construct($userLoggedIn, $fileDestDb, $previewdestdb, $currentConvo, $originalName){
        $this->userLoggedIn = $userLoggedIn;
		$this->fileDestDb = $fileDestDb;
		$this->previewdestdb = $previewdestdb;
		$this->currentConvo = $currentConvo;
		$this->originalName = $originalName;
    }
	

	
	
	public function insert()
	{

		$date = time();
		
		$sql = "INSERT INTO messages (body, dateTime, messageID, userFrom, file, fileName, filePreview) VALUES (?,?,?,?,?,?,?)";
		
		$stmt = $this->connect()->prepare($sql);
		
		$stmt->execute(['SHARED FILE:',$date, $this->currentConvo, $this->userLoggedIn, $this->fileDestDb, $this->originalName, $this->previewdestdb]);
	
	
	}
	
	
	
	
	
	
	

}




















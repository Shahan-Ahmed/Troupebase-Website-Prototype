<?php
require_once("../classes/dbh.class.php");

class Troupes extends Dbh{
	
	
	
	
//GET TROUPES
public function getTroupes($user, $start){

$sql = "SELECT * FROM connectedTroupes WHERE (userA = ? OR userB = ?) ORDER BY dateTime DESC LIMIT ?, 10";
$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$user, $user, $start])){
		$result = $stmt->fetchAll();
			return $result;
	}else{
	return "error";
	}	

}
	
	
	
	//GET SENT TROUPE REQUESTS
public function getSentTroupeRequests($userLoggedIn, $start){
$sql = "SELECT * FROM notifications WHERE (userFrom = ? AND type = ?) ORDER BY dateTime DESC LIMIT ?, 10";	
$stmt = $this->connect()->prepare($sql);	
	$n = 'troupeRequest';
	if($stmt->execute([$userLoggedIn, $n, $start])){
		$result = $stmt->fetchAll();
			return $result;
	}else{
	return "error";
	}		
	
}	
	
	
	
	
//GET TROUPE REQUESTS
public function getTroupeRequests($userLoggedIn, $start){
$sql = "SELECT * FROM notifications WHERE (userTo = ? AND type = ?) ORDER BY dateTime DESC LIMIT ?, 10";	
$stmt = $this->connect()->prepare($sql);	
	$n = 'troupeRequest';
	if($stmt->execute([$userLoggedIn, $n, $start])){
		$result = $stmt->fetchAll();
			return $result;
	}else{
	return "error";
	}		
	
}	
	
	
	
	
	
	
	
	
	
}
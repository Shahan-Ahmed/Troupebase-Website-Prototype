<?php
require_once("dbh.class.php");

class User extends Dbh{
	
	
	//GET TROUPES BY TALENT AND LOCATION
	public function getTroupeSearchByTalentAndLocation($start, $talent, $userLoggedIn, $city, $state, $country){
	
		
$sql = "SELECT * FROM users WHERE (city = ? AND state = ? AND country = ?) AND talentString LIKE ? ORDER BY id DESC LIMIT ?, 15";
		$stmt = $this->connect()->prepare($sql);
		$needle = '%'.$talent.',%';
		if($stmt->execute([$city, $state, $country, $needle, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
		
	}
	
	
	
	
	
	
	
	//GET TROUPES BY TALENT
		public function getTroupeSearchByTalent($start, $userLoggedIn, $talent){
	
			$sql = "SELECT * FROM users WHERE talentString LIKE ? ORDER BY id DESC LIMIT ?, 15";
		$stmt = $this->connect()->prepare($sql);
		$needle = '%'.$talent.',%';
		if($stmt->execute([$needle, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		

	}
	
	
	
	//GET TROUPES SEARCH BY LOCATION
	public function getTroupeSearchByLocation($start, $userLoggedIn, $city, $state, $country){
	
		
		$sql = "SELECT * FROM users WHERE id != ? AND city = ? AND state = ? AND country = ? ORDER BY id DESC LIMIT ?, 15";
		$stmt = $this->connect()->prepare($sql);
		$needle = '';
		if($stmt->execute([$needle, $city, $state, $country, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
		
	}
	
	
	
	
	
	//GET TROUPES SEARCH ALL
	public function getTroupeSearchAll($start){
	
		//$sql = "SELECT * FROM users WHERE alias != ? AND state != ? ORDER BY id DESC LIMIT ?, 15";
		$sql = "SELECT * FROM users WHERE id != ? ORDER BY id DESC LIMIT ?, 15";
		$stmt = $this->connect()->prepare($sql);
		$needle = '';
		if($stmt->execute([$needle, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//DELETE TROUPE
	public function deleteTroupe($userLoggedIn, $user){
	$sql = "DELETE FROM connectedTroupes WHERE (userA = ? AND userB = ?) OR (userA = ? AND userB = ?)";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $user, $userLoggedIn])){
	return "success";	
	}else{
	return "error";
	}
	}
	
	
	
	//DENY TROUPE REQUEST
	public function denyTroupeRequest($userLoggedIn, $user){
	$sql = "DELETE FROM notifications WHERE (userFrom = ? AND userTo = ? AND type = ?)";
	$stmt = $this->connect()->prepare($sql);
	$type = 'troupeRequest';
	if($stmt->execute([$user, $userLoggedIn, $type])){
	return "success";	
	}else{
	return "error";
	}
	}
	
	
	
	
	//CANCEL TROUPE REQUEST
	public function cancelTroupeRequest($userLoggedIn, $user){
	$sql = "DELETE FROM notifications WHERE (userFrom = ? AND userTo = ? AND type = ?)";
	$stmt = $this->connect()->prepare($sql);
	$type = 'troupeRequest';
	if($stmt->execute([$userLoggedIn, $user, $type])){
	return "success";	
	}else{
	return "error";
	}
	}
	
	
	
	
	
	
	
	
	//SEND TROUPE REQUEST
	public function sentTroupeRequest($userLoggedIn, $user, $date){
	$sql = "INSERT INTO notifications (userFrom, userTo, dateTime, type, comment, postType, commentID) VALUES (?, ?, ?, ?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
	$type = 'troupeRequest';
	$comment = "sent you a Troupe Request";
	$null = "null";
	if($stmt->execute([$userLoggedIn, $user, $date, $type, $comment, $null, $null])){
	return "success";
	}else{
	return "error";
	}
	}
	
	
	
	//ADD TO CONNECTED TROUPES
	public function addToTroupes($userLoggedIn, $user, $date){
	$sql = "INSERT INTO connectedTroupes (userA, userB, dateTime) VALUES (?,?,?)";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $date])){
	return "success";
	}else{
	return "error";
	}
	}
	
	
	
	
	
	//CHECK IF TROUPE REQUEST SENT OR RECEIVED
public function isTroupeRequestSentOrRec($userLoggedIn, $user){
$sql = "SELECT * FROM notifications WHERE ((userFrom = ? AND userTo =?) OR (userFrom = ? AND userTo =?)) AND type = ? AND deleted = ? LIMIT 1";
$stmt = $this->connect()->prepare($sql);
$n1 = 'troupeRequest';
if($stmt->execute([$userLoggedIn, $user, $user, $userLoggedIn, $n1, 0])){

$result = $stmt->fetch();	

$sentOrReceived = "none";
if($result['userFrom'] == $userLoggedIn){
$sentOrReceived = "sent";
}
if($result['userTo'] == $userLoggedIn){
$sentOrReceived = "received";
}
			
return $sentOrReceived;	
	
}else{
return "error";
}
		
			
	
}
	
	
	
	
	
	
	
	
	//GET TROUPE STATUS
	public function checkIfTroupes($userLoggedIn, $user){
	$sql = "SELECT id FROM connectedTroupes WHERE (userA = ? AND userB = ?) OR (userA = ? AND userB = ?)";
	$stmt = $this->connect()->prepare($sql);
	if($stmt->execute([$userLoggedIn, $user, $user, $userLoggedIn])){
	$result = $stmt->fetchAll();
	$count = count($result);
	if($count>0){
		return "troupes";
	}else{
		return "none";
	}
	}else{
		return "error";
	}
	}
	
	
	
	
	//USERS SEARCH
	public function usersSearch($userLoggedIn, $user, $start){
	
		
		$sql = "SELECT id, name, talentString, profilePic, state, city, country, messageReceipt, lastOnline, photoFilter FROM users WHERE (name LIKE ? OR alias LIKE ?) ORDER BY id DESC LIMIT ?, 10";
		$stmt = $this->connect()->prepare($sql);
		$needle = '%'.$user.'%';
		if($stmt->execute([$needle, $needle, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
		
		
	}
	
	
	
	
	
	
	//GET USERS
	public function getusers($userLoggedIn, $user, $start){
	
		
		$sql = "SELECT id, name, talent, profilePic, state, city, country, messageReceipt, lastOnline, photoFilter FROM users WHERE (name LIKE ? OR alias LIKE ?) AND alias != '' AND state != '' ORDER BY id DESC LIMIT ?, 10";
		$stmt = $this->connect()->prepare($sql);
		$needle = '%'.$user.'%';
		if($stmt->execute([$needle, $needle, $start])){
		
			$result = $stmt->fetchAll();
			return $result;
			
		}else{
		return "end";
		}
		
		
		
	}
	
	
	
	
	
	//ACCEPT TOU
	public function acceptTermsOfUse($userLoggedIn)
	{
		$sql = "UPDATE users SET acceptedTOU = 1 WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn]);
	}
	
	//DECLINE TOU
	public function declineTermsOfUser($userLoggedIn)
	{
		$sql = "UPDATE users SET acceptedTOU = 0 WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn]);
	}
	
	
	//UNBLOCK
	public function unblock($userLoggedIn, $userToUnblock)
	{
		$sql = "DELETE FROM blocked WHERE userA = ? AND userB = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn, $userToUnblock]);
		
		return "success";
		
	}
	
	
	
	
	//
	
	
	
	
	//BLOCK
	public function block($userLoggedIn, $user, $date)
	{
		$sql = "INSERT INTO blocked(userA, userB, dateTime) VALUES (?, ?, ?)";		
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $user, $date])){
	
			return "success";
		
		}else{
		return "error";
		}
	
	}
	
	
	
	
	
	
	
	//UPDATE PROFILE PIC
		public function updateProfilePic($userLoggedIn, $fileDB, $selectedProfFilter){
		
			$sql = "update users SET profilePic = ?, photoFilter = ? WHERE id = ?";
			$stmt = $this->connect()->prepare($sql);
			if($stmt->execute([$fileDB,$selectedProfFilter,$userLoggedIn])){
			return $fileDB;
			}else{
			echo "error";
			}
		
		}
	
	
	//UPDATE MESSAGE RECEIPT
		public function messageReceipt($userLoggedIn, $messageReceipt){
		
		$sql = "update users SET messageReceipt = ? WHERE id = ?";
			$stmt = $this->connect()->prepare($sql);
			$stmt->execute([$messageReceipt,$userLoggedIn]);
		
		
		}
	
	
	
	//UPDATE PROFILE
	public function updateProfile($userLoggedIn, $newName, $newCity, $newState, $newCountry, $timeZone, $socialMediaString, $newProfileMessage, $newWebsite, $collabRequestPrivacy, $troupeRequestPrivacy, $projectGoalVisibility){

		$sql = "update users SET name = ?, state = ?, city = ?, country = ?, timeZone = ?, smLinks = ?, projectGoal = ?, website = ?, privacyCR = ?, privacyTR = ?, pgVis = ? WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$newName, $newState, $newCity, $newCountry, $timeZone, $socialMediaString, $newProfileMessage, $newWebsite, $collabRequestPrivacy, $troupeRequestPrivacy, $projectGoalVisibility, $userLoggedIn])){
		
			echo "success";
			
			
		}else{
		echo "error";
		}
		
	}
	
	
	

	//GET USERS TO TAG IN POST COMMENT
	public function getUsersToTagComment($user, $start){
		$sql = "SELECT id, name, talent, alias, profilePic, state FROM users WHERE (name LIKE ? OR alias LIKE ? OR email LIKE ?) AND visible = 1 AND alias != ? LIMIT ?, 7";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = "%".$user."%";
		$needleTwo = "";
		if($stmt->execute([$needleOne, $needleOne, $needleOne, $needleTwo, $start])){
		$result = $stmt->fetchAll();
			return $result;
			
		}
	}
	
	
	
	
	
	//GET USERS TO TAG
	public function getUsersToTag($userLoggedIn, $user, $start)
	{
	
		$sql = "SELECT * FROM users WHERE (name LIKE ? OR alias LIKE ? OR email LIKE ?) ORDER BY name DESC LIMIT ?, 7";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = "%".$user."%";
		$needleTwo = "%,".$userLoggedIn.",%";
		$needleThree = "";
		$stmt->execute([$needleOne, $needleOne, $needleOne, $start]);
		$result = $stmt->fetchAll();
		
			return $result;
		
	}
	
	
	
	
		//CHECK USERS EMAIL EXIST
	public function checkUserEmailExist($email)
	{
	
			$sql = "SELECT id, email, password, alias FROM users WHERE email = ?";
			$stmt = $this->connect()->prepare($sql);
			if($stmt->execute([$email])){
				return $stmt->fetch();
			}else{
			return "error";
			}
		
	}
	
	
	
	
	//GET PROFILE
	public function getProfile($user)
	{
		
		$sql = "SELECT * FROM users WHERE id = ? OR alias = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$user, $user]);
		$result = $stmt->fetch();
		
		return $result;
		
	}
	
	
	
	//GET USER
	public function getUser($user)
	{

	$sql = "SELECT id, name, profilePic, state, city, country, messageReceipt, lastOnline, photoFilter, talentString FROM users WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$user]);
		
		$result = $stmt->fetch();
		
			return $result;
	
	}
	
	
	//CHECK USERNAME SAME 
	public function getUserAlias($userLoggedIn)
	{
	
		$sql = "SELECT alias FROM users WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn])){
			
			$result = $stmt->fetch();
			return $result;
			
		}else{
		echo "error";
		}
		
	}
	
	
	
	//CHECK ALIAS TAKEN
	public function checkUserNameTaken($userLoggedIn, $alais)
	{
	$sql = "SELECT alias FROM users WHERE alias = ? AND id != ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$alais, $userLoggedIn])){
		
			return count($stmt->fetchAll());
			
		}else{
		return "error";
		}
		
	}
	
	//UPDATE USERNAME
	public function updateUsername($userLoggedIn, $alias)
	{
	
		$sql = "UPDATE users SET alias = ? WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$alias,$userLoggedIn])){
		
			return "success";
		
		}else{
		return "error";
		}
	}
	
	
	
	


	
	
	
	//GET USER LOGGED IN
	public function getUserLoggedIn($email)
	{

		$sql = "SELECT id, name, signUpDate, profilePic, projectGoal, smLinks, visible, verified, state, city, country, acceptedTOU, website, timeZone, privacyCR, privacyTR, lastOnline, messageReceipt, alias, suspended, pgVis, reports, photoFilter, talentString FROM users WHERE email = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$email])){
		
		$result = $stmt->fetch();
		
			return $result;
			
		}else{
		return "error";
		}
	
	}
	
	//LOGOUT
		public function logout($userLoggedIn, $sessionID)
		{
			$sql = "DELETE FROM sessions WHERE user = ? AND sessionID = ?";
			$stmt = $this->connect()->prepare($sql);
			$needle = "";
			if($stmt->execute([$userLoggedIn,$sessionID])){
				
				return "success";
		
			}
		}
	
	
		//GET TALENTS
	public function getTalents($user)
	{
	
		$sql = "SELECT talent FROM talent WHERE user = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$user])){
		
			$result = $stmt->fetchAll();
			return $result;		
		}
	}
	
			//GET TALENTS
	public function getTalentsOne($user)
	{
	
		$sql = "SELECT talentString FROM users WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$user])){
		
			$result = $stmt->fetch();
			return $result;		
		}
		
	}
	
	
	
	
	
			//REMOVE TALENT
	public function removTalent($user, $talent)
	{
	
		$sql = "UPDATE users SET talentString = REPLACE(talentString, ?, ?) WHERE id = ?";
		$stmt = $this->connect()->prepare($sql);
		$needleOne = ",".$talent.",";
		$needleTwo = ",";
		if($stmt->execute([$needleOne, $needleTwo, $user])){
		
			return "success";
		
		}else{
		
			return "error";
			
		}
	}
	
	
	
	
	
//UPDATE TALENT

	public function updateTalent($userLoggedIn, $talent)
	{
		$sql = "UPDATE users SET talentString = CONCAT(talentString, ?) WHERE id = ?";
		$needle = $talent.",";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$needle, $userLoggedIn])){
			return "success";	
		}else{
		return "error";
		}
		
	}
	
	
	
	
	//BLOCKED
	public function getBlocked($userLoggedIn,$start)
	{
		$sql = "SELECT userB FROM blocked WHERE userA = ? ORDER BY dateTime DESC LIMIT ?, 7";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn, $start]);
		return $stmt->fetchAll();
	}
	
	
	
	
	
		
	//GET BLOCKED STATUS
		public function getBlockedStatus($userLoggedIn, $user){
	
		$sql = "SELECT * FROM blocked WHERE (userA = ? AND userB = ?) OR (userA = ? AND userB = ?)";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userLoggedIn, $user, $user, $userLoggedIn]);
		return $stmt->fetchAll();
		
	}
	

	
	
	
	


	
	
	//CHECK SESSION
	public function checksession($userLoggedIn, $sessionID, $device)
	{
		$sql = "SELECT email, sessionID FROM sessions WHERE user = ? AND sessionID = ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$userLoggedIn, $sessionID]))
		{
		return $stmt->fetch();
		}else{
		echo "error";
		}
		
	}
	
	
	
	
	
	
	
	
	
	//INSERT SESSION
	public function insertsession($TroupeBaseID, $device, $sessionID, $email)
	{
	
		$date = time();
		
		$sql = "INSERT INTO sessions (user, sessionID, device, email, dateTime) VALUES (?,?,?,?,?)";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([$TroupeBaseID, $sessionID, $device, $email, $date])){
		return "success";
		}else{
		return "error";
		}
	}
	
	
	
	

}















<?php
require_once("../classes/notifications.class.php");
if($_POST['isWebsite']){
$noteID = $_POST['notificationID'];	
$postID = $_POST['postID'];
$userFrom = $_POST['userFrom'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{
	
	
}




$notificationObj = new Notification();


//CHECK ALREADY ADDED
$checkAlreadyAdded = $notificationObj->checkAlreadyAddedToCollabs($userLoggedIn, $postID);

if($checkAlreadyAdded > 0){
echo "success";
$notificationObj->deleteNotification($noteID, $userFrom);
exit();
};





//INSERT TO COLLABS
$addToCollab = $notificationObj->addToCollabList($userLoggedIn, $postID);

echo $addToCollab;





if($checkAlreadyAdded > 0 ||  $addToCollab == "success"){
$notificationObj->deleteNotification($noteID, $userFrom);
}











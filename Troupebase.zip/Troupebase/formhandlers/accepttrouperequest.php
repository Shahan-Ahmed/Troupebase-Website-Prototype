<?php
require_once("../classes/user.class.php");
require_once("../classes/notifications.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();


$userObj = new User();

//CHECK IF ALREADY TROUPES
$ifAlreadyTroupes = $userObj->checkIfTroupes($userLoggedIn, $user);
if($ifAlreadyTroupes == "troupes"){
echo "success";
exit();
}



//INSERT
$insert = $userObj->addToTroupes($userLoggedIn, $user, $date);


echo $insert;





if($insert == "success"){
$deleteNOTE = $userObj->denyTroupeRequest($userLoggedIn, $user);
}
<?php
require_once("../classes/message.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();

$messageObj = new Message();
$userObj = new User();

$activeChatsResults = $messageObj->getActiveChats($userLoggedIn, $start);


if($activeChatsResults == "error"){
echo "error";
exit();
}
if(count($activeChatsResults) == 0){
echo "end";
exit();
}




foreach($activeChatsResults as $chat)
{
	
$id = $chat['chatID'];
$userA = $chat['userA'];
$userB = $chat['userB'];	
$lastMessage = $chat['lastMessage'];
	
if($userA == $userLoggedIn){
$userToGet = $userB;
}else{
$userToGet = $userA;
}
	

//GET LAST MESSAGE
$lastMessage = $messageObj->getLastMessage($id);
$lastMessage = substr($lastMessage, 0, 100);	
	
	
$dateTime = $chat['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);	
		
	
	
//GET USER
$user = $userObj->getUser($userToGet);

	


	

	
$json[] = array(
"id" => $id,
"user"=> $user,
"last" => $lastMessage,
"dateTime" => $dateTime 

	
	
);
	
	
	
	
}


echo json_encode($json);




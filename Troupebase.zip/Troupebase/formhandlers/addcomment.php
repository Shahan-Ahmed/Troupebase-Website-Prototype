<?php
require_once("../classes/post.class.php");
$date = time();
if(isset($_POST['isWebsite'])){
$postID = $_POST['postID'];
$postComment = $_POST['postComment'];
$postCommentTagString = $_POST['postCommentTagString'];
$type = $_POST['type'];
$postBy = $_POST['postBy'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();//DATE
$dateTime = date('h:i A m-d-Y', $date);



$postComment = substr($postComment, 0, 3001);


$postObj = new Post();
$addComment = $postObj->addComment($postID, $postComment, $userLoggedIn, $postCommentTagString, $date);

if($addComment == "error"){
echo "error";
exit();
}

$json = array(
"date" => $date,
"dateTime" => $dateTime,	
"comment" => $postComment
);



echo json_encode($json);






//INSERT NEW COMMENT NOTE
$insertNewCommentNote = $postObj->insertCommentNote($userLoggedIn, $postBy, $postID, $date, "postcomment", $postComment, $type);








//INSERT @ NOTES
if($postCommentTagString !== ","){	
$tagged = explode(',', rtrim($postCommentTagString, ','));
foreach($tagged AS $userTo){
if($userTo !== ""){


	
$insertAtnotes = $postObj->insertAtNotice($userLoggedIn, $userTo, $postID, $date, "comment@", $postComment, $type);


}
}
}








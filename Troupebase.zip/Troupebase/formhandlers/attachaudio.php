<?php
require_once("../classes/message.class.php");
if(isset($_POST['isWebsite'])){
$chatID = $_POST['chatID'];
$audio = $_POST['audio'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

$date = time();
date_default_timezone_set($timeZone);
$uniqueID = $userLoggedIn.time();
$json = array();

$messageObj = new Message();


if($_FILES['fileToAttach']['name'] !==''){
$filenewName = $_FILES['audio']['name'];
$filenewTmpName = $_FILES['audio']['tmp_name'];
$filenewSize = $_FILES['audio']['size'];
$filenewError = $_FILES['audio']['error'];
$filenewType = $_FILES['audio']['type'];	
if($filenewSize > 26214400){
echo "too large";
exit();
}
	

	
$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
$allowed = array('wav','mp3','m4a');		
	
if(in_array($filenewfileActualExt, $allowed)){			
if($filenewError == 0){			
	
	
$fileName = $userLoggedIn.$date.".".$filenewfileActualExt;	
$fileNameMp3 = "../attachments/".$userLoggedIn.$date.".mp3";
$fileDestDBVideo = 'https://troupebase.com/attachments/'.$userLoggedIn.$date.".mp3";//FILE DB
	
$bitrate = "96k";
$output = "/usr/bin/ffmpeg -i $filenewTmpName -b:a $bitrate -map a $fileNameMp3";	
system($output);	
	
	
if(file_exists($fileNameMp3)){		

$type = "audio";	
$message = "shared an audio:";
$insert = $messageObj->sendAttachment($uniqueID, $userLoggedIn, $chatID, $message, $date, $fileDestDBVideo, "null", $type);
	
if($insert == "success"){

$unix = $date;
$dateTime = $date;
$dateTime = date('h:i A m-d-Y', $dateTime);		
	

$json[] = array(

"id" => $uniqueID,
"body" => $message,
"dateTime" => $dateTime,
"userFrom" => $userLoggedIn,	
"viewed" => 0,
"file" => $fileDestDBVideo,
"filePreview" => "null",
"type" => $type
);	
	
echo json_encode($json);	
	
	
}else{
echo "error";
}
	
	
}else{
echo "error";
}
}else{
echo "error";
exit();
}
}else{
echo "error";
exit();
}
	
	
	
}
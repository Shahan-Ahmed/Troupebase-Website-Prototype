<?php

require_once("../classes/message.class.php");
require_once("../classes/processmedia.class.php");

if(isset($_POST['isWebsite'])){
$chatID = $_POST['chatID'];
$photo = $_POST['photo'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

$date = time();
date_default_timezone_set($timeZone);
$uniqueID = $userLoggedIn.time();
$json = array();

$messageObj = new Message();


if($_FILES['fileToAttach']['name'] !==''){
$filenewName = $_FILES['photo']['name'];
$filenewTmpName = $_FILES['photo']['tmp_name'];
$filenewSize = $_FILES['photo']['size'];
$filenewError = $_FILES['photo']['error'];
$filenewType = $_FILES['photo']['type'];	
if($filenewSize > 26214400){
echo "too large";
exit();
}

$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
$allowed = array('jpg', 'jpeg', 'png');
	
if(in_array($filenewfileActualExt, $allowed)){		
if($filenewError == 0){				

	
//FILE NAME
$filename = $userLoggedIn.$date.".".$filenewfileActualExt;	
$file = '../attachments/'.$filename;	
$fileDB = "https://troupebase.com/attachments/".$filename;
move_uploaded_file($filenewTmpName, $file);		
	
if(file_exists($file)){	
	
	
//RESIZE
$resize = resize_image($file, "600", $filenewfileActualExt);	
	

//CREATE TINY	
$smallImageDestination = "../attachments/tinyimage/".$userLoggedIn.$date.".jpg";	
$smallImageDestinationDB = "https://troupebase.com/attachments/tinyimage/".$userLoggedIn.$date.".jpg";		

$smallImage = createSmallImage($file, $smallImageDestination, $smallImageDestinationDB, "200", "jpg", $userLoggedIn, $date);

	
if(file_exists($smallImageDestination)){		

$type = "photo";
$message = "shared a photo:";
$insert = $messageObj->sendAttachment($uniqueID, $userLoggedIn, $chatID, $message, $date, $fileDB, $smallImageDestinationDB, $type);	
	
if($insert == "success"){

$unix = $date;
$dateTime = $date;
$dateTime = date('h:i A m-d-Y', $dateTime);		
	

$json[] = array(

"id" => $uniqueID,
"body" => $message,
"dateTime" => $dateTime,
"userFrom" => $userLoggedIn,	
"viewed" => 0,
"file" => $fileDB,
"filePreview" => $smallImageDestinationDB,
"type" => $type
);	
	
echo json_encode($json);	
	
	
}else{
echo "error";
}
	
	
	
	
}else{
echo "error";
exit();
}	
	
	
}else{
echo "error";
exit();
}	

}else{
echo "error";
exit();
}	
}else{
echo "error";
exit();
}	
}else{
echo "error";
exit();
}
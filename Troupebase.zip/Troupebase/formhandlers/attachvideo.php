<?php

require_once("../classes/message.class.php");
require_once("../classes/processmedia.class.php");

if(isset($_POST['isWebsite'])){
$chatID = $_POST['chatID'];
$video = $_POST['video'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

$date = time();
date_default_timezone_set($timeZone);
$uniqueID = $userLoggedIn.time();
$json = array();

$messageObj = new Message();



if($_FILES['fileToAttach']['name'] !==''){
$filenewName = $_FILES['video']['name'];
$filenewTmpName = $_FILES['video']['tmp_name'];
$filenewSize = $_FILES['video']['size'];
$filenewError = $_FILES['video']['error'];
$filenewType = $_FILES['video']['type'];	
if($filenewSize > 26214400){
echo "too large";
exit();
}
	
	
$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
$allowed = array('mov','ogg','webm','mp4');
	
if(in_array($filenewfileActualExt, $allowed)){		
if($filenewError == 0){		
	
$fileName = $userLoggedIn.$date.".".$filenewfileActualExt;	
$fileNameNewVideo = "../attachments/".$fileName;//NEW FILE NAME
$fileDestDBVideo = 'https://troupebase.com/attachments/'.$fileName;//FILE DESTINATION DATABASE	
	
$bitrate = "1800k";
$output = "/usr/bin/ffmpeg -i $filenewTmpName -b:v $bitrate -bufsize $bitrate $fileNameNewVideo";	
	
	
system($output);	
if(file_exists($fileNameNewVideo)){	
	
	
//CREATE THUMB
$thumbLocation = "../attachments/tinyimage/".$userLoggedIn.$date.".jpg";
$thumbLocationDB = "https://troupebase.com/attachments/tinyimage/".$userLoggedIn.$date.".jpg";
$thumb = "/usr/bin/ffmpeg -ss 0 -i $fileNameNewVideo -vframes 1 -q:v 2 $thumbLocation";
	
system($thumb);	
if(file_exists($thumbLocation)){		

$type = "video";	
$message = "shared a video:";
$insert = $messageObj->sendAttachment($uniqueID, $userLoggedIn, $chatID, $message, $date, $fileDestDBVideo, $thumbLocationDB, $type);	
	
	
if($insert == "success"){

$unix = $date;
$dateTime = $date;
$dateTime = date('h:i A m-d-Y', $dateTime);		
	

$json[] = array(

"id" => $uniqueID,
"body" => $message,
"dateTime" => $dateTime,
"userFrom" => $userLoggedIn,	
"viewed" => 0,
"file" => $fileDestDBVideo,
"filePreview" => $thumbLocationDB,
"type" => $type
);	
	
echo json_encode($json);	
	
	
}else{
echo "error";
exit();
}	
	
	
	
	
}else{
echo "error";
exit();
}
}else{
echo "error";
exit();
}	
	
}else{
echo "error";
exit();
}
}else{
echo "error";
exit();
}
}else{
echo "error";
exit();
}
<?php
require_once("../classes/user.class.php");

if(isset($_POST['isWebsite'])){
$start = $_POST['start'];
}else{

}

$userLoggedIn = $_COOKIE['TroupeBaseID'];

$json = array();

$userObj = new User();
$blockedUsers = $userObj->getBlocked($userLoggedIn,$start);

foreach($blockedUsers as $blockedUser){
$userToGet = $blockedUser['userB'];
$userBObj = $userObj->getUser($userToGet);
	


	$profilePic = $userBObj['profilePic'];
	if($profilePic == ""){
	$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
$json[] = array(

"id" => $userBObj['id'],
"name" => $userBObj['name'],
"profilePic" => $profilePic,
"photoFilter" => $userBObj['photoFilter'],
"talents" => $userBObj['talent'],
"state" => $userBObj['state']
);
	
	
	
	

	
}

echo json_encode($json);

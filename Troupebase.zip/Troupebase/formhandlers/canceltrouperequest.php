<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();


//OBJ
$userObj = new User();
$cancelResult = $userObj->cancelTroupeRequest($userLoggedIn, $user);



echo $cancelResult;
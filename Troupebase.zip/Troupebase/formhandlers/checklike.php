<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$postID = $_POST['postID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


$postObj = new Post();
$resultObj = $postObj->checklike($userLoggedIn, $postID);

if($resultObj == "")
{
$liked = 0;
}else{
$liked = 1;
}


echo $liked;
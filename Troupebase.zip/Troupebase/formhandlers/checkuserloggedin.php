<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_POST['TroupeBaseID'];
$sessionID = $_POST['SessionID'];
$device = $_POST['device'];
}else{

}



$userObj = new User();
$sessionCheck = $userObj->checksession($userLoggedIn, $sessionID, $device); //MATCH SESSION

if($sessionCheck == "error")
{
echo "error";
exit();
}


//GET USER
$email = $sessionCheck['email'];
$sessionID = $sessionCheck['sessionID'];
$userResult = $userObj->getUserLoggedIn($email);



//CHECK FOR UNREAD NOTIFICATIONS

	

echo json_encode(array($userResult,$sessionID, $talentsResult));




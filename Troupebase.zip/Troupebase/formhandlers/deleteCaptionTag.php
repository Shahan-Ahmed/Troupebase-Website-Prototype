<?php
require_once("../classes/notifications.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$username = $_POST['username'];
$timeZone = $_COOKIE['TimeZone'];
$noteID = $_POST['noteID'];
$postID = $_POST['postID'];
$userFrom = $_POST['userFrom'];
$postDate = $_POST['postDate'];
}else{
$post = json_decode(file_get_contents("php://input"));
$userLoggedIn = $post->userLoggedIn;
}



$noteObj = new Notification();


$delete = $noteObj->deleteCaptionTag($userLoggedIn, $username, $userFrom, $postDate, $postID);


if($delete == "success"){
$noteObj->deleteNotification($noteID, $userFrom);
echo "success";
}else{
echo "error";
}
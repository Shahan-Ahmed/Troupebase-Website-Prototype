<?php
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$projectID = $_POST['id'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}



$projectObj = new Project();
$delete = $projectObj->deleteMyPGResponse($userLoggedIn, $projectID);


echo $delete;
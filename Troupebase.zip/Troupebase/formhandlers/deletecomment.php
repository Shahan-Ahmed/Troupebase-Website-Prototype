<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$commentID = $_POST['commentID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}



$postObj = new Post();
$postObj->deleteComment($userLoggedIn, $commentID);
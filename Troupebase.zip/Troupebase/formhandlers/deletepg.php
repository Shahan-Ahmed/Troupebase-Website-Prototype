<?php
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['projectID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}

$projectObj = new Project();
$deleteResult = $projectObj->deleteProjectGoal($userLoggedIn, $id);
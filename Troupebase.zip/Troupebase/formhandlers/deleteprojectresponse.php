<?php
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['id'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();


$project = new Project();
$delete = $project->deleteResponse($userLoggedIn, $id);

echo $delete;
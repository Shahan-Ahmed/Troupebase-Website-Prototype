<?php
require_once("../classes/notifications.class.php");
if(isset($_POST['isWebsite'])){
$notificationID = $_POST['notificationID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$noteObj = new Notification();
$deny = $noteObj->denyNotification($userLoggedIn, $notificationID);

echo $deny;
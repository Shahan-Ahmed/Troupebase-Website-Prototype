<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
$start = $_POST['start'];
$talent = $_POST['talent'];
$state = $_POST['state'];
$city = $_POST['city'];
$country = $_POST['country'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();
$postObj = new Post();



//IF LOCATION SELECTED ONLY
if($talent == "" && $country !== ""){
$postResults = $postObj->getPostsForDiscoverByLocation($start, $userLoggedIn, $city, $state, $country);
$searchingBy = 1;
}
if($talent !== "" && $country == ""){
$postResults = $postObj->getPostsForDiscoverByTalent($start, $userLoggedIn, $talent);
$searchingBy = 2;
}
if($talent !== "" && $country !== ""){
$postResults = $postObj->getPostsForDisTalentLocation($start, $userLoggedIn, $city, $state, $country, $talent);
$searchingBy = 3;
}


if(count($postResults) == 0){
echo "end";
exit();
}

foreach($postResults as $post)
{


	$smallimage = $post['smallimage'];


$json[] = array(
"searchingBy" => $searchingBy,
"userLoggedIn" => $userLoggedIn,
"id" => $post['id'],
"user" => $post['user'],
"file" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"smallimage" => $smallimage
);	
	
}

echo json_encode($json);





<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
$start = $_POST['start'];
$talent = $_POST['talent'];
$state = $_POST['state'];
$city = $_POST['city'];
$country = $_POST['country'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();

$postObj = new Post();




if($talent == "" && $country !== ""){
$projectResults = $postObj->getProjectsByLocation($start, $userLoggedIn, $city, $state, $country);
$searchingBy = 1;
}
if($talent !== "" && $country == ""){
$projectResults = $postObj->getProjectsByTalent($start, $userLoggedIn, $city, $state, $country, $talent);
$searchingBy = 2;
}
if($talent !== "" && $country !== ""){
$projectResults = $postObj->getProjectsByTalAndLoc($start, $userLoggedIn, $city, $state, $country, $talent);
$searchingBy = 3;
}

if(count($projectResults) == 0){
echo "end";
exit();
}


foreach($projectResults as $post)
{
	
//GET USER
$userObj = new User();
$userResults = $userObj->getUser($post['user']);	
	

$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
$smallimage = $post['smallimage'];
	
$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state']
);	
	
}

echo json_encode($json);

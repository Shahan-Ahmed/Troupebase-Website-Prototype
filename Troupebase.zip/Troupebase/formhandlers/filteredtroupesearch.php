<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
$start = $_POST['start'];
$talent = $_POST['talent'];
$state = $_POST['state'];
$city = $_POST['city'];
$country = $_POST['country'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();
$userObj = new User();



if($talent == "" && $country !== ""){
$troupesResult = $userObj->getTroupeSearchByLocation($start, $userLoggedIn, $city, $state, $country);
$searchingBy = 1;
}
if($talent !== "" && $country == ""){
$troupesResult = $userObj->getTroupeSearchByTalent($start, $userLoggedIn, $talent);
$searchingBy = 2;
}
if($talent !== "" && $country !== ""){
$troupesResult = $userObj->getTroupeSearchByTalentAndLocation($start, $talent, $userLoggedIn, $city, $state, $country);
$searchingBy = 3;
}



if(count($troupesResult) == 0){
echo "end";
exit();
}






foreach($troupesResult as $user){

$troupeID = $user['id'];
$name = $user['name'];
$talent = $user['talent'];
$alias = $user['alias'];	
$profilePic = $user['profilePic'];
if($profilePic ==""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
$state = $user['state'];	

	

	
$json[] = array(
'troupeID' => $troupeID,
'name' => $name,
'talent' => $user['talentString'],
'alias' => $alias,
'profilePic' => $profilePic,
'state' => $state
);
	


}





echo json_encode($json);










<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$postID = $_POST['postID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$start = $_POST['start'];
}else{

	
}

$json = array();



$postObj = new Post();



//GET COLLABORATION IDS
$collabResults = $postObj->getCollaborations($postID, $start, 10);
$resultCheck = count($collabResults);
if($resultCheck == 0){
echo "end";
exit();
}




foreach($collabResults as $collab){
//GET USER

$userID = $collab['user'];
	
$userObj = new User();
$userResult = $userObj->getUser($userID);	

$talentString = "";//TALENT STRING
$talentsResult = $userObj->getTalents($userID);
foreach($talentsResult as $talent){
$talentString = $talentString." ".$talent['talent'];
}	
	
	
$json[]=array(
"user" => $userResult,
"talentString" => $talentString
);

	
	
}


echo json_encode($json);


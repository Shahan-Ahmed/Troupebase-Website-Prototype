<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$commentID = $_POST['commentID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

	
}
date_default_timezone_set($timeZone);
$json = array();




//CLASS OBJECTS
$postObj = new Post();
$userObj = new User();


//GET COMMENT
$commentResult = $postObj->getTheComment($commentID);
if($commentResult == "error"){
echo "error";
exit();
}

$dateTime = $commentResult['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);


//GET USER
$user = $commentResult['user'];//POSTED BY ID
$userResult = $userObj->getUser($user);



echo json_encode(array($userResult, $commentResult, $dateTime));



















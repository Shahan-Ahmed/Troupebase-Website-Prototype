<?php
require_once("../classes/notifications.class.php");
require_once("../classes/user.class.php");
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$noteID = $_POST['noteID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);


$noteObj = new Notification();
$notificationResult =  $noteObj->returnNotification($noteID);
if($notificationResult == "error"){
echo "error";
exit();
}


echo $notificationResult['commentID'];

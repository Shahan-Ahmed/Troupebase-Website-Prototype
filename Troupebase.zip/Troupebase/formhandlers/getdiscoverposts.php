<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$start = $_POST['start'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();



//OBJ
$postObj = new Post();


//GET POSTS
$postResults = $postObj->getPostsForDiscover($start, $userLoggedIn);
if(count($postResults) == 0){
echo "end";
exit();
}



foreach($postResults as $post)
{


	$smallimage = $post['smallimage'];


$json[] = array(
"userLoggedIn" => $userLoggedIn,
"id" => $post['id'],
"user" => $post['user'],
"file" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"smallimage" => $smallimage
);	
	
}

echo json_encode($json);



<?php
require_once("../classes/user.class.php");
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
if($userLoggedIn == ""){
exit();
}

//OBJ
$userObj = new User();
$postObj = new Post();



//GET USERS TALENT

$talentsResult = $userObj->getTalents($userLoggedIn);
if(count($talentsResult) == 0){
exit();
}





//FIND USERS
foreach($talentsResult as $talent){
$talentToSearch = $talent['talent'];
	
	
	
	
	
	
	
	
}
	









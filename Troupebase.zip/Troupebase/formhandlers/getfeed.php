<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$user = $_POST['user'];
$start = $_POST['start'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();


$projObj = new Project();
$postObj = new Post();
$responseObj = $postObj->getPosts($user, $userLoggedIn, $start);
$resultCheck = count($responseObj);

//IF NO RESULTS
if($resultCheck == 0){
echo "end";
exit();
}





//GET USER
$userObj = new User();
$userResults = $userObj->getUser($user);






foreach($responseObj as $post)
{

	

$checkApplied = 0;
if($post['type'] == "pg"){
//CHECK APPLIED
$checkApplied = $projObj->checkIfResponseSent($userLoggedIn, $post['id']); 	

//GET TOTAL APPLICANTS
$totalApplicants = $projObj->getTotalResponses($post['id']);
	
}
	
$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
	
$smallimage = $post['smallimage'];
	
$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"responseStatus" => $checkApplied,
"totalApplicants" => $totalApplicants
);	
	
}


echo json_encode($json);
<?php
require_once("../classes/message.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['id'];
$lastMessageDate = $_POST['lastMessageDate'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();

$messageObj = new Message();

$messages = $messageObj->getlatestmessages($id, $lastMessageDate);
if(count($messages)==0){
echo "end";
exit();
}


foreach($messages as $message){

$unix = $message['dateTime'];
$dateTime = $message['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);	
	
	
$json[] = array(

"id" => $message['id'],
"body" => $message['body'],
"unix" => $unix,
"dateTime" => $dateTime,
"userFrom" => $message['userFrom'],	
"viewed" => $message['viewed'],
"file" => $message['file'],
"filePreview" => $message['filepreview'],
"type" => $message['type'],
"isOlder" => 0
);
	

	
}



echo json_encode($json);
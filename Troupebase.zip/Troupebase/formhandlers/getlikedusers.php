<?php
require_once("../classes/user.class.php");
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$postID = $_POST['postID'];
$start = $_POST['start'];
}else{

}

$json = array();


$postObj = new Post();
$resultObj = $postObj->getlikedusers($postID, $start);
$resultCheck = count($resultObj);
if($resultCheck > 0){
foreach($resultObj as $result){
$troupeID = $result['user'];//TROUPE ID	

$userObj = new User();
$userResult = $userObj->getUser($troupeID);
	
foreach($userResult as $u){
	
$profilePic = $u['profilePic'];
if($u['profilePic'] == ""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
	
$talentString = "";

$talentResult = $userObj->getTalents($u['id']);
foreach($talentResult as $talent){
$talentString = $talentString. " " .$talent['talent'];
}
	

$json[] = array(
"troupeID" => $u['id'],
"name" => $u['name'],
"alias" => $u['alias'],
"state" => $u['state'],
"profilePic" => $profilePic,
"talent" => $talentString

);

}


}
}else{
echo "end";
exit();
}
echo json_encode($json);
<?php
require_once("../classes/location.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_POST['TroupeBaseID'];
$value = $_POST['value'];
$start = $_POST['start'];
}else{

}


$locationObj = new Location();
$locationsResult = $locationObj->getLocations($value);
if($locationsResult == "end"){
echo "end";
exit();
}



echo json_encode($locationsResult);



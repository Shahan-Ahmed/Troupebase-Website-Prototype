<?php
require_once("../classes/notifications.class.php");
require_once("../classes/user.class.php");
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$username = $_POST['username'];
$timeZone = $_COOKIE['TimeZone'];
$start = $_POST['start'];
}else{
$post = json_decode(file_get_contents("php://input"));
$userLoggedIn = $post->userLoggedIn;
}

date_default_timezone_set($timeZone);



//JSON
$json = array();



//GET THE NOTIFICATIONS
$notificationObj = new Notification();
$notificationResult = $notificationObj->getNotifications($userLoggedIn, $username, $start);
if($notificationResult == "error"){
echo "error";
exit();
}
$resultCheck = count($notificationResult);
if($resultCheck == 0){
echo "end";
exit();
}







//LOOP THROUGH
foreach($notificationResult as $notification){

	$id = $notification['id']; //ID
	$type = $notification['type'];
	
	//GET USER FROM
	$userFrom = $notification['userFrom']; //USERFROM
	$userObj = new User();
	$userResult = $userObj->getUser($userFrom);//USER RESULT
	
	$dateTime = $notification['dateTime'];
	$dateTime = date('h:i A m-d-Y', $dateTime);
	
	$profilePic = $userResult['profilePic'];
	if($profilePic ==""){
	$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
	
	
	
	//GET POST INFO
	$postObj = new Post();
	$postPreview = $postObj->getPreviewPhoto($notification['postID']);
	$coverPhoto = $postPreview['smallimage'];
	if($coverPhoto == ""){
	$coverPhoto = $postPreview['coverPhoto'];
	}
	$postDate = $postPreview['dateTime'];
	$postDate = date('h:i A m-d-Y', $postDate);
	
	
	
	
$json[] = array(
"id" => $id,
"userFrom" => $userFrom,
"postID" => $notification['postID'],
"dateTime"=> $dateTime,
"type" => $notification['type'],
"subject" => $notification['subject'],
"comment" => $notification['comment'],
"commentFrom" => $notification['commentID'],
"postType" => $notification['postType'],
"smallImage" =>$coverPhoto,
"postDate" => $postDate,
"unix" => $notification['dateTime'],
"userFromName" =>$userResult['name'],
"profilePic" => $profilePic,
"accepted" => $notification['accepted']
);
	
	
	
	

}



echo json_encode($json);



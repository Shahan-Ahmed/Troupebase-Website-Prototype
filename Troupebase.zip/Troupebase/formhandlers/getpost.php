<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$postID = $_POST['postID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}

$jsonCollabs = array();

$postObj = new Post();
$resultObj = $postObj->getPost($postID, $userLoggedIn);
$resultCheck = count($resultObj);
if($resultCheck > 0){

//POSTED BY
$user = $resultObj['user'];
$userObj = new User();
$userResult = $userObj->getUser($user);	

	
//GET COLLABORATIONS
	
//TOTAL COLLABS
$totalCollabsResult = $postObj->getTotalCollaborations($postID);
$totalCollabs = count($totalCollabsResult);
	
	
	
$postID = $resultObj['id'];
$collabResult = $postObj->getCollaborations($postID, 0, 6);
foreach($collabResult as $collab){
$collabUserID = $collab['user'];
$collabUserObj = $userObj->getUser($collabUserID);	

	
//GET COLLABORATOR TALENTS
$talentString = "";
$talents = $userObj->getTalents($collabUserID);
foreach($talents as $talent){
if($talent['talent'] !== ""){
$talentString = $talentString.$talent['talent']." ";
}
}
	
	$profilePic = $collabUserObj['profilePic'];
	if($profilePic == ""){
	$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
	
$jsonCollabs[]=array(

"id" => $collabUserObj['id'],
"name" => $collabUserObj['name'],
"profilePic" => $profilePic,
"state" => $collabUserObj['state'],
"talentString" => $talentString

);

	
}
	
	
	

echo json_encode(array($resultObj, $userResult, $jsonCollabs, $totalCollabs));
	
	
}else{
echo "end";
}
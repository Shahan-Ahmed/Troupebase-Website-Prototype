<?php
require_once("..classes/post.class.php");
if(isset($_POST['isWebsite'])){
$postID = $_POST['postID'];
}else{

}
<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}

$json = array();
$userObj = new User();




$userResult = $userObj->getProfile($user);// USERS TABLE



//GET BLOCKED INFO
$isBlocked = 0;
$didBlock = 0;
$blockedResult = $userObj->getBlockedStatus($userLoggedIn, $user);
foreach($blockedResult AS $blocked){
if($blocked['userA'] == $userLoggedIn){
$isBlocked = 1;
}
if($blocked['userB'] == $userLoggedIn){
$didBlock = 1;
}
}




$talentResult = $userObj->getTalents($user);//TALENTS TABLE
$resultCheck = count($userResult);

if($resultCheck <= 1){
echo "end";
exit();
}




//TROUPE STATUS
$troupeStatus = "none";
$ifTroupes = $userObj->checkIfTroupes($userLoggedIn, $userResult['id']);
$troupeStatus = $ifTroupes;
if($troupeStatus == "none"){
$ifTrSentOrRec = $userObj->isTroupeRequestSentOrRec($userLoggedIn, $userResult['id']);
$troupeStatus = $ifTrSentOrRec;
}


if($troupeStatus == "error"){
echo "end";
exit();
}






$talentString = "";// TALENT STRING
foreach($talentResult as $talent){
$talentString = $talentString. " " . $talent['talent'];
}






echo json_encode(array($userResult, $talentString, $troupeStatus, $isBlocked, $didBlock));






<?php
require_once("../classes/project.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$projectID = $_POST['projectID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();

$projectObj = new Project();
$userObj = new User();
$response = $projectObj->getProjectResponse($userLoggedIn, $projectID);
if($response == ""){
echo "not found";
exit();
}

//DATE TIME
$dateTime = $project['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);

$userID = $response['user'];

$user = $userObj->getUser($userID);

//TALENTS
$talentString = "";//TALENT STRING
$talentsResult = $userObj->getTalents($userID);
foreach($talentsResult as $talent){
$talentString = $talentString." ".$talent['talent'];
}

$owner = false;
if($userLoggedIn == $userID){
$owner = true;
}



echo json_encode(array($response, $user, $talentString, $dateTime, $owner));
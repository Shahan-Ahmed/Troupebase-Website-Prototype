<?php
require_once("../classes/user.class.php");
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['id'];
$start = $_POST['start'];
$getProjectAlso = $_POST['getProjectAlso'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}



//OBJECTS
$userObj = new User();
$postObj = new Post();



//Jsons
$jsonProject = array();
$jsonResponses = array();


//GET THE PROJECT
if($getProjectAlso == 1){
$post = $postObj->getAProjectGoal($userLoggedIn, $id);
	
//GET USER
$userObj = new User();
$userResults = $userObj->getUser($userLoggedIn);	

$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
$smallimage = $post['smallimage'];
	
$jsonProject[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state']
);	
	
}







//GET RESPONSES
$responseObj = $postObj->getProjectResponses($start, $id);
if(count($responseObj) == 0){
$jsonResponses == "end";
}




foreach($responseObj AS $response){

$dateTime = $response['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
	
//GET USER
$userResults = $userObj->getUser($response['user']);	
	
$jsonResponses[] = array(
	
"id" => $response['id'],
"projectID" => $response['projectID'],
"viewed" => $response['id'],
"message" => $response['message'],
"userObj" => $userResults,
"dateTime" => $dateTime
	
);

	
}







echo json_encode(array($jsonProject, $jsonResponses));





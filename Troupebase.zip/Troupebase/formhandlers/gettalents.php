<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
}else{

}

$data = array();

$userObj = new User();
$talents = $userObj->getTalents($user);


foreach($talents as $talent){

$data[] = array(
"talent" => $talent
);
	
}


echo json_encode($data);
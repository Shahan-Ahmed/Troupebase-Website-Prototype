<?php
require_once("../classes/troupes.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


//OBJECTS
$troupesObj = new Troupes();
$userObj = new User();





$json = array();





$troupesResult = $troupesObj->getTroupes($user, $start); //TROUPES RESULT
if($troupesResult == "error"){
echo "error";
exit();
}


$resultCheck = count($troupesResult);
if($resultCheck == 0){
echo "end";	
exit();
}






//FOR EACH CONNECTED TROUPE
foreach($troupesResult as $troupe){
	
	
if($troupe['userA'] == $user){
$userToGet = $troupe['userB'];
}else{
$userToGet = $troupe['userA'];
}	

	
$userResult = $userObj->getUser($userToGet);//USER RESULT
	

	
	
	
$json[] = array(
	
"id" => $troupe['userB'],
"user" => $userResult,
"userToGet" => $userToGet,
"uli" => $userLoggedIn,
"forUser" => $user
); 	

	
	
	
	
}


echo json_encode($json);






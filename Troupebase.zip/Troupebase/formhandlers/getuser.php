<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
}else{

}


$userObj = new User(); 
$resultObj = $userObj->getUser($user);


echo json_encode($resultObj);
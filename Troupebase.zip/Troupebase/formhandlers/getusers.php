<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


$userObj = new User();

$usersResults = $userObj->getusers($userLoggedIn, $user, $start);
$resultCheck = count($usersResults);
if($resultCheck == 0){
echo "end";
	exit();
}


$json = array();



foreach($usersResults as $user)
{

$id = $user['id'];//TROUPE ID

$talentString = "";//TALENT STRING
$talentsResult = $userObj->getTalents($id);
foreach($talentsResult as $talent){
$talentString = $talentString." ".$talent['talent'];
}
	
$json[] = array(

"id" => $id,
"name" => $user['name'],
"talentString" => $talentString,
"profilePic" => $user['profilePic'],
"state" => $user['state'],
"lastOnline" => $user['lastOnline'],
"photoFilter" => $user['photoFilter']
	
); 	

	
	
	
	
	

}

echo json_encode($json);
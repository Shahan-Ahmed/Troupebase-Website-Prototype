<?php
if(isset($_POST['isWebsite'])){
$userToSearch = $_POST['user'];
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}
require_once("../classes/user.class.php");

$userObj = new User();
$resultObj = $userObj->getUsersToTag($userLoggedIn, $userToSearch, $start);

$rescultCheck = count($resultObj);

if($rescultCheck === 0){
echo "";
exit();
}


$json = array();

foreach($resultObj as $user){

$troupeID = $user['id'];
$name = $user['name'];
$talent = $user['talent'];
$alias = $user['alias'];	
$profilePic = $user['profilePic'];
if($profilePic ==""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
$state = $user['state'];	
$talentString = "";	
	
	
$talents = $userObj->getTalents($troupeID);
	

foreach($talents as $talent){
$talentString = $talentString.$talent['talent']." ";
}
	
	
$json[] = array(
'troupeID' => $troupeID,
'name' => $name,
'talent' => $talentString,
'alias' => $alias,
'profilePic' => $profilePic,
'state' => $state
);
	


}


echo json_encode($json);

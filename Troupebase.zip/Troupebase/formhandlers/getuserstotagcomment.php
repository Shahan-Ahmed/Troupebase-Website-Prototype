<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$user = $_POST['user'];
$start = $_POST['start'];
}else{

}


$user = str_replace("@", "", $user);
$json = array();

$userObj = new User();
$resultObj = $userObj->getUsersToTagComment($user, $start);
$resultCheck = count($resultObj);
if($resultCheck > 0){
foreach($resultObj as $u){
$blockedStatus = $userObj->getBlockedStatus($userLoggedIn, $u['id']);
$resultCheckBlock = count($blockedStatus);	
if($resultCheckBlock == 0){
$talentString = "";
$talents = $userObj->getTalents($u['id']);

foreach($talents as $talent){
$talentString = $talentString.$talent['talent']." ";
}
	

$profilePic = $u['profilePic'];
if($u['profilePic'] == ""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
	
$json[] = array(

"troupeID" => $u['id'],
"name" => $u['name'],
"alias" => $u['alias'],
"state" => $u['state'],
"profilePic" => $profilePic,
"talent" => $talentString

);
	
	
	
}	
}
echo json_encode($json);	
}



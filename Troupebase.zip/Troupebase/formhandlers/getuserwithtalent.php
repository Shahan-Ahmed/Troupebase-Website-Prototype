<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();

$userObj = new User();

$user = $userObj->getUser($user);


$talentString = "";//TALENT STRING
$talentsResult = $userObj->getTalents($user['id']);
foreach($talentsResult as $talent){
$talentString = $talentString." ".$talent['talent'];
}


echo json_encode(array($user, $talentString));
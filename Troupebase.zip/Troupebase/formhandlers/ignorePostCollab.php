<?php
require_once("../classes/notifications.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
$noteID = $_POST['noteID'];
$postID = $_POST['postID'];
$userFrom = $_POST['userFrom'];
$postDate = $_POST['postDate'];
}else{
$post = json_decode(file_get_contents("php://input"));
$userLoggedIn = $post->userLoggedIn;
}



$noteObj = new Notification();


$delete = $noteObj->deleteNotification($noteID, $userFrom);


echo $delete;
<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['id'];
$projectID = $_POST['projectID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}




$postObj = new Post();

//DELETE RESPONSE
$ignoreResponse = $postObj->ignoreProjResp($id, $projectID);

echo $ignoreResponse;
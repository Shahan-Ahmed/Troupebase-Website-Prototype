<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$postID = $_POST['postID'];
$likeorunlike = $_POST['likeOrUnlike'];
}else{

}

$postObj = new Post();
$checLikeResponse = $postObj->checklike($userLoggedIn, $postID);//CHECK LIKED

//LIKE
if($likeorunlike == "like"){
if($checLikeResponse == "")
{
$resultObj = $postObj->like($userLoggedIn, $postID);
}
}


//UNLIKE
if($likeorunlike == "unlike"){
if($checLikeResponse !== "")
{
$resultObj = $postObj->unlike($userLoggedIn, $postID);
}
}
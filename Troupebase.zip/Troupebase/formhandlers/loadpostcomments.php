<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$postID = $_POST['postID'];
$start = $_POST['start'];
}else{

}

$timeZone = $_COOKIE['TimeZone'];
date_default_timezone_set($timeZone);
$userLoggedIn = $_COOKIE['TroupeBaseID'];


$postObj = new Post();
$commentResult = $postObj->getComments($userLoggedIn, $postID, $start);
$resultCheck = count($commentResult);

if($resultCheck == 0){
echo "end";
exit();
}





$json = array();
foreach($commentResult as $comment){

$user = $comment['user'];
	
$userObj = new User();
$userResult = $userObj->getUser($user);
	
$dateTime = $comment['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);	
	
$profilePic = $userResult['profilePic'];
if($profilePic ==""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
	
$talentString = "";
$talentResult = $userObj->getTalents($user);
foreach($talentResult as $talent){
$talentString = $talentString. " " .$talent['talent'];
}
	
	
$json[] = array(
'id' => $comment['id'],
'postID' => $postID,
'user' => $comment['user'],
'userLoggedIn' => $userLoggedIn,
'profilePic' => $profilePic,
'name' => $userResult['name'],
'photoFilter' => $userResult['photoFilter'],
'talents' => $talentString,
'comment' => $comment['details'],
'tagged' => $comment['tagged'],
'dateTime' => $dateTime
);	

	

}



echo json_encode($json);








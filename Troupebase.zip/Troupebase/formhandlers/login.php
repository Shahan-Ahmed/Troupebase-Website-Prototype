<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$email = $_POST['email'];
$password = $_POST['password'];
$device = $_POST['device'];
}else{

}

$json = array();




$userObj = new User();
$emailExist = $userObj->checkUserEmailExist($email);
$resultCheckEmail = count($emailExist);

if($emailExist==""){
echo "not found";
	exit();
}





$hashedPassword = $emailExist['password'];
$userEmail = $emailExist['email'];
$TroupeBaseID = $emailExist['id'];//TROUPEBASE ID
$sessionID = time();

if(password_verify($password, $hashedPassword)){
	
$insertSession = $userObj->insertsession($TroupeBaseID, $device, $sessionID, $email);	
if($insertSession == "success"){

	$userResult = $userObj->getUserLoggedIn($email);

	echo json_encode(array($userResult,$sessionID));
	
	
	
}else{
echo "failed";
}
	
}else{
echo "wrong password";
}
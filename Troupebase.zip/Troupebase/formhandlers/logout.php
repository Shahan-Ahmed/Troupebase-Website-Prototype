<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_POST['TroupeBaseID'];
$sessionID = $_POST['SessionID'];
$device = $_POST['device'];
}else{

}

$userObj = new User();
$logout = $userObj->logout($userLoggedIn, $sessionID);

echo $logout;
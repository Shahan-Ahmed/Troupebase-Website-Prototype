<?php
require_once("../classes/project.class.php");
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];

}else{

}


$postObj = new Post();
$projectObj = new Project();
$userObj = new User();
$json = array();


//FIND RESPONSES
$responses = $projectObj->getMyResponses($userLoggedIn, $start);
if(count($responses) == 0){
echo "end";
exit();
}


foreach($responses as $response){
$projectID = $response['projectID']; //PROJECT ID
	
	
//GET THE PROJECT
$post = $postObj->getAProjectGoal($userLoggedIn, $projectID);
	
	
//GET USER
$userObj = new User();
$userResults = $userObj->getUser($post['user']);
	
	
$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);	
	
	

$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $projectID,
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"myResponse" => $response['message'],
"responseStatus" => 0,
"totalApplicants" => 0,
"for" => 0
);		
	
	
	
	
	
}


echo json_encode($json);








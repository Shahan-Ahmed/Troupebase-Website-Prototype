<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$start = $_POST['start'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}



$postObj = new Post();
$projObj = new Project();
$json = array();


$projectResults = $postObj->getProjectGoalsAll($userLoggedIn, $start);
if(count($projectResults) == 0){
echo "end";
exit();
}





foreach($projectResults as $post)
{
	
//GET USER
$userObj = new User();
$userResults = $userObj->getUser($post['user']);	
	
	
	
	
	
//CHECK APPLIED
$checkApplied = $projObj->checkIfResponseSent($userLoggedIn, $post['id']); 
	
	

$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
$smallimage = $post['smallimage'];
	
$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"responseStatus" => $checkApplied
);	
	
}


echo json_encode($json);







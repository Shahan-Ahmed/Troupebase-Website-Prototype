<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];//USERLOGGEDIN
$caption = $_POST['caption'];//CAPTION
$optionalPostLink = $_POST['optionalPostLink'];//LINK
$taggedString = $_POST['taggedString'];//TAGGED STRING
$workedWithString = $_POST['workedWithString'];//WORKED WITH STRING
$filter = $_POST['filter'];
$imageBase64 = $_POST['audioCover'];
$videoFit = "null";//VIDEO FIT
}else{

}



$date = time();//DATE
$uniqueID = $userLoggedIn.time();//UNIQUE ID
$caption = substr($caption, 0, 3000);//CAPTION
$type = "a";//TYPE


if($_FILES['fileToAddToPortfolio']['name'] !==''){
$filenewName = $_FILES['audioFile']['name'];
$filenewTmpName = $_FILES['audioFile']['tmp_name'];
$filenewSize = $_FILES['audioFile']['size'];
$filenewError = $_FILES['audioFile']['error'];
$filenewType = $_FILES['audioFile']['type'];	
if($filenewSize > 60000000){
echo "error";
exit();
}
	
	
$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
$allowed = array('wav','mp3','m4a');		
	
if(in_array($filenewfileActualExt, $allowed)){		
if($filenewError == 0){			
	
$fileName = $userLoggedIn.$date.".".$filenewfileActualExt;	
$fileNameMp3 = "../userUploads/posts/".$userLoggedIn.$date.".mp3";
$fileNameNewVideo = "../userUploads/posts/".$fileName;//NEW FILE NAME
$fileDestDBVideo = 'https://troupebase.com/userUploads/posts/'.$fileName;//FILE DESTINATION DATABASE
	
$bitrate = "128k";
$output = "/usr/bin/ffmpeg -i $filenewTmpName -b:a $bitrate -map a $fileNameMp3";	
	
system($output);	
	
if(file_exists($fileNameMp3)){	

$image = imagecreatefrompng($imageBase64);
$fileCover = "../userUploads/posts/".$userLoggedIn.$date.".jpg";
$fileDB = "https://troupebase.com/userUploads/posts/".$userLoggedIn.$date.".jpg";
$cover = $fileDB; //COVER DB
imagejpeg($image, $fileCover, 80);
imagedestroy($image);

if(!file_exists($fileCover)){
echo "error";
exit();
}
	
	
$postObj = new Post();
$resultObj = $postObj->insertPost($uniqueID, $userLoggedIn, $fileDestDBVideo, $caption, $type, $filter, $fileDB, $videoFit, $taggedString, $optionalPostLink);
	
	
	
//TAGS
if($taggedString !== ""){

$insertCaptionsTags = $postObj->insertCaptionTags($userLoggedIn, $uniqueID, $type, $taggedString);
	
}



//WORKED WITH
if($workedWithString !== ""){

$insertCaptionsTags = $postObj->insertWorkedWithNotification($userLoggedIn, $uniqueID, "ww", $workedWithString);
	
}	
	
	
//SUCCESS	
if($resultObj == "success"){

	
	

	   $json = array(
        'postID' => $uniqueID,
        'coverPhoto' => $cover,
	   	'filter' => $filter,
	  	'type' => $type
    );


	echo json_encode($json);
	
	
	
	
}else{
echo "error";
}
	
	
}else{
echo "error";
}	
}else{
echo "error";
}
}else{
echo "error";
}
}else{
echo "error";
}



<?php
require_once("../classes/post.class.php");
require_once("../classes/notifications.class.php");
if(isset($_POST['isWebsite'])){
$commentID = $_POST['commentID'];
$postID = $_POST['postID'];
$user = $_POST['user'];
$body = $_POST['body'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

	
}
date_default_timezone_set($timeZone);
$date = time();//DATE
$dateTime = date('h:i A m-d-Y', $date);

$postObj = new Post();
$PostCommentReplyResult = $postObj->postCommentReply($userLoggedIn, $commentID, $postID, $body, $date);
if($PostCommentReplyResult == "error"){
echo "error";
exit();
}




if($PostCommentReplyResult == "success"){
$json = array(
"date" => $date,
"dateTime" => $dateTime,
"body" => $body
);
	
echo json_encode($json);	
	
	
	
	
	
	
	
//INSERT NOTIFICATION	
if($userLoggedIn !== $user){
$noteObj = new Notification();
$insert = $noteObj->insertCommentReply($commentID, $postID, $user, $body, $userLoggedIn, $date);
}
	
	
	
	
	
	
	
	
	
}else{
echo "failed";
}

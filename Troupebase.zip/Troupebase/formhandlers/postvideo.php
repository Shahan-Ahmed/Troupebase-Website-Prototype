<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];//USERLOGGEDIN
$thumbTime = $_POST['thumbTime'];
$caption = $_POST['caption'];//CAPTION
$optionalPostLink = $_POST['optionalPostLink'];//LINK
$taggedString = $_POST['taggedString'];//TAGGED STRING
$workedWithString = $_POST['workedWithString'];//WORKED WITH STRING
$filter = $_POST['filter'];
$videoFit = $_POST['videoFit'];
}else{

}

$date = time();//DATE
$uniqueID = $userLoggedIn.time();//UNIQUE ID
$caption = substr($caption, 0, 3000);//CAPTION
$type = "v";//TYPE

if($_FILES['fileToAddToPortfolio']['name'] !==''){
$filenewName = $_FILES['video']['name'];
$filenewTmpName = $_FILES['video']['tmp_name'];
$filenewSize = $_FILES['video']['size'];
$filenewError = $_FILES['video']['error'];
$filenewType = $_FILES['video']['type'];	
	
if($filenewSize > 393216000){
exit();
}
	
$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
	
$allowed = array('mov','ogg','webm','mp4');		
	
if(in_array($filenewfileActualExt, $allowed)){			
if($filenewError == 0){		
	
$fileName = $userLoggedIn.$date.".".$filenewfileActualExt;	
$fileNameNewVideo = "../userUploads/posts/".$fileName;//NEW FILE NAME
$fileDestDBVideo = 'https://troupebase.com/userUploads/posts/'.$fileName;//FILE DESTINATION DATABASE	
	
$bitrate = "1200k";
$output = "/usr/bin/ffmpeg -i $filenewTmpName -b:v $bitrate -bufsize $bitrate $fileNameNewVideo";		
	
system($output);	
	
if(file_exists($fileNameNewVideo)){	
	
$thumbLocation = "../userUploads/posts/".$userLoggedIn.$date.".jpg";
$thumbLocationDB = "https://troupebase.com/userUploads/posts/".$userLoggedIn.$date.".jpg";
	
$thumb = "/usr/bin/ffmpeg -ss $thumbTime -i $fileNameNewVideo -vframes 1 -q:v 2 $thumbLocation";
system($thumb);	

if(file_exists($thumbLocation)){


$postObj = new Post();
$resultObj = $postObj->insertPost($uniqueID, $userLoggedIn, $fileDestDBVideo, $caption, $type, $filter, $thumbLocationDB, $videoFit, $taggedString, $optionalPostLink);	
	
if($resultObj == "error")
{
echo "error";
exit();
}
	
		
	
//TAGS
if($taggedString !== ""){

$insertCaptionsTags = $postObj->insertCaptionTags($userLoggedIn, $uniqueID, $type, $taggedString);
	
}
	
	
//WORKED WITH
if($workedWithString !== ""){

$insertCaptionsTags = $postObj->insertWorkedWithNotification($userLoggedIn, $uniqueID, "ww", $workedWithString);
	
}

		
	if($resultObj == "success"){
	
	$json = array(
        'postID' => $uniqueID,
        'coverPhoto' => $thumbLocationDB,
	   	'filter' => $filter,
	  	'type' => $type
    );
	echo json_encode($json);
		
		
	}else{
	echo "error";
	}
		
		
}else{
echo "error";
}
}else{
echo "error";
}	
}else{
echo "error";
}	
}else{
echo "error";
}	
}else{
echo "error";
}



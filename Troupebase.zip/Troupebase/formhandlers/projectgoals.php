<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$json = array();


$projObj = new Project();
$postObj = new Post();


if($user == $userLoggedIn){
$for = 'me';
$responseObj = $postObj->getProjectGoalsByLastApplied($user, $userLoggedIn, $start);
}else{
$for = 'others';
$responseObj = $postObj->getProjectGoals($user, $userLoggedIn, $start);
}


$resultCheck = count($responseObj);

//IF NO RESULTS
if($resultCheck == 0){
echo "end";
exit();
}





//GET USER
$userObj = new User();
$userResults = $userObj->getUser($user);



foreach($responseObj as $post)
{

	
//CHECK APPLIED
$checkApplied = $projObj->checkIfResponseSent($userLoggedIn, $post['id']); 	

//GET TOTAL APPLICANTS
$totalApplicants = $projObj->getTotalResponses($post['id']);	
	
	
$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
	
$smallimage = $post['smallimage'];
	
$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"responseStatus" => $checkApplied,
"totalApplicants" => $totalApplicants,
"for" => $for
);	
	
}


echo json_encode($json);
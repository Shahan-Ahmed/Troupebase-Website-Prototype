<?php
require_once("../classes/project.class.php");
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$city = $_POST['city'];
$state = $_POST['state'];
$country = $_POST['country'];
$details = $_POST['details'];
$subject = $_POST['subject'];
$selectedTalentsPG = $_POST['selectedTalentsPG'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$userLoggedInTalents = $_POST['userLoggedInTalents'];
}else{

}



$timeZone = $_COOKIE['TimeZone'];
date_default_timezone_set($timeZone);

$uniqueID = $userLoggedIn.time();

$projectObj = new Project();
$postObj = new Post();
$userObj = new User();


$dateTime = time();
$dateTime = date('h:i A m-d-Y', $dateTime);	


//INSERT PROJECT GOAL
$insertProject = $projectObj->insertProject($uniqueID, $userLoggedIn, $city, $state, $country, $subject, $details, $selectedTalentsPG, $userLoggedInTalents);



if($insertProject == "error"){
echo "error";
exit();
}


$json = array();

//GET PROJECT
$post = $postObj->getAProjectGoal($userLoggedIn, $uniqueID);


//GET USER
$userObj = new User();
$userResults = $userObj->getUser($userLoggedIn);	


$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
$smallimage = $post['smallimage'];


$jsonProject[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"responseStatus" => 0,
"totalApplicants" => 0
);	


echo json_encode($jsonProject);

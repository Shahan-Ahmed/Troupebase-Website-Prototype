<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$talent = $_POST['selection'];
}else{

}
$userLoggedIn = $_COOKIE['TroupeBaseID'];


$userObj = new User();
$result = $userObj->removTalent($userLoggedIn, $talent);

if($result == "success"){
echo $userLoggedIn;
}else{
echo "error";
}
<?php
require_once("../classes/notifications.class.php");
if(isset($_POST['isWebsite'])){
$notificationID = $_POST['notificationID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

	
}
date_default_timezone_set($timeZone);
$date = time();//DATE


$notificationObj = new Notification();
$report = $notificationObj->reportNotification($userLoggedIn, $notificationID);

echo $report;
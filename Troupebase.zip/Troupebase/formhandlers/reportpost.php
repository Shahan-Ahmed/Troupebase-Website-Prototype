<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$id = $_POST['id'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);


$postObj = new Post();
$reportResult = $postObj->reportpost($id, $userLoggedIn);


echo $reportResult;
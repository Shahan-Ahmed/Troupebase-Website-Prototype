<?php
require_once("../classes/message.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['id'];
$message = $_POST['message'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


$messageObj = new Message();

$uniqueID = $userLoggedIn.time();
$dateTime = time();
$usersArray = array($userLoggedIn, $id);


//CHECK IF ALREADY CHATTING
$alreadyChatting = $messageObj->checkIfAlreadyChatting($userLoggedIn, $id);


//LOAD CONVO IF ALREADY CHATTING
$currentChatID;
if(count($alreadyChatting)>0){
foreach($alreadyChatting as $currentChat){
$currentChatID = $currentChat['chatID'];
}
echo $currentChatID;
exit();
}





//INSERT NEW CHAT
$insertSuccess = 1;
$insert = $messageObj->insertNewMessage($userLoggedIn, $id, $uniqueID, $dateTime);



//INSERT MESSAGE
if($insert == "success"){
$addMessage = $messageObj->addMessage($userLoggedIn, $uniqueID, $message, $dateTime);
echo $addMessage;
}else{
echo "error";
}






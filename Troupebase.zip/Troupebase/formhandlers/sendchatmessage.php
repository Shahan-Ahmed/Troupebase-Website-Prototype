<?php
require_once("../classes/message.class.php");
if(isset($_POST['isWebsite'])){
$id = $_POST['id'];
$message = $_POST['message'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}
$dateTime = time();
date_default_timezone_set($timeZone);

$uniqueID = $userLoggedIn.time();

$json = array();


$messageObj = new Message();

$send = $messageObj->send($uniqueID, $userLoggedIn, $id, $message, $dateTime);

$unix = $dateTime;
$dateTime = $dateTime;
$dateTime = date('h:i A m-d-Y', $dateTime);	

if($send == "success"){
$json = array();
	
$json[] = array(

"id" => $uniqueID,
"body" => $message,
"dateTime" => $dateTime,
"userFrom" => $userLoggedIn,	
"viewed" => 0,
"file" => "null",
"filePreview" => "null",
"type" =>""
);	
	
	echo json_encode($json);
	
	
	
	//UPDATE LAST MESSAGE DATE
	$update = $messageObj->updateLastMessageDate($id, $unix);

	
}else{
echo "error";
}
<?php
require_once("../classes/project.class.php");
if(isset($_POST['isWebsite'])){
$projectID = $_POST['projectID'];
$message = $_POST['message'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}


date_default_timezone_set($timeZone);
$date = time();

$obj = new Project();

//CHECK APPLIED
$checkApplied = $obj->checkIfResponseSent($userLoggedIn, $projectID); 
if($checkApplied>0){
echo "already applied";
exit();
}




$insert = $obj->insertProjectResponse($userLoggedIn, $projectID, $date, $message);



echo $insert;

if($insert == "success"){
$updateLastApplied = $obj->updateProjectLastApplied($date, $projectID);
}
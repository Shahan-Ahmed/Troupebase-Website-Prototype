<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}
date_default_timezone_set($timeZone);
$date = time();


//OBJ
$userObj = new User();



//CHECK IF ALREADY SENT
$ifAlreadySent = $userObj->isTroupeRequestSentOrRec($userLoggedIn, $user);
if($ifAlreadySent == "sent"){
echo "sent";
exit();
}




//IF TROUPE REQUEST ALREADY RECEIVED
if($ifAlreadySent == "received"){
$addToTroupes = $userObj->addToTroupes($userLoggedIn, $user, $date);	
if($addToTroupes == "success"){
echo "youAreNowTroupes";
}else{
echo "error";
}	
exit();
}



//SEND THE TROUPE REQUEST IF NONE OF THE ABOVE FIRST
$sendTroupeRequest = $userObj->sentTroupeRequest($userLoggedIn, $user, $date);	
if($sendTroupeRequest == "success"){
echo "sent";
}else{
echo "error";
}






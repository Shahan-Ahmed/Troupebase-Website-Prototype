<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$audio = $_POST['audio'];
$caption = $_POST['caption'];
$optionalPostLink = $_POST['optionalLink'];
$workedWithString = $_POST['workedWithString'];
$taggedString = $_POST['taggedString'];
$audioCover = $_POST['audioCover'];
$coverExt = $_POST['coverExt'];
$ext = $_POST['ext'];
$partOfPortfolio = $_POST['partOfPortfolio'];
$originalOrCrop = $_POST['originalOrCrop'];
$filter = $_POST['selectedFilter'];
$addToPortfolio = $_POST['addToPortfolio'];
$videoFit = "null";//VIDEO FIT
$city = $_POST['shareCity'];
$state = $_POST['shareState'];
$country = $_POST['shareCountry'];
$userTalents = $_POST['userTalents'];
}


$date = time();//DATE
$uniqueID = $userLoggedIn.time();//UNIQUE ID
$caption = substr($caption, 0, 3000);//CAPTION
$type = "a";//TYPE
$smallImageDestinationDB = "";


$userObj = new User();







//RESIZE FUNCTION
function resize_image($file, $max_resolution, $coverExt){
if($coverExt == "jpg" || $coverExt == "jpeg"){
$original_image = imagecreatefromjpeg($file);
}
if($coverExt == "png"){
$original_image = imagecreatefrompng($file);
}
	
//RESOLUTION
$original_width = imagesx($original_image);
$original_height = imagesy($original_image);

	
if($original_width > 600 || $original_height > 600){
//TRY WIDTH FIRST
$ratio = $max_resolution / $original_width;
$new_width = $max_resolution;
$new_height = $original_height * $ratio;
	
	
//if that didnt work
if($new_height > $max_resolution){
$ratio = $max_resolution / $original_height;
$new_height = $max_resolution;
$new_width = $original_width * $ratio;
}
	
	
if($original_image){
	
$new_image = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($new_image, $original_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
imagejpeg($new_image, $file, 90);	
	
if(file_exists($file)){
}else{
echo "error13";
exit();
}	
	
}	
}
}
//
















//CREATE TINY IMAGE FUNCTION
function createSmallImage($file, $max_resolution, $coverExt, $userLoggedIn, $date){
	
$smallImageDestination = "../userUploads/tinyimage/".$userLoggedIn.$date.".jpg";
$smallImageDestinationDB = "https://troupebase.com/userUploads/tinyimage/".$userLoggedIn.$date.".jpg";	
	
$original_image = imagecreatefromjpeg($file);
if($ext == "jpg" || $ext == "jpeg"){
$original_image = imagecreatefromjpeg($file);
}
if($ext == "png"){
$original_image = imagecreatefrompng($file);
}

//RESOLUTION
$original_width = imagesx($original_image);
$original_height = imagesy($original_image);
	
if($original_width > 400 || $original_height > 400){
//TRY WIDTH FIRST
$ratio = $max_resolution / $original_width;
$new_width = $max_resolution;
$new_height = $original_height * $ratio;
	
	
//if that didnt work
if($new_height > $max_resolution){
$ratio = $max_resolution / $original_height;
$new_height = $max_resolution;
$new_width = $original_width * $ratio;
}

if($original_image){
	
$new_image = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($new_image, $original_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
	
if(imagejpeg($new_image, $smallImageDestination, 90)){
return $smallImageDestinationDB;
}else{
return "error";
}
	
}else{
return "error";
}	
}else{
$smallImageDestinationDB = "";
return $smallImageDestinationDB;
}
}















//RESIZE ORIGINAL
if($originalOrCrop == "original"){
if($_FILES['selectedCoverForAudio']['name'] !==''){
$filenewName = $_FILES['audioCover']['name'];
$filenewTmpName = $_FILES['audioCover']['tmp_name'];
$filenewSize = $_FILES['audioCover']['size'];
$filenewError = $_FILES['audioCover']['error'];
$filenewType = $_FILES['audioCover']['type'];	
//FILE SIZE CHECK
if($filenewSize > 16000000){
echo "fstl";
exit();
}	
$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
$allowed = array('jpg', 'jpeg', 'png');
if(in_array($filenewfileActualExt, $allowed)){		
if($filenewError == 0){				
	
$filename = $userLoggedIn.$date.".".$filenewfileActualExt;	
$file = '../userUploads/posts/'.$filename;	//COVER
$fileDB = "https://troupebase.com/userUploads/posts/".$filename;
move_uploaded_file($filenewTmpName, $file);		
	
if($filenewfileActualExt =='jpeg' OR $filenewfileActualExt =='jpg'){	
	
	
$exif = exif_read_data($file);	
if (!empty($exif['Orientation'])){
$image = imagecreatefromjpeg($file);

switch ($exif['Orientation']) {

case 3:
$image = imagerotate($image, 180, 0);
break;

case 6:
$image = imagerotate($image, -90, 0);
break;

case 8:
$image = imagerotate($image, 90, 0);
break;		
		
}	
	
imagejpeg($image, $file, 75);
	
}		
}
	

//CALL RESIZE FUNCTION
$resize = resize_image($file, "600", $coverExt);	
	
		
}else{
echo "error10";
exit();
}	
}else{
echo "error9";
exit();
}
}else{
echo "error8";
exit();
}
}







//CREATE COVER FROM BASE64
if($originalOrCrop == "croppie"){
$image = imagecreatefrompng($audioCover);
$file = "../userUploads/posts/".$userLoggedIn.$date.".jpg";
$fileDB = "https://troupebase.com/userUploads/posts/".$userLoggedIn.$date.".jpg"; //COVER
imagejpeg($image, $file, 100);
imagedestroy($image);
if(file_exists($file)){
}else{
echo "error7";
exit();
}
}
























//CHECK IF FILE EXISTS AND CONTINUE
if(file_exists($file)){
	
//CREATE SMALL IMAGE
$smallImage = createSmallImage($file, "400", "jpg", $userLoggedIn, $date);	
if($smallImage == "error"){
echo "error";
exit();
}	
	

if($_FILES['fileToShare']['name'] !==''){
$filenewName = $_FILES['audio']['name'];
$filenewTmpName = $_FILES['audio']['tmp_name'];
$filenewSize = $_FILES['audio']['size'];
$filenewError = $_FILES['audio']['error'];
$filenewType = $_FILES['audio']['type'];	
if($filenewSize > 60000000){
echo "error6";
exit();
}
	
$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
$allowed = array('wav','mp3','m4a');	
	
if(in_array($filenewfileActualExt, $allowed)){			
if($filenewError == 0){				
	
$fileName = $userLoggedIn.$date.".".$filenewfileActualExt;	
$fileNameMp3 = "../userUploads/posts/".$userLoggedIn.$date.".mp3";
$fileDestDBVideo = 'https://troupebase.com/userUploads/posts/'.$userLoggedIn.$date.".mp3";//FILE DB
	
$bitrate = "96k";
$output = "/usr/bin/ffmpeg -i $filenewTmpName -b:a $bitrate -map a $fileNameMp3";	
system($output);	
	
if(file_exists($fileNameMp3)){		

	
//INSERT POST
$postObj = new Post();
$resultObj = $postObj->insertPost($uniqueID, $userLoggedIn, $fileDestDBVideo, $caption, $type, $filter, $fileDB, $videoFit, $taggedString, $optionalPostLink, $smallImage, $city, $state, $country, $userTalents);
		

//INSERT CAPTIONS TAGS
if($taggedString !== ""){
$insertCaptionsTags = $postObj->insertCaptionTags($userLoggedIn, $uniqueID, "captag", $taggedString);
}	
	
	
//WORKED WITH
if($workedWithString !== ""){
$insertCaptionsTags = $postObj->insertWorkedWithNotification($userLoggedIn, $uniqueID, "ww", $workedWithString);
}
	
	
	//GET POST
if($resultObj == "success"){

	
	
$json = array();	
	
$post = $postObj->getPost($uniqueID, $userLoggedIn);
	
//GET USER
$userObj = new User();
$userResults = $userObj->getUser($userLoggedIn);	

$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
$smallimage = $post['smallimage'];	
	
	
	
$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"responseStatus" => 0,
"totalApplicants" => 0
);	


echo json_encode($json);	
		
	
	
	
	
}else{
echo "error5";
exit();
}
	
	
		
	
	
	
}else{
echo "error4";
exit();
}
}else{
echo "error3";
exit();
}
}else{
echo "error2";
exit();
}
}

}



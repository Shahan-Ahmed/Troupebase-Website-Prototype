<?php
require_once("../classes/post.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$projectID = $_POST['projectID'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}

date_default_timezone_set($timeZone);
$date = time();

$postObj = new Post();

//CHECK SHARED
$checkShared = $postObj->checkAlreadyShared($userLoggedIn, $user, $projectID);
if($checkShared > 0){
echo "alreadyshared";
exit();
}



//INSERT SHARE
if($checkShared < 1){
$shareResult = $postObj->shareTheProject($userLoggedIn, $user, $projectID, $date);
echo $shareResult;
}else{
echo "success";
}

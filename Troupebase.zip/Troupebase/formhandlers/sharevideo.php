<?php
require_once("../classes/post.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];//USERLOGGEDIN
$video = $_POST['video'];
$thumbTime = $_POST['thumbTime'];
$caption = $_POST['caption'];//CAPTION
$optionalPostLink = $_POST['optionalPostLink'];//LINK
$taggedString = $_POST['taggedString'];//TAGGED STRING
$workedWithString = $_POST['workedWithString'];//WORKED WITH STRING
$filter = $_POST['selectedFilter'];
$videoFit = $_POST['videoFit'];
$partOfPortfolio = $_POST['partOfPortfolio'];
$city = $_POST['shareCity'];
$state = $_POST['shareState'];
$country = $_POST['shareCountry'];
$userTalents = $_POST['userTalents'];
}else{

}



$date = time();//DATE
$uniqueID = $userLoggedIn.time();//UNIQUE ID
$caption = substr($caption, 0, 3000);//CAPTION
$type = "v";//TYPE

$userObj = new User();




//CREATE TINY IMAGE FUNCTION
function createSmallImage($file, $max_resolution, $coverExt, $userLoggedIn, $date){
	
$smallImageDestination = "../userUploads/tinyimage/".$userLoggedIn.$date.".jpg";
$smallImageDestinationDB = "https://troupebase.com/userUploads/tinyimage/".$userLoggedIn.$date.".jpg";	
	
$original_image = imagecreatefromjpeg($file);
if($ext == "jpg" || $ext == "jpeg"){
$original_image = imagecreatefromjpeg($file);
}
if($ext == "png"){
$original_image = imagecreatefrompng($file);
}

//RESOLUTION
$original_width = imagesx($original_image);
$original_height = imagesy($original_image);
	
if($original_width > 400 || $original_height > 400){
//TRY WIDTH FIRST
$ratio = $max_resolution / $original_width;
$new_width = $max_resolution;
$new_height = $original_height * $ratio;
	
	
//if that didnt work
if($new_height > $max_resolution){
$ratio = $max_resolution / $original_height;
$new_height = $max_resolution;
$new_width = $original_width * $ratio;
}

if($original_image){
	
$new_image = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($new_image, $original_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
	
if(imagejpeg($new_image, $smallImageDestination, 90)){
return $smallImageDestinationDB;
}else{
return "error";
}
	
}else{
return "error";
}	
}else{
$smallImageDestinationDB = "";
return $smallImageDestinationDB;
}
}













if($_FILES['fileToShare']['name'] !==''){
$filenewName = $_FILES['video']['name'];
$filenewTmpName = $_FILES['video']['tmp_name'];
$filenewSize = $_FILES['video']['size'];
$filenewError = $_FILES['video']['error'];
$filenewType = $_FILES['video']['type'];	
if($filenewSize > 1073741824){
exit();
}


$filenewfileExt = explode('.', $filenewName);	
$filenewfileActualExt = strtolower(end($filenewfileExt));
	
$allowed = array('mov','ogg','webm','mp4');		
	
if(in_array($filenewfileActualExt, $allowed)){			
if($filenewError == 0){		

$fileName = $userLoggedIn.$date.".".$filenewfileActualExt;	
$fileNameNewVideo = "../userUploads/posts/".$fileName;//NEW FILE NAME
$fileDestDBVideo = 'https://troupebase.com/userUploads/posts/'.$fileName;//FILE DESTINATION DATABASE	
	
$bitrate = "1800k";
$output = "/usr/bin/ffmpeg -i $filenewTmpName -b:v $bitrate -bufsize $bitrate $fileNameNewVideo";	
	
	
system($output);	
if(file_exists($fileNameNewVideo)){	

//CREATE THUMB
$thumbLocation = "../userUploads/posts/".$userLoggedIn.$date.".jpg";
$thumbLocationDB = "https://troupebase.com/userUploads/posts/".$userLoggedIn.$date.".jpg";
	
$thumb = "/usr/bin/ffmpeg -ss $thumbTime -i $fileNameNewVideo -vframes 1 -q:v 2 $thumbLocation";
system($thumb);	
if(file_exists($thumbLocation)){	
	
	
	

//CREATE SMALL IMAGE
$smallImage = createSmallImage($thumbLocation, "400", "jpg", $userLoggedIn, $date);	
if($smallImage == "error"){
echo "error";
exit();
}	

	
	
	
//INSERT POST
$postObj = new Post();
$resultObj = $postObj->insertPost($uniqueID, $userLoggedIn, $fileNameNewVideo, $caption, $type, $filter, $thumbLocationDB, $videoFit, $taggedString, $optionalPostLink, $smallImage, $city, $state, $country, $userTalents);
	
	
//TAGS
if($taggedString !== ""){

$insertCaptionsTags = $postObj->insertCaptionTags($userLoggedIn, $uniqueID, "captag", $taggedString);
	
}



//WORKED WITH
if($workedWithString !== ""){

$insertCaptionsTags = $postObj->insertWorkedWithNotification($userLoggedIn, $uniqueID, "ww", $workedWithString);
	
}	
	
	
	
	
//GET POST
if($resultObj == "success"){

	
$json = array();	
	
$post = $postObj->getPost($uniqueID, $userLoggedIn);
	
//GET USER
$userObj = new User();
$userResults = $userObj->getUser($userLoggedIn);	

$dateTime = $post['dateTime'];
$dateTime = date('h:i A m-d-Y', $dateTime);
$smallimage = $post['smallimage'];	
	
	
	
$json[] = array(
"userLoggedIn" => $userLoggedIn,
"user" => $post['user'],
"id" => $post['id'],
"photo" => $post['file'],
"coverPhoto" => $post['coverPhoto'],
"type" => $post['type'],
"filter" => $post['filter'],
"caption" => $post['details'],
"subject" => $post['subject'],
"dateTime" => $dateTime,
"requiredTalent" => $post['requiredTalent'],
"userObj" => $userResults,
"smallimage" => $smallimage,
"city" => $post['city'],
"state" => $post['state'],
"responseStatus" => 0,
"totalApplicants" => 0
);	


echo json_encode($json);	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}else{
echo "error";
exit();
}
	
	
	
	
	
	
	
	
}else{
echo "error";
unlink($fileNameNewVideo);
exit();
}
}else{
echo "error";
exit();
}	
}else{
echo "error";
exit();
}	
}else{
echo "error"; 
exit();
}
}else{
echo "error";
exit();
}







<?php
require_once("../classes/user.class.php");
require_once("../classes/register.class.php");

if(isset($_POST['isWebsite'])){
$name = $_POST['Name'];
$name = substr($name, 0, 100);
$email = $_POST['Email'];
$email = substr($email, 0, 100);
$email = str_replace(" ", "", $email);
$pass = $_POST['Pass'];
$password = substr($pass, 0, 100);
$device = $_POST['device'];
}else{
$post = json_decode(file_get_contents("php://input"));
$name = $post->Name;
$name = substr($name, 0, 100);
$name = str_replace(" ", "", $name);
$email = $post->Email;
$email = substr($email, 0, 100);
$email = str_replace(" ", "", $email);
$pass = $post->Pass;
$password = substr($pass, 0, 100);
}



//CHECK PASSWORD LENGTH
$passlength = strlen($password);
if($passlength < 8){
echo "Password too short";
	exit();
}


//CHECK BLANKS
if($name == "" || $email == "" || $password == ""){
echo "ENTER ALL FIELDS";
	exit();
}





//VALIDATE EMAIL
if(!filter_var($email, FILTER_VALIDATE_EMAIL))
{
echo "INVALID EMAIL";
exit();
}







//CHECK EMAIL EXIST
$register = new Register();
$result = $register->checkexisting($email);
if(count($result) > 0)
{
  	 echo "EMAIL ALREADY IN USE";
	exit();
}



//HASH PASSWORD
$hashedPwd = password_hash($password, PASSWORD_DEFAULT);





//INSERT ACCOUNT
$insert = $register->createaccount($name, $email, $hashedPwd);





if($insert == "success"){
$userObj = new User();
	
	
$userResult = $userObj->getUserLoggedIn($email);

	
$TroupeBaseID = $userResult['id'];//TROUPEBASE ID
$sessionID = time();

//INSERT SESSION
$insertSession = $userObj->insertsession($TroupeBaseID, $device, $sessionID, $email);

if($insertSession == "success"){


	echo json_encode(array($userResult,$sessionID));
	
	
}else{
echo "failed";
}
	
}else{
echo "failed";
}
















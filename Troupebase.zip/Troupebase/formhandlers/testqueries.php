<?php
require_once("../classes/dbh.class.php");

class Quickquery extends Dbh{

public function addCollab($userID, $postID){
$date = time();
$sql = "INSERT INTO collabs(user, postID, dateTime) VALUES (?, ?, ?)";
$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$userID, $postID, $date]);
}
	
	
public function loopUserId(){
$sql = "SELECT id FROM users WHERE id != ? ORDER BY id DESC";
$stmt = $this->connect()->prepare($sql);
		$n = '';
		$stmt->execute([$n]);
$result = $stmt->fetchAll();
			return $result;
}

	
	public function foraddtotroupe($id, $idtwo){
	$sql = "INSERT INTO connectedTroupes (userA, userB, dateTime, viewed) VALUES (?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
	$n = '';
	$date = time();
	$stmt->execute([$id, $idtwo, $date, 0]);
	}
	
	
	public function forceAddSentTR($id, $idtwo){
	$sql = "INSERT INTO notifications (userFrom, userTo, dateTime, type, comment) VALUES (?, ?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
	$n = 'troupeRequest';
	$n1 = 'sent you troupe request';
	$date = time();
	$stmt->execute([$id, $idtwo, $date, $n, $n1]);
	}
	
	
	
	
	
	public function insertCountries($country){
		
		$sql = "INSERT INTO countries (name) VALUES (?)";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute([$country]);
	}
	
	
	
	
	public function getcountryids(){
		
		$sql = "SELECT id FROM countries WHERE id < ?";
		$stmt = $this->connect()->prepare($sql);
		if($stmt->execute([10000])){
		$result = $stmt->fetchAll();
			return $result;
		}
	}
	
	
	

	
	
	public function addStateNameToCities(){
	
		$sql = "SELECT name, countryID FROM countries WHERE id != ?";
		$stmt = $this->connect()->prepare($sql);
		$needle = '';
		if($stmt->execute([$needle])){
		$result = $stmt->fetchAll();
			
			
	foreach($result as $r){
		
	$countryName = $r['name'];
	$countryID = $r['countryID'];
		
		$sqlTwo = "UPDATE cities SET countryName = ? WHERE countryID = ?";
		$stmt = $this->connect()->prepare($sqlTwo);
		$stmt->execute([$countryName,$countryID]);
		
		
		
	
	}
			
			
			
			
	}
	}
	
	
	public function forceAddPRResp($user, $projectID){
	$sql = "INSERT INTO applicants (projectID, user, dateTime, message) VALUES (?, ?, ?, ?)";
	$stmt = $this->connect()->prepare($sql);
	$date = time();
	$message = 'WELCOME';
	$stmt->execute([$projectID, $user, $date, $message]);
	}
	
	
	
	
}





$Quickquery = new Quickquery();












<?php
require_once("../classes/troupes.class.php");
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}

//OBJECTS
$troupesObj = new Troupes();
$userObj = new User();

$json = array();

//GET REQUESTS
$troupesReqResult = $troupesObj->getTroupeRequests($userLoggedIn, $start); //TROUPES RESULT
if($troupesReqResult == "error"){
echo "error";
exit();
}
$resultCheck = count($troupesReqResult);
if($resultCheck == 0){
echo "end";	
exit();
}

//FOR EACH REQUEST
foreach($troupesReqResult as $troupe){
$userToGet = $troupe['userFrom'];	

$userResult = $userObj->getUser($userToGet);//USER RESULT

$talentString = "";
$talentResult = $userObj->getTalents($userToGet);//TALENTS
foreach($talentResult as $talent){
$talentString = $talentString. " " . $talent['talent'];
}	
	
$json[] = array(

"user" => $userResult,
"talentString" => $talentString

	
); 		
	
	
}

echo json_encode($json);
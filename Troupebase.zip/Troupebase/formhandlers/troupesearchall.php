<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$start = $_POST['start'];
$timeZone = $_COOKIE['TimeZone'];
}else{

}



$userObj = new User();
$json = array();


$troupesResult = $userObj->getTroupeSearchAll($start);
if(count($troupesResult) == 0){
echo "end";
exit();
}






foreach($troupesResult as $user){

$troupeID = $user['id'];
$name = $user['name'];
$talent = $user['talent'];
$alias = $user['alias'];	
$profilePic = $user['profilePic'];
if($profilePic ==""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
$state = $user['state'];	

	
	
$json[] = array(
'troupeID' => $troupeID,
'name' => $name,
'talent' => $user['talentString'],
'alias' => $alias,
'profilePic' => $profilePic,
'state' => $state
);
	


}





echo json_encode($json);






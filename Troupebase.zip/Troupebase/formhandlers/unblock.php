<?php
require_once("../classes/user.class.php");

if(isset($_POST['isWebsite'])){
$userToUnblock = $_POST['troupeID'];
}else{

}

$userLoggedIn = $_COOKIE['TroupeBaseID'];

$userObj = new User();
$unblock = $userObj->unblock($userLoggedIn, $userToUnblock);


echo $unblock;
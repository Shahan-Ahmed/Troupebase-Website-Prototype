<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$messageReceipt = $_POST['messageReceipt'];
}else{

}

$userLoggedIn = $_COOKIE['TroupeBaseID'];

$userObj = new User();

$update = $userObj->messageReceipt($userLoggedIn, $messageReceipt);

echo $messageReceipt;
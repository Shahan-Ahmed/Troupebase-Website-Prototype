<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$newName = $_POST['newName'];
$newName = substr($newName, 0, 50);
$newCity = $_POST['newCity'];
$newState = $_POST['newState'];
$newCountry = $_POST['newCountry'];
$timeZone = $_POST['timeZone'];
$timeZone = str_replace(' ','_', $timeZone);
$newWebsite = strtolower($_POST['newWebsite']);
$cleanLink = str_replace("https://","", $newWebsite);
$cleanLink = str_replace("http://","", $newWebsite);
$newProfileMessage = $_POST['newProfileMessage'];	
$newProfileMessage = substr($newProfileMessage, 0, 100);
$troupeRequestPrivacy = $_POST['troupeRequestPrivacy'];
$collabRequestPrivacy = $_POST['collabRequestPrivacy'];
$projectGoalVisibility = $_POST['projectGoalVisibility'];	

$newFacebookLink = $_POST['newFacebookLink'];
$newInstagramLink = $_POST['newInstagramLink'];	
$newAppleMusicLink = $_POST['newAppleMusicLink'];	
$newAmazonLink = $_POST['newAmazonLink'];	
$newSpotifyLink = $_POST['newSpotifyLink'];	
$newYoutubeLink = $_POST['newYoutubeLink'];
$newTidalLink = $_POST['newTidalLink'];	
$newTwitchLink = $_POST['newTwitchLink'];	
$newTikTokLink = $_POST['newTikTokLink'];	
$newSoundcloudLink = $_POST['newSoundcloudLink'];
	
}else{

}


$userLoggedIn = $_COOKIE['TroupeBaseID'];

if($newFacebookLink !==''){
$fbLink = "facebook=".$newFacebookLink.",";
}	
if($newInstagramLink !==''){
$igLink = "instagram=".$newInstagramLink.",";
}		
if($newAppleMusicLink !==''){
$appleMusicLink = "applemusic=".$newAppleMusicLink.",";
}	
if($newAmazonLink !==''){
$amazonLink = "amazon=".$newAmazonLink.",";
}
if($newSpotifyLink !==''){
$spotifyLink = "spotify=".$newSpotifyLink.",";
}	
if($newYoutubeLink !==''){
$youtubeLink = "youtube=".$newYoutubeLink.",";
}
if($newTidalLink !==''){
$tidalLink = "tidal=".$newTidalLink.",";
}
if($newTwitchLink !==''){
$twitchLink = "twitch=".$newTwitchLink.",";
}	
if($newTikTokLink !==''){
$tikTokLink = "tiktok=".$newTikTokLink.",";
}
if($newSoundcloudLink !==''){
$souncloudLink = "soundcloud=".$newSoundcloudLink.",";
}

$socialMediaString = $fbLink.$igLink.$appleMusicLink.$amazonLink.$spotifyLink.$youtubeLink.$tidalLink.$twitchLink.$tikTokLink.$souncloudLink;

$userObj = new User();
$update = $userObj->updateProfile($userLoggedIn, $newName, $newCity, $newState, $newCountry, $timeZone, $socialMediaString, $newProfileMessage, $newWebsite, $collabRequestPrivacy, $troupeRequestPrivacy, $projectGoalVisibility);



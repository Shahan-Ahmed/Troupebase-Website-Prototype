<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$imageBase64 = $_POST['profilepic'];
$selectedProfFilter = $_POST['selectedProfFilter'];
}else{

}

$userLoggedIn = $_COOKIE['TroupeBaseID'];
$json = array();
$date = time();
$dateTwo = $date + 1;

$data = str_replace('data:image/png;base64,', '', $imageBase64);

$data = str_replace(' ', '+', $data);

$data = base64_decode($data);

$file = '../userUploads/profilepics/'.$userLoggedIn.$date. '.png';
$fileDB = 'https://troupebase.com/userUploads/profilepics/'.$userLoggedIn.$date. '.png';
if(file_put_contents($file, $data)){

$userObj = new User();	
$result = $userObj->updateProfilePic($userLoggedIn, $fileDB, $selectedProfFilter);
	
if($result == "error"){
echo "error";
}else{
$json[] = array(
"photo" => $result,
"filter" => $selectedProfFilter
);			
echo json_encode($json);
}
	
	
	
}else{
echo "error";
}


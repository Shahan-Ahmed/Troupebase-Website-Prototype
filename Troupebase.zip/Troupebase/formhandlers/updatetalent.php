<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
$talent = $_POST['talent'];
}else{

}

$talent = str_replace("And", "/", $talent);	



$userObj = new User();


//GET THE TALENT STRING
$talentStringResult = $userObj->getTalentsOne($userLoggedIn);
$talentString = $talentStringResult['talentString'];


//CHECK COUNT
$array  = explode(',', $talentString);
$count  = count($array) - 1;

if($count == 4){
echo "MAX";
exit();
}




//CHECK ALREADY SELECTED
if(strstr($talentString, $talent.",")) {
echo "ALREADY SELECTED"; 
exit();
}



//ADD TALENT
$insert = $userObj->updateTalent($userLoggedIn, $talent);

echo $insert;






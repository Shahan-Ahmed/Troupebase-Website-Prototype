<?php
require_once("../classes/user.class.php");
$userLoggedIn = $_COOKIE['TroupeBaseID'];
if(isset($_POST['isWebsite'])){
$alias = $_POST['alias'];
}else{

}
$alias = substr($alias, 0, 30);
$alias = str_replace(' ', '', $alias);
$alias = str_replace('&', 'and', $alias);
preg_replace("/^'|[^A-Za-z0-9\'-]|'$/", '', $alias);


$userObj = new User();

//IF SAME
$currentResult = $userObj->getUserAlias($userLoggedIn);
$currentUsername = "";
foreach($currentResult AS $result)
{
$currentUsername = $result;
}
if(strtolower($currentUsername) == strtolower($alias)){
echo "success";
exit();
}


//IF TAKEN
$ifTaken = $userObj->checkUserNameTaken($userLoggedIn, $alias);

if($ifTaken > 0){
echo "taken";
exit();
}



//UPDATE
echo $update = $userObj->updateUsername($userLoggedIn, $alias);








	
	
	
	








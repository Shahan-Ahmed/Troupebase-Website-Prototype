<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$user = $_POST['user'];
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


$userObj = new User();

$usersResults = $userObj->usersSearch($userLoggedIn, $user, $start);
$resultCheck = count($usersResults);
if($resultCheck == 0){
echo "end";
	exit();
}







echo json_encode($usersResults);
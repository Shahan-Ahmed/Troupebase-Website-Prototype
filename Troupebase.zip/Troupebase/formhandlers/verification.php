<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


$userObj = new User();


//ACCEPT TERMS OF USE
if(isset($_POST['acceptTermsOfUse'])){
$userObj->acceptTermsOfUse($userLoggedIn);
exit();
}
//accept terms of user



//DECLINE TERMS OF USE
if(isset($_POST['declineTermsOfUser'])){
$userObj->declineTermsOfUser($userLoggedIn);
echo "success";
exit();
}
//decline terms of user

























//EMAIL VERIFICATION
if(isset($_POST['checkEmailPin'])){
$pin = mysqli_real_escape_string($tbConn, $_POST['pin']);
	
$checkPin = mysqli_query($tbConn, "SELECT pin FROM users WHERE id = '$userLoggedIn'");
$resultCheckPin = mysqli_num_rows($checkPin);
if($resultCheckPin>0){
$rowPin = mysqli_fetch_assoc($checkPin);
	
$pinToCheck = $rowPin['pin'];

if($pin == $pinToCheck){
$update = mysqli_query($tbConn, "UPDATE users SET visible = '1', verified = '1' WHERE id = '$userLoggedIn'");
echo "success";
}else{
echo  "PIN DOES NOT MATCH";
}


}else{
echo "error";
}	
	
exit();
}
//email verification




?>
<?php
require_once("../classes/user.class.php");
if(isset($_POST['isWebsite'])){
$userToSearch = $_POST['user'];
$start = $_POST['start'];
$userLoggedIn = $_COOKIE['TroupeBaseID'];
}else{

}


$userObj = new User();

$resultObj = $userObj->getUsersToTag($userLoggedIn, $userToSearch, $start);
$resultCheck = count($resultObj);

if($resultCheck > 0){
$json = array();

foreach($resultObj as $user){

$troupeID = $user['id'];
$name = $user['name'];
$alias = $user['alias'];	
$profilePic = $user['profilePic'];
if($profilePic ==""){
$profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
$state = $user['state'];	
	
$talentString = "";	
	

	
$json[] = array(
'troupeID' => $troupeID,
'name' => $name,
'talent' => $user['talentString'],
'alias' => $alias,
'profilePic' => $profilePic,
'state' => $state
);	
	
	
	
	
}	

}else{
echo "";
exit();
}



echo json_encode($json);
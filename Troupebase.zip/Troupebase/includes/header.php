<!DOCTYPE html>
<head>
<title>troupebase</title>
<meta name="description" content="Social Media for the Creator - discover, share and collaborate with other talents.">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=4, user-scalable=0"/>
<link rel="shortcut icon" href="https://troupebase.com/assets/troupebaseIcon.jpeg" type="favicon/ico" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300&display=swap" rel="stylesheet">
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/adc2b66e7d.js" crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css" href="css/croppie.css">
<link rel="stylesheet" type="text/css" href="css/troupebase.css?v=11.149">
<script src="js/croppie.min.js" type="text/javascript"></script>
<script src="js/tb.js?v=6.630" type="text/javascript"></script>
</head>
	
	
	
<script>
var url = window.location.href;
if (url.indexOf("www.") >= 0){
var loc = url.replace("www.","");
window.location=loc;
}
</script>

<input type='hidden' id='lastMessageDate' value=''>	

<noscript>
<div class='noScript'>
	<br><br>
	<p style='font-size: 25px;'>JAVASCRIPT IS DISABLED</p>
	<p>Troupebase requires Javascript to be enabled<br>Please enable Javascript</p>
	<a href='https://troupebase.com'><button>CONTINUE</button></a>
</div>
</noscript>



<body id='body'>
	
	

	
	
	
	<div id='topBar'><!-- START TOP BAR-->
	<div id='logo'><!-- START LOGO-->
		<img src='../assets/logojusttb.png'>
	</div><!-- end logo-->
	

	<div id='navContainer'><!-- START NAV-->
	<a href='https://troupebase.com' id='goToHomeBase'><img src='../assets/defaultProfilePic.png' class='t1 tutorial tip' id='goToHomeIcon' data-tip='Homebase'></a>
		<img class="fas fa-search notificationIcons t2 tutorial tip" id='goToTroupeSearch' value='https://troupebase.com/troupesearch.php' src='https://troupebase.com/assets/trsearch.png' data-tip='Troupe Search'>
		<a href='https://troupebase.com/projectsearch.php'><img class='t3 tutorial tip' src='https://troupebase.com/assets/checklist.png' id='projectSearchIcon' data-tip='Projects'></a>
		<a href='https://troupebase.com/discover.php?talent=all&state=all'><img class='t4 tutorial tip' src='https://troupebase.com/assets/discoverTwo.png' id='discoverIcon' style='background-color: white;' data-tip='Discover'></a>

	</div><!-- end nav-->

	

	
	
</div><!-- end top bar-->
	
	<input type='file' id='fileToShare' name='fileToShare' style='display: none;'>
	<input type='file' id='selectedCoverForAudio' name='selectedCoverForAudio' style='display: none;'>
	<input type='file' id='fileToAddToPortfolio' name='fileToAddToPortfolio' style='display: none;'>
	
	
	
	
<div id='mainContainer'><!-- START MAIN CONTAINER-->	
	<div id='successResponseDropDown'><!-- SUCCESS-->
</div><!-- success-->	
	
	
		

	
	<div id='profileLoaderContainerSlider'><div id='profileLoaderContainer'></div></div>
	
	<div id='splashContainer'><div id='splashContent'><img src='../assets/logowhitegreenback.jpg'></div></div>
	

	
	
	
	
	
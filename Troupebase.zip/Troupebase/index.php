<?php
include("includes/header.php");
?>

<div id='signupContainer'><!-- SIGNUP CONTAINER-->	
<div id='welcomeLogo'>
<img src='../assets/tblogoonlywhite.png'>
</div>	
<div id='signUpOptionsOptions'>
	
<div id='signupFormHeading'><!-- HEADING-->
<p id='signupMessage'>New Account</p>	
</div>	
	
	
	
	
<div id='signupFormItems'><!-- FORM ITEMS-->
<input type='text' placeholder='First & Last Name' class='signupName' id='name'><span id='signupNameCount'></span><br>
<input type='text' placeholder='E-Mail' class='signupEmail' id='email'><span id='signupEmailCount'></span><br>
<input type='password' placeholder='Password' class='signupPassword' id='password'><span id='signupPasswordCount'></span><br>
<input class='cbone' type="checkbox" id="13older" style='width: 15px; height: 15px;'><span style='color: white;'>I am 13 or older</span><br>
	<button id='createAccount'>CREATE</button><br><br><br>
	<button class='showLoginForm' style='background-color: transparent; color:#009688; font-weight: bold; font-size: 13px; border: none;'>LOGIN</button>
<br><br><br><br>
</div> <!-- form items -->
	
<div class='signupFormContainer signupLoginForms loginFormContainer'>
<div id='signupFormItems'>
<input type='text' placeholder='E-Mail' id='loginEmail' class='loginEmail'><span class='loginEmailCount' style='color: white;'></span><br>
<input type='password' placeholder='Password' id='loginPassword' class='loginPassword'><span class='loginPassCount' style='color: white;'></span><br>
<button id='submitLogin'>LOGIN</button><br><button class='forgotPassword' style='background-color: transparent; border: none; font-size: 11px; margin-top: 10px;'>RESET PASSWORD</button>
<br><br><button class='showSignupForm' style='background-color: transparent; color:#009688; font-weight: bold; font-size: 13px; border: none;'>SIGNUP</button>
</div>
</div>
	<br><br><br>
	
	
<div class="policiesContainer welcomepolicycon"><button class="viewPolicy" value="about">ABOUT</button><button class="viewPolicy" value="privacy">PRIVACY</button><button class="viewPolicy" value="dmca">DMCA</button><button class="viewPolicy" value="tou">TOU</button></div>	
	
</div>
</div><!-- signup container-->
</div><!-- end main container-->
</body>
</html>

<script>
$("#logo").css("display", "none");
</script>
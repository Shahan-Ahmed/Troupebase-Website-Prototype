$(document).ready(function(){
	
var mainScroll = document.getElementsByClassName("mainScroll");

var scrollStart = 10;
var scrollLimit = 10;
var selection;

var scrollTime;

	
	
	
	
	
	
	
	
	
	
	
	
	
//TROUPE OPTIONS
$("body").on("click", ".showTroupeOptions", function(){
var id = $(this).attr("data-id");
$(this).slideUp(50);	
$(".troupeContainerDropdown"+id).slideDown(50);
setTimeout(function(){
$(".showTroupeOptions").slideDown(50);
$(".troupeContainerDropdown"+id).slideUp(50);
}, 3000);
});
	
	
	
//FEATURE	
$("body").on("click", ".featureThisTroupe", function(){	
var troupeID = $(this).attr("data-troupeid");
$.ajax({
url: "https://troupebase.com/admin/formHandlers/featureTroupeHandler.php",
method: "POST",
data: {
troupeID: troupeID,
feature: 1
},
success: function(response){
if(response == "success"){
$(".featureSuccess"+troupeID).slideDown(50);
}
}
});
});
	
	
	
	
//UNFEATURE	
$("body").on("click", ".unfeatureThisTroupe", function(){	
var troupeID = $(this).attr("data-troupeid");
$.ajax({
url: "https://troupebase.com/admin/formHandlers/featureTroupeHandler.php",
method: "POST",
data: {
troupeID: troupeID,
unfeature: 1
},
success: function(response){
if(response == "success"){
$(".unfeatureSuccess"+troupeID).slideDown(50);
}
}
});
});	
	
	
	
	
//troupe options
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
//SUBMIT LOGIN
$(".adminlogin").on("click", function(){
var email = $(".loginemail").val();
var password = $(".loginpassword").val();
$.ajax({
url: "https://troupebase.com/admin/login.php",
method: "POST",
data: {
email: email,
password: password,
login: 1
},
success: function(response){
if(response == "email not found"){
alert("Account not found");
return;
}
if(response == "wrong password"){
alert("Incorrect password");
return;
}

$(".formhandlerresponse").append(response);

}
});
return;
});
//submit login






	
	
	
	
	
	

	


//MENU SELECTION
$("body").on("click", ".menuSelection", function(){
scrollStart = 10;
scrollLimit = 10;
var buttonClicked = $(this).attr("value");
var scrollerShowing = $(this).attr("data-heading");
selection = $(this).attr("data-selection");
$(".scrollerShowing").html(scrollerShowing);
if(buttonClicked == "newFeature"){
}
	
	
loadSelection();
	
});
//menu selection








	
	
	
//BACK TO  MENU	
$("body").on("click", ".backToMenu", function(){
	$(".menu").slideDown(50);
$(".scrollCombo").slideUp(50);
});
//
	
	
	
//LOAD SELECTION FUNCTION	
function loadSelection(){
$(mainScroll).empty();
$(".menu").slideUp(50);
$(".scrollCombo").slideDown(50);
	
if(selection == "newFeature" || selection == "currentlyFeatured"){
$.ajax({
url: "https://troupebase.com/admin/feature.php",
method: "POST",
data: {
selection: selection,
scrollStart: 0,
scrollLimit: 10
},
success: function(response){
constructFeatures(response);
}
});
}
	
	
	
	
	
	
}	
//load selection function	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	

//SCROLLS


$(mainScroll).on("scroll", function(){
var elmnt = document.getElementById("mainScroll");
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t === c){

if($(".endOfResults").length === 0){
	
if(selection == "newFeature" || selection == "currentlyFeatured"){
loadMoreFeatures();	
}	
	
	
	
}
}
},150);
});
	
	

//scrolls












//LOAD MORE FEATURES FUNCTION
function loadMoreFeatures(){
$.ajax({
url: "https://troupebase.com/admin/feature.php",
method: "POST",
data: {
selection: selection,
scrollStart: scrollStart,
scrollLimit: scrollLimit
},
success: function(response){
if(response == "end"){
$(mainScroll).append("<div class='endOfResults' style='color: black; text-align: center;'><br>End of Results<br><br><br></div>");
return;
}
constructFeatures(response);
scrollStart += scrollLimit;
}
});
}
//load more features function


	









//CONTRUCT FEATURES FUNCTION	
function constructFeatures(response){
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var troupe = data[i];
	
if($(".troupeContainer"+troupe.troupeID).length == 0){	

$(mainScroll).append("<div class='troupeContainer troupeContainer"+troupe.troupeID+"'></div>");		
$(".troupeContainer"+troupe.troupeID).append("<div class='troupeContent troupeContent"+troupe.troupeID+"'><br></div>");
$(".troupeContent"+troupe.troupeID).append("<div class='troupeHasBeenFeatured featureSuccess"+troupe.troupeID+"'><br><br><br><br><p>USER HAS BEEN FEATURED</p></div>");
$(".troupeContent"+troupe.troupeID).append("<div class='troupeHasBeenFeatured unfeatureSuccess"+troupe.troupeID+"'><br><br><br><br><p style='color: red;'>USER HAS BEEN UN-FEATURED</p></div>");
$(".troupeContent"+troupe.troupeID).append("<div class='troupeContainerOptions'><img src='https://troupebase.com/assets/dropdown.png' class='showTroupeOptions' data-id = '"+troupe.troupeID+"' style='border: none; width: 25px; height: 25px;'></div>");
if(selection == "newFeature"){
$(".troupeContent"+troupe.troupeID).append("<div class='troupeContainerDropdown troupeContainerDropdown"+troupe.troupeID+"'><button class='featureThisTroupe' data-troupeid='"+troupe.troupeID+"'>FEATURE</button></div>");
}
if(selection == "currentlyFeatured"){
$(".troupeContent"+troupe.troupeID).append("<div class='troupeContainerDropdown troupeContainerDropdown"+troupe.troupeID+"'><button class='unfeatureThisTroupe' data-troupeid='"+troupe.troupeID+"'>UN-FEATURE</button></div>");
}
$(".troupeContent"+troupe.troupeID).append("<img class='viewProfile' src='"+troupe.profilePic+"'>");
$(".troupeContent"+troupe.troupeID).append("<p style='font-weight: bold;'>"+troupe.name+"</p><p style='font-weight: bold;'>"+troupe.talent+", "+troupe.state+"</p><p>"+troupe.about+"</p><br>");


	
	
}	
	
}
}	
//construct features function






	
	
	
	

setTimeout(function(){
$(".splash").fadeOut(1000);
}, 2000);
});
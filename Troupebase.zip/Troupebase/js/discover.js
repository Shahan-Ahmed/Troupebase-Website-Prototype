$(document).ready(function(){
var homebaseIsLoggedIn;
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
var SessionID = localStorage.getItem('SessionID');
var profilePic = localStorage.getItem("profilePic");
$("#goToHomeIcon").attr("src", profilePic);	
	
var scrollTime;
	
var disc_city_filter = "";
var disc_state_filter = "";
var disc_country_filter = "";
var disc_talent_filter = "";	
	

	
	
	
	
//LOAD DISCOVER WRAP ON LOAD
$("#profileLoaderContainer").append("<div class='wrapper'><div class='discoverscrollwrap' id='discoverscrollwrap'><div class='scroller discoverScroller' id='discoverScroller' data-start = '0'><div class='discover-suggested flex-wrap-start'></div><div class='discover-allposts flex-wrap-start' id='discover-allposts'></div></div><div class='discovermenuwrap' id='discovermenuwrap'><div class='discovermenuicons' id='discovermenuicons'><img class='hoverimage' id='showDiscSearch' value='hidden' src='../assets/discoversearch.png'></div><div class='discoversearchheading' id='discoversearchheading'>Search Posts</div><div class='discoversearchinputs' id='discoversearchinputs'><button class='chooseTalentsFilter'>Talent</button><button class='chooseLocationForShare'>Location</button><span class='hoverimage' id='resetDiscFilters' style='color: #214844; font-weight: bold; display: none;'>Show All</span></div></div></div></div>");
var disctalentselector = document.getElementById('talentDiscoverSearch');
$("#profileLoaderContainerSlider").css("display", "initial");
	
	
//RESET	
$("body").on("click", "#resetDiscFilters", function(){
resetDiscover();
});
function resetDiscover(){
$(".discfilteredsearchwrap").remove();
$(".chooseTalentsFilter").html("Talent");
$(".chooseLocationForShare").html("Location");
disc_city_filter = "";
disc_state_filter = "";
disc_country_filter = "";
disc_talent_filter = "";	
}
	
	
	
	
	
	
	
//FILTER EVENTS
	
$("body").on("click", ".eachTalentFilter", function(){
var talent = $(this).attr("data-value");
disc_talent_filter = talent;
$("#talentFiltContainer").fadeOut(100);
$(".chooseTalentsFilter").html(talent);
if(talent == ""){
$(".chooseTalentsFilter").html("Talent");
}
loadFilteredSearchForDiscover();
});	
	
$("body").on("click", ".eachLocation", function(){
var id = $(this).attr("data-id");
let location = $("#thisLocationText"+id).html();
let locationString = $("#eachLocationCommaString"+id).text();
let Arr = locationString.split(',');
disc_city_filter = Arr[0];
disc_state_filter = Arr[1];
disc_country_filter = Arr[2];
loadFilteredSearchForDiscover();
});

	
	
	
	
	
	
	

//LOAD THEN FILTERED CONTAINER	
function loadFilteredSearchForDiscover(){
$("#resetDiscFilters").css("display", "initial");
$(".discfilteredsearchwrap").remove();
if(disc_country_filter == "" && disc_talent_filter == ""){
return;
}
var time = Date.now();
$("#discoverscrollwrap").append("<div class='universalcontainer discfilteredsearchwrap flex-wrap-start' id='discfilteredsearchwrap"+time+"' style='width: 100%; top: 0px; background-color: white;' data-start = '0'></div>");
var container = document.getElementById('discfilteredsearchwrap'+time);

//SCROLL
$("#discfilteredsearchwrap"+time).on("scroll", function(){
var start = $(this).attr("data-start");
console.log(start);
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+250){
discover_get_filtered_posts(start).then(function(response){
constructPosts(container, start, response);
});	
}
}, 150);
});		
	
	
	
var start = $("#discfilteredsearchwrap"+time).attr("data-start");
discover_get_filtered_posts(start).then(function(response){
constructPosts(container, start, response);
});	
	
}	
	
	
	
	
	
//GET FILTERED POSTS	
function discover_get_filtered_posts(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/filtereddiscoverposts.php",
method: "POST",
data: {
start: start,
talent: disc_talent_filter,
city: disc_city_filter,
state: disc_state_filter,
country: disc_country_filter,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 150);
});
}
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
//GET SUGGESTED DISC POSTS
//getDiscoverPostSuggested().then(function(response){

//});
function getDiscoverPostSuggested(){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/getdiscsuggested.php",
method: "POST",
data: {
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}
	
	
	
	
	
//SCROLL
$("#discoverScroller").on("scroll", function(){

var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+250){
getAllDiscPostsByDateOrder(start).then(function(response){
var container = "all";
constructPosts(container, start,response);
});
}
}, 150);
});	
		
	
	
	
	
	
	
//GET ALL OTHER POSTS
getAllDiscPostsByDateOrder(0).then(function(response){
var container = "all";
constructPosts(container, 0,response);
});
function getAllDiscPostsByDateOrder(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/getdiscoverposts.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);	
});
}
	
	
	
	
	
	
	
	
//CONSTRUCT POST
function constructPosts(container, start, response){

if(response == "end"){
return;
}
//UPDATE SCROLL COUNT
var newStart = parseInt(start) + 20;
if(container == "all"){
var container = document.getElementById('discover-allposts');
$("#discoverScroller").attr("data-start", newStart);
}	
if(container !== "all"){
$(".discfilteredsearchwrap").attr("data-start", newStart);
}		

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var post = data[i];		
	
	
//DETERMINE TYPE ICON
if(post.type == "v"){
var typeOfImage = "../assets/videoIconOne.png";
var deleteText = "Video?";
}
if(post.type == "a"){
var typeOfImage = "../assets/audioIconOne.png";
var deleteText = "Audio?";
}
if(post.type == "p"){
var typeOfImage = "";
var deleteText = "Photo?";
}	
	
var smallimage = post.smallimage;
	
	
//IF NO SMALL IMAGE AVAILABLE
if(smallimage == ""){
if(post.type == "p"){
smallimage = post.photo;
}
if(post.type == "a" || post.type == "v"){
smallimage = post.coverPhoto;
}
}
	

	
//CONSTRUCT POST	
$(container).append("<div class='postContainer postContainer"+post.id+" viewPost' data-id='"+post.id+"' data-datetime='-'><img src='"+smallimage+"' class='filter"+post.filter+"'><div id='TypeLikedContainerUp"+post.id+"' class='TypeLikedContainer TypeLikedContainerUp"+post.id+"'><img src='"+typeOfImage+"'></div></div>");	
if(post.type == "p"){
$("#TypeLikedContainerUp"+post.id).remove();
}
	
	
	
	
	

	
}	
}	
	
	
	
});
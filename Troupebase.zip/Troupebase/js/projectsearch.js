$(document).ready(function(){
var homebaseIsLoggedIn;
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
var SessionID = localStorage.getItem('SessionID');

var profilePic = localStorage.getItem("profilePic");
$("#goToHomeIcon").attr("src", profilePic);	
	
var scrollTime;
	
var ps_city_filter = "";
var ps_state_filter = "";
var ps_country_filter = "";
var ps_talent_filter = "";	
	
	

	
	
//LOAD DISCOVER WRAP ON LOAD
$("#profileLoaderContainer").append("<div class='wrapper'><div class='discoverscrollwrap' id='discoverscrollwrap'><div class='scroller discoverScroller' id='discoverScroller' data-start = '0'><div class='discover-suggested flex-wrap-start'></div><div class='discover-allposts flex-wrap-start' id='discover-allposts'></div></div><div class='discovermenuwrap' id='discovermenuwrap'><div class='discovermenuicons' id='discovermenuicons'><img class='hoverimage' id='showDiscSearch' value='hidden' src='../assets/discoversearch.png'></div><div class='discoversearchheading' id='discoversearchheading'>Search Projects</div><div class='discoversearchinputs' id='discoversearchinputs'><button class='chooseTalentsFilter'>Talent</button><button class='chooseLocationForShare'>Location</button><span class='hoverimage' id='resetPGFilters' style='color: #214844; font-weight: bold; display: none;'>Show All</span></div></div></div></div>");
var disctalentselector = document.getElementById('talentDiscoverSearch');
$("#profileLoaderContainerSlider").css("display", "initial");	
	
	
	
	
	
	
//SCROLL
$("#discoverScroller").on("scroll", function(){
var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+250){
getAllPGSearch(start).then(function(response){
var container = "all";
ps_construct_projects(container, start,response);
});
}
}, 150);
});	
			
	
	
	
	
	
	
	
	
	
	
	
//RESET	
$("body").on("click", "#resetDiscFilters", function(){
resetPGSearch();
});
function resetPGSearch(){
$(".discfilteredsearchwrap").remove();
$(".chooseTalentsFilter").html("Talent");
$(".chooseLocationForShare").html("Location");
ps_city_filter = "";
ps_state_filter = "";
ps_country_filter = "";
ps_talent_filter = "";	
}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//FILTER EVENTS
	
$("body").on("click", ".eachTalentFilter", function(){
var talent = $(this).attr("data-value");
ps_talent_filter = talent;
$("#talentFiltContainer").fadeOut(100);
$(".chooseTalentsFilter").html(talent);
if(talent == ""){
$(".chooseTalentsFilter").html("Talent");
}
loadFilteredSearchForPS();
});	
$("body").on("click", ".eachLocation", function(){
var id = $(this).attr("data-id");
let location = $("#thisLocationText"+id).html();
let locationString = $("#eachLocationCommaString"+id).text();
let Arr = locationString.split(',');
ps_city_filter = Arr[0];
ps_state_filter = Arr[1];
ps_country_filter = Arr[2];
loadFilteredSearchForPS();
});	
	
	
	
	
	
	
//LOAD THEN FILTERED CONTAINER	
function loadFilteredSearchForPS(){
$("#resetDiscFilters").css("display", "initial");
$(".discfilteredsearchwrap").remove();
if(ps_country_filter == "" && ps_talent_filter == ""){
return;
}
	
var time = Date.now();
$("#discoverscrollwrap").append("<div class='universalcontainer discfilteredsearchwrap flex-wrap-start' id='discfilteredsearchwrap"+time+"' style='width: 100%; top: 0px; background-color: white;' data-start = '0'></div>");
var container = document.getElementById('discfilteredsearchwrap'+time);

//SCROLL
$("#discfilteredsearchwrap"+time).on("scroll", function(){
var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+250){
ps_get_filtered_posts(start).then(function(response){
ps_construct_projects(container, start, response);
});	
}
}, 150);
});		
	
	
var start = $("#discfilteredsearchwrap"+time).attr("data-start");
ps_get_filtered_posts(start).then(function(response){
ps_construct_projects(container, start, response);
});	

	
}	
		
	


	
	
//GET FILTERED PROJECTS
function ps_get_filtered_posts(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/filteredprojectsearch.php",
method: "POST",
data: {
start: start,
talent: ps_talent_filter,
city: ps_city_filter,
state: ps_state_filter,
country: ps_country_filter,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 150);
});
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//GET ALL PROJECT SEARCH
function getAllPGSearch(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/pgsearchall.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 150);	
});
}
getAllPGSearch(0).then(function(response){
var container = "all";
ps_construct_projects(container, 0,response);
});			
	
	


	
	
//REMOVE EXCESS LINE BREAKS
function removeExcessLB(string){
var string = string.replace(/\n\s*\n\s*\n/g, '\n\n');
return string;
}





//CONSTRUCT PROJECT GOALS
	
function ps_construct_projects(container, start, response){
if(response == "end"){
return;
}

//UPDATE SCROLL COUNT
var newStart = parseInt(start) + 20;
if(container == "all"){
var container = document.getElementById('discover-allposts');
$("#discoverScroller").attr("data-start", newStart);
}	
if(container !== "all"){
$(".discfilteredsearchwrap").attr("data-start", newStart);
}		
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var post = data[i];		

var counter = Math.random();
counter = counter.toString();
counter = counter.replace(".", "");	
	
	
	//USERS TALENTS
	var talentText = "";
let talents = post.userObj.talentString;
	talents = talents.split(',');
	for(var t = 0; t<talents.length; t++){
	var thisTalent = talents[t];
	if(thisTalent !==""){
		talentText = talentText+thisTalent+", ";
	}
	}
	
	talentText = talentText.replace(/,(\s+)?$/, ''); 	
	
	
	
	//REQUIRED TALENTS
	var rtalentString = "";
	var requiredTalents = post.requiredTalent;
	requiredTalents = requiredTalents.split(',');
	for(var rt = 0; rt<requiredTalents.length; rt++){
	var thisReqTalent = requiredTalents[rt];
		if(thisReqTalent !==""){
		rtalentString = rtalentString+thisReqTalent+", ";
	}
	}
	
	rtalentString = rtalentString.replace(/,(\s+)?$/, ''); 
	
	
	
	//LOCATION 
	var locationString = "Location: "+post.city+", "+post.state;
	
	if(post.state == "" || post.state == "null"){
	var locationString = "Location: Any";
	}	

	var deleteText = "Project Goal?";

	var subject = post.subject;
	

	//REMOVE EXCESS LINE BREAKS
	post.caption = removeExcessLB(post.caption);

	
var profilePic = post.userObj.profilePic;
if(profilePic == ""){
profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}

	var shortCaption = post.caption.substring(0,140);	


$(container).append("<div id='eachFeedPostWrap"+post.id+"' class='eachFeedPostWrap eachFeedPostWrap"+post.id+"'><div class='eachProjectGoalFeed'><div class='postedBy'><div class='postedByPhoto'><img id='projectGoalUserPic"+post.id+"' src='"+profilePic+"'></div><div class='postedByName'><span style='font-weight: bold;' id='projectGoalName"+post.id+"'>"+post.userObj.name+"</span><br><span id='projectGoalUsersTalentAndState"+post.id+"'>"+talentText+", "+post.userObj.state+"</span><br><span>Looking for: "+rtalentString+"</span><br><span>"+locationString+"</span><br><span>Subject: "+subject+"</span><br><span style='font-size: 11px;'>"+post.dateTime+"</span><br></div></div><div class='pgbody'><div class ='projectShortBody' id='projectShortBody"+counter+"'>"+shortCaption+"</div><div class='fullProjectCaption fullProjectCaption"+counter+"' id='fullProjectCaption"+counter+"' data-id='"+post.id+"'>"+post.caption+"</div><div class='pgrespdiv pgrespdiv"+counter+"' id='pgrespdiv"+counter+"'></div><div class='pgrespstat' id='pgrespstat"+counter+"'></div><div class='eachFeedPostControls'><img class='hoverimage sharePg sharePg"+post.id+"' id='sharePg"+post.id+"' value='"+post.id+"' src='../assets/sharethree.png'><div id='pgRespImgHere"+counter+"'><img class='interested hoverimage interested"+post.id+"' id='interested"+post.id+"' data-postedby='"+post.user+"' data-projectid='"+post.id+"' data-counter='"+counter+"' src='../assets/messagetwo.png' style='margin-right: 15px;'></div><button class='redTextOnlyButton reportpostbutton' id='reportpostbutton"+post.id+"' value='"+post.id+"' data-counter='"+counter+"'>Report</button></div><div class='confirmdeletediv' id='confirmdeletediv"+post.id+"'>Delete "+deleteText+"<button class='confirmDeleteButton confirmDeletePost' id='conDelPost"+post.id+"' value='"+post.id+"'>YES</button></div><div class='confirmdeletediv' id='confirmReportDiv"+counter+"'>Report "+deleteText+"<button class='confirmDeleteButton confirmReportPost' id='conDelPost"+post.id+"' value='"+post.id+"'>YES</button></div></div></div></div>");
	
	
var shortCaptionLength = shortCaption.length;
var fullCaptionLength = post.caption.length;
	
if(shortCaptionLength < fullCaptionLength){
$("#projectShortBody"+counter).append(" <button class='viewMoreButton viewFullProjectCaption' data-counter='"+counter+"'>View More</button>");
}
	
	//BUTTON CHECK
	if(post.user == post.userLoggedIn){
		$("#interested"+post.id).remove();
	}




//RESPONSE CHECK
var responseStatus = post.responseStatus;
if(responseStatus>0){
$(".interested"+post.id).remove();
$("#pgrespstat"+counter).append("<span style='color: #214844; font-weight: bold; margin-right: 5px;'>Your responded to this project</span><img class='hoverimage delprojresp' data-id='"+post.id+"' data-counter='"+counter+"' src='../assets/delete.png'>");
}
	
	
	
}	
	
}	
	
	
	
});
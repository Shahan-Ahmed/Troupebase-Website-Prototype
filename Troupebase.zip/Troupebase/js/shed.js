$(document).ready(function(){

var URL = window.webkitURL || window.URL;
	
var isGrabbingDrawer = false;
var toolbox = document.getElementById("toolBox");
var handle = document.getElementById("toolboxHandle");
var drawerstart = 0; 
var drawerscrolllock = 0;
	
var currentTime;
var startPointRange;
	
var audio = new Audio();
	
var videoURI = "";
var audioURI = "";
var photoURI = "";
var startTimeSeconds = 0;
var startTime = "00:00:00";

	
var singleImageCanvas;	
	
	
var currentpos = "";
var newpos = "";	
var totalphotossel = 0;
	
var dataURLARRAY = [];
	
	
var currentWindow = "home";
	

	
	
	
	
	
	

	
	
	
	
	
	
	
	
//CREATE
$("body").on("click", ".create", function(){
audio.pause();
if(currentWindow == "singleImageToVid"){
createSinglePhotoVideo();
}
	
	
	
});	
//create	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//MENU
$("body").on("click", ".openCreator", function(){
$(".shedMenuWrap").fadeOut("fast");
var toolToLoad = $(this).attr("value");
loadTool(toolToLoad);
setTimeout(function(){
$(".creatorContainer").fadeIn("fast");
}, 1000);
});
	
	
	
//AUDIO TO VIDEO SELECT	
$("body").on("click", ".singleOrSlide", function(){
if($(this).attr("value") == "singleImageVid"){
loadSingleImageVideoCreator();
}
if($(this).attr("value") == "slide"){
loadAudioToVideoSlideCreator();
}
});	
	
//menu
	
	
	
	
	
	
	
//LOAD TOOL	

	
function loadAudioToVideoSlideCreator(){
$(".creatorContent").fadeOut("fast");
$(".loadToolTool").empty();
$(".loadToolTool").append("<div class='tool'><div class='fileSelector'><div class='errorMess'></div><p>SELECT UP TO 10 PHOTOS</p><input type='file' name='photoFileMulti' class='photoFileMulti' id='photoFileMulti'  accept='.png, .jpg, .jpeg' multiple><br><div class='selectedPhotosWrap'><div class='selectedPhotosContainer'></div></div><br><br><br><button class='back' value='audToVidSecMenu' style='font-size: 11px;'>BACK</button><br><br></div></div>");
	
setTimeout(function(){
$(".loadToolWrap").fadeIn("fast");
}, 1000);
currentWindow = "slideImageAudToVid";
}

	



	
function loadSingleImageVideoCreator(){
$(".creatorContent").fadeOut("fast");
$(".loadToolTool").empty();
$(".loadToolTool").append("<div class='tool'><div class='fileSelector'><div class='errorMess'></div><p>SELECT PHOTO</p><input type='file' name='photoFile' class='photoFile' id='photoFile'><div class='photoPreview'></div><div class='openCropper'>RESIZE FIT<br><img class='cropPhoto' src='https://troupebase.com/assets/shrink.png'></div><br><p>SELECT AUDIO</p><input type='file' name='audioFile' class='audioFile' id='audioFile'><div class='playPauseButton'><img src='https://troupebase.com/assets/pause.png' style='display: none;' class='pauseAudio'><img src='https://troupebase.com/assets/playMedia.png' class='playAudio'></div><div class='startPounterSelector'><span id='currentTime' class='currentTime'>0:00</span><br><span class='startPoint'>Start: 0:00</span><br><input type='range' class='startPointRange' id='startPointRange' name='startPointRange' min='0' max='100' value='0'></div><br><br><br><p>Name File</p><input placeholder = 'NAME THIS FILE' type='text' class='nameFile'><p style='font-size: 12px;'>Video will be same length as audio file<br>(1 Min Max)</p><br><button class='create'>CREATE</button><br><br><button class='back' value='audToVidSecMenu' style='font-size: 11px;'>BACK</button><br><br></div></div>");
setTimeout(function(){
$(".loadToolWrap").fadeIn("fast");
}, 1000);
currentWindow = "singleImageToVid";
currentTime = document.getElementById("currentTime");
}	
	
	
	
//CROP PHOTO
$("body").on("mousedown", ".cropPhoto", function(){
$(".cropperWrap").fadeIn("fast");
	
setCroppie();
	
});
	

//INSTANTIATE CROPPIE
function setCroppie(){


	
var width = $("#cropperContent").width();
var square = width-10;
	
$image_crop = $("#cropContainer").croppie({
enableExit: true,
viewport: {
width: square,
height: square,
type: 'square'
},
boundary: {
width: width,
height: width
}
});	
	
$image_crop.croppie('bind', {
url: photoURI
});
	
	
	
}
//instantiate croppie

	
//DONE CROPPING
$(".doneCrop").on("click", function(){
$(".cropperWrap").fadeOut("fast");
if(currentWindow == "singleImageToVid"){
$image_crop.croppie('result', {
type: 'canvas',
size: 'viewport',
quality: 1
}).then(function(response){
photoURI = response;
$(".cropContainer").croppie("destroy");
$(".photoPreview").empty();

$(".photoPreview").append("<br><img width='400' height='auto' src='"+photoURI+"'>");	
$("body").append("<br><img width='400' height='auto' src='"+photoURI+"'>");	

	
});
}
	
		
		
		
		
		
		
});
//done cropping

//crop photo
	
	
	



	
//MEDIA CONTROLS

audio.addEventListener('timeupdate', function(){
var currentProgress = (audio.currentTime / audio.duration) * 100;
converTime(Math.round(audio.currentTime));
	
});
	
	
function converTime(seconds){
	var min = Math.floor(seconds / 60);
	var sec = seconds % 60;
	min = (min < 10) ? "0" + min : min;
	sec = (sec < 10) ? "0" + sec : sec;
currentTime.textContent = min + ":" + sec;

totalTime(Math.round(audio.duration));
}	
function totalTime(seconds){
	var min = Math.floor(seconds / 60);
	var sec = seconds % 60;
	min = (min < 10) ? "0" + min : min;
	sec = (sec < 10) ? "0" + sec : sec;
currentTime.textContent += "/" + min + ":" + sec;	
}		
	


//START POINT SEEKER
$("body").on("input", "#startPointRange", function(){
var value = $(this).val();
audio.currentTime = audio.duration * (value/100);

var currentSecs = audio.currentTime;
currentSecs = Math.round(currentSecs);
startTimeSeconds = currentSecs;	

startTime = toHHMMSS(currentSecs);
startTime = "00:"+startTime;
$(".startPoint").html("Start: "+ startTime);

	
});
	


var toHHMMSS = (secs) => {
    var sec_num = parseInt(secs, 10)
    var hours   = Math.floor(sec_num / 3600)
    var minutes = Math.floor(sec_num / 60) % 60
    var seconds = sec_num % 60

    return [hours,minutes,seconds]
        .map(v => v < 10 ? "0" + v : v)
        .filter((v,i) => v !== "00" || i > 0)
        .join(":")
}



//




//media controls	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//LOAD TOOL	
function loadTool(toolToLoad){

// AUD TO VID
if(toolToLoad=="audioToVideo"){
$(".creatorContent").append("<div class='toolContainer'><div class='audToVidSecMenu'><button class='singleOrSlide' value='singleImageVid'>SINGLE IMAGE</button><br><button class='singleOrSlide' value='slide'>SLIDESHOW</button><br><br><button class='back' style='font-size: 11px;'>BACK</button></div></div>");
currentWindow = "audToVidSecMenu";
}	
// aud to vid
	

	
}
//load tool
	
	
	
//PLAY PAUSE
$("body").on("click", ".playAudio", function(){
audio.currentTime = startTimeSeconds;
audio.play();
$(this).slideUp("fast");
$(".pauseAudio").slideDown("fast");
});
$("body").on("click", ".pauseAudio", function(){
audio.pause();
$(this).slideUp("fast");
$(".playAudio").slideDown("fast");
});
//play pause
	
	
	
	
	
	
	
//FILES
	



$("body").on("change", ".photoFileMulti", function(e){
$(".selectedPhotosContainer").empty();
	
var files = $(this)[0].files;

if(files.length > 10){
var message = "10 PHOTOS MAX";
$(".photoFileMulti").val("");
errorMess(message);
return;	
}
	
totalphotossel = files.length;

var totalPhotos = 0;
for (var i = 0; i < files.length; i++)
{
totalPhotos++;
var fileName = files[i].name;
var ext = fileName.split('.').pop().toLowerCase();
if(ext == "jpeg" || ext == "jpg" || ext =="png"){
	
var eachFile = files[i];
	
addToImageUrlARRAY(eachFile, files.length);	

	
	

}else{
var message = "PLEASE SELECT PHOTOS ONLY";
$(".photoFileMulti").val("");
errorMess(message);
return;	
}
}
	
});
	

	
var imageURLARRAY = [];

function addToImageUrlARRAY(eachFile, totalPhotos){
var reader = new FileReader();
reader.addEventListener("load", function () {
imageURLARRAY.push(reader.result);
if(imageURLARRAY.length == totalPhotos){
constructImageURLARRAY();
}
}, false);
reader.readAsDataURL(eachFile);
	
	
}
	
function constructImageURLARRAY(){
for(var i = 0; i < imageObjARRAY.length; i++) {
	
}
}


	

function constructImages(imageObjARRAY, width){
var photonum = 0;
for(var i = 0; i < imageObjARRAY.length; i++) {
photonum++;
$(".eachSelectedPhoto"+photonum).append("<canvas width='"+width+"' height='"+width+"' class='eachPhotoCan' id='eachPhotoCan"+photonum+"'></canvas>");	
var canv = document.getElementById('eachPhotoCan'+photonum);
var ctx = canv.getContext('2d');
var image = imageObjARRAY[i];	


(function(ctx, image) {
image.onload = function(){
ctx.drawImage(image, 0, 0, ctx.canvas.width, ctx.canvas.width);
}
})(ctx, image);

	
}
	

	console.log(imageObjARRAY.length);
}

	

$("body").on("mousedown", ".positionSelection", function(){
currentpos = $(this).val();
});
$("body").on("change", ".positionSelection", function(){
newpos = $(this).val();
updatepos(currentpos, newpos);	
});
	
//function update position
function updatepos(){
var canvas = document.getElementById('eachPhotoCan'+currentpos);
var dataURL = canvas.toDataURL();

var elem = document.getElementById('eachSelectedPhotoContainer'+currentpos);

$(elem).insertBefore('.eachSelectedPhotoContainer'+newpos);
	
$(elem).addClass("eachSelectedPhotoContainer"+newpos);
$(elem).attr("id", "eachSelectedPhotoContainer"+newpos);
$(elem).attr("data-photonumber", newpos);
elem.classList.remove("eachSelectedPhotoContainer"+currentpos);
	
var elem = document.getElementById('eachSelectedPhotoOptions'+currentpos);
elem.classList.remove("eachSelectedPhotoOptions"+currentpos);
$(elem).addClass("eachSelectedPhotoOptions"+newpos);
$(elem).attr("id", "eachSelectedPhotoOptions"+newpos);	
	
	
	
for(var i = 0; i<totalphotossel; i++){
if(i<currentpos && i>0){
var pos = $(".positionSelection"+i).val();
var pos = parseInt(pos) + 1;
$(".positionSelection"+i).val(pos);

}
}
	
	
currentpos = "";
newpos = "";
}
//function update position

$("body").on("mousedown touchstart", ".eachSelectedPhotoContainer", function(){
var photonum = $(this).attr("data-photoNumber");
$(".eachSelectedPhotoOptions"+photonum).fadeIn("fast");
});






$("body").on("change", ".photoFile", function(e){
$(".photoPreview").empty();
	
var filePath = $(".photoFile").val(); 
var file_ext = filePath.substr(filePath.lastIndexOf('.')+1,filePath.length).toLowerCase();;

if(file_ext == "jpeg" || file_ext == "jpg" || file_ext =="png"){
}else{
var message = "PLEASE SELECT A PHOTO";
errorMess(message);
return;
}

var file = e.target.files[0];
	
var reader = new FileReader();
reader.addEventListener("load", function () {
photoURI = reader.result;
$(".photoPreview").append("<br><img src='"+photoURI+"' id='singleImagePreview' style='width: 400px; height: auto;'></img>");
}, false);
reader.readAsDataURL(file);

	
	

$(".openCropper").slideDown();
	
});
	
	

	
	

	









$("body").on("change", ".audioFile", function(){
var file = $(this).val();
var ext = file.split('.').pop().toLowerCase();
if(ext == "wav" || ext == "mp3" || ext =="m4a"){
var audioFile = document.getElementById("audioFile");
audioURI = URL.createObjectURL(audioFile.files[0]);

	
audio.src = audioURI;
	
$(".playPauseButton").slideDown("fast");
$(".startPounterSelector").slideDown();
	
}else{
var message = "PLEASE SELECT AN AUDIO FILE";
$(".audioFile").val("");
errorMess(message);
return;	
}
});
//files
	
	
	
	
	
	
	

	
	
	
	
	
	
	
//GO BACK	
$("body").on("click", ".back", function(){

audio.pause();
	
if(currentWindow == "audToVidSecMenu"){
$(".creatorContainer").fadeOut("fast");
setTimeout(function(){
$(".shedMenuWrap").fadeIn("fast");
}, 1000);
currentWindow = "home";
}

	
if(currentWindow == "singleImageToVid" || currentWindow == "slideImageAudToVid"){
$(".loadToolWrap").fadeOut("fast");
setTimeout(function(){
$(".creatorContent").fadeIn("fast");
}, 1000);
currentWindow = "audToVidSecMenu";
}
	
});
//go back
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
function errorMess(message){
$(".errorMess").empty();
$(".errorMess").append("<p style='color: red; margin: 5px;'>"+message+"</p>");
setTimeout(function(){
$(".errorMess").empty();
}, 4000);
}
	

	
	
	
	
	
	
	
	
	
//OPENING ANIMATION
	
$(".shedIntroText").fadeIn(2000);	

	
setTimeout(function(){
var openingAnimationTimer;
const openingAnimationText = baffle(".shedIntroText");
openingAnimationText.set({
	
	
Characters: '▓█▓ /█▒█░ █▒▓▒█ █░█ ▒▒█/< ▒▒<▓ █▒█ ▒░██ ▒░▓░',
speed: 900
});
openingAnimationText.start();
openingAnimationText.reveal(4000);
//
	
}, 1000);
	
setTimeout(function(){
$(".shedIntroText").html("THE shed");
}, 5000)
setTimeout(function(){
$('.shedIntroText').animate({ marginTop: '-150%' , opacity: 0.5 }, 1500);
}, 7500)
setTimeout(function(){
$(".shedSplash").slideUp(500);
$("#slideToOpenToolDrawer").fadeTo("slow", .1).fadeTo("slow", .3).fadeTo("slow", .1).fadeTo("slow", .3).fadeTo("slow", .1).fadeTo("slow", .3).fadeTo("slow", .1).fadeTo("slow", .3).fadeOut("slow");
}, 8000);
	
	
	
	
//SINGLE AUDIO PHOTO FUNCTION
function createSinglePhotoVideo(){	
if(audioURI == "" || photoURI == ""){
var message = "PLEASE SELECT ALL FILES";
errorMess(message);
return;
}
if(name == ""){
var message = "PLEASE NAME THE VIDEO";
errorMess(message);
return;
}


$(".loading").fadeIn("fast");	
	
var name = $(".nameFile").val();
var photoFile = document.getElementById("photoFile").files[0];
var audioFile = document.getElementById("audioFile").files[0];
	
	
var formdata = new FormData();
formdata.append("audioFile", audioFile);
formdata.append("photoURI", photoURI);
formdata.append("startTime", startTime);
formdata.append("nameFile", name);
formdata.append("create", 1);

var ajax = new XMLHttpRequest();	
ajax.upload.addEventListener("progress", uploadProgress, false);
ajax.addEventListener("load", completeResult, false);
	
ajax.open("POST", "https://troupebase.com/shed/formhandlers/createsinglephotovideo.php");
ajax.send(formdata);	
	
}
//single audio photo function
	
	
	
function uploadProgress(e){
var total = (e.loaded/e.total) * 100;
$(".percentFill").css("width", total+"%");
}
function completeResult(e){
resetCreator();
if(e.target.responseText == "success"){
$(".successMessage").html("FILE CREATED!");
$(".toolBoxScrollContainer").empty();
drawerstart = 0;
loadDrawer(drawerstart);
$(".toolBox").trigger("mousedown");
}else{
$(".successMessage").html("ERROR OCCURED!");
}
}	
	


function resetCreator(){
$(".loading").fadeOut("fast");
$(".back").trigger("click");
photoURI = "";
audioURI = "";
setTimeout(function(){
$(".successMessage").html("");
}, 4000);	
	
}	

	
	


loadDrawer(drawerstart);
function loadDrawer(drawerstart){
$.ajax({
url: "https://troupebase.com/shed/loaddrawer.php",
method: "POST",
data: {
loadDrawer: 1,
start: drawerstart

},
success: function(response){
constructDrawerItems(response, drawerstart);
}
});	
}
	

//CONSTRUCT DRAWER ITEMS
function constructDrawerItems(response, drawerstart){

var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){
var file = data[i];
	
var fileUrl = file.file;
var afterSlashChars = fileUrl.match(/\/([^\/]+)\/?$/)[1];
var ext = file.ext;



$(".toolBoxScrollContainer").append("<div class='eachDrawerItem eachDrawerItem"+file.id+"' data-file='"+file.file+"' data-ext='"+ext+"' data-name='"+file.fileName+"'><div class='drawerItemContent'><div class='drawerItemFrame drawerItemFrame"+file.id+"'><img src='"+file.frame+"'></div><div class='eachDrawerItemDetails'>"+file.fileName+"."+ext+"</div></div></div>");
	
	

if(file.viewed == 0){
$(".drawerItemFrame"+file.id).css("-webkit-box-shadow", "0px -1px 20px -5px white");
$(".drawerItemFrame"+file.id).css("-moz-box-shadow", "0px -1px 20px -5px white");	
$(".drawerItemFrame"+file.id).css("box-shadow", "0px -1px 20px -5px white");

$(".eachDrawerItem"+file.id).fadeTo("slow", .2).fadeTo("slow", 1).fadeTo("slow", .2).fadeTo("slow", 1);
	
}		
	


}
}
//construct drawer items
	
	


	
//DOWNLOAD
$("body").on("click", ".eachDrawerItem", function(){
var file = $(this).attr("data-file");
var afterSlashChars = file.match(/\/([^\/]+)\/?$/)[1];
var ext = $(this).attr("data-ext");
var name = $(this).attr("data-name");
window.location = "https://troupebase.com/shed/download.php?file="+afterSlashChars+"&name="+name+"&ext="+ext+"";
});
//download






var toolBoxOpen = 0;
$("body").on("mousedown", ".toolBox",function(e){
if(toolBoxOpen == 0){
 $(".toolBox").animate({height: "650px"});
toolBoxOpen = 1;
}else{
 $(".toolBox").animate({height: "40px"});
toolBoxOpen = 0;
}
});
$("body").on("mousedown", ".toolBoxContent",function(e){
e.stopPropagation();
});
});
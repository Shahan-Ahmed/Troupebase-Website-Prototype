$(document).ready(function(){
var currentUrl = window.location.href;
	
//SET ITEM
function setItem(name, value){
localStorage.setItem(name,value);
}	

	
//DIRECT TO HOMEBASE IF LOGGED IN
function directToHomeBaseIfLoggedIn(){
var url = getUrl();
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
if(TroupeBaseID !== undefined && TroupeBaseID !== "" && TroupeBaseID !== "undefined" && TroupeBaseID !== "null"){
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
var SessionID = localStorage.getItem('SessionID');
var device = getDevice();
checkUserLoggedIn(TroupeBaseID, SessionID, device).then(function(response){
if(response !== "error"){
conHomebase(response);
}else{
loguserout();
}
});
}
}
	
	
	
	
	
//CHECK CURRENT PAGE AND REDIRECT
if(currentUrl == "https://troupebase.com/"){//HOMEBASE
directToHomeBaseIfLoggedIn();	
}
if(currentUrl.includes("https://troupebase.com/discover.php")){//DISCOVER
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
var SessionID = localStorage.getItem('SessionID');
var device = getDevice();
checkUserLoggedIn(TroupeBaseID, SessionID, device).then(function(response){
if(response !== "error"){
setULIVars(response);
}else{
loguserout();
}
});
}

//	
	

	
	
//CHECK THE USER LOGGED IN
function checkUserLoggedIn(TroupeBaseID, SessionID, device)
{
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "../formhandlers/checkuserloggedin.php",
method: "POST",
data: {
TroupeBaseID: TroupeBaseID,
SessionID: SessionID,
device: device,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}
	
	
	
	
//LOGOUT
$("body").on("click", "#logout",function(){
loguserout();
});
	
function loguserout(){
var device = getDevice();
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
var SessionID = localStorage.getItem('SessionID');
localStorage.setItem('TroupeBaseID','null');
localStorage.setItem('SessionID','null');
localStorage.setItem('TimeZone','null');
document.cookie = "TroupeBaseID=;expires=Thu, 01 Jan 1970 00:00:00 GMT;domain=.troupebase.com;path=/";
document.cookie = "SessionID=;expires=Thu, 01 Jan 1970 00:00:00 GMT;domain=.troupebase.com;path=/";
document.cookie = "TimeZone=;expires=Thu, 01 Jan 1970 00:00:00 GMT;domain=.troupebase.com;path=/";
$("#logo").css("display", "none");
$.ajax({
url: "https://troupebase.com/formhandlers/logout.php",
method: "POST",
data: {
isWebsite: 1,
TroupeBaseID:TroupeBaseID,
SessionID: SessionID,
device: device
},
success: function(response){
if(response == "success"){
location.reload(true);
}
}
});	
	


}
//logout		
	
	
	
//ULI
var userLoggedIn = undefined;	
var userLoggedInProfilePic = "";
var userLoggedInName = "";
var userLoggedInState = "";
var userLoggedInCity = "";
var userLoggedInCountry = "";
var userLoggedInTalents = "";
var ulik;
var userLoggedInAlias = undefined;
var myTalentString = $("#myTalentString").attr("value");
var messageReceipt = $("#myMessageReceipt").attr("value");
var timeZone = $("#myTimeZone").attr("value");

function getCookies()
{
var cookies = document.cookie
  .split(';')
  .map(cookie => cookie.split('='))
  .reduce((accumulator, [key, value]) => ({ ...accumulator, [key.trim()]: decodeURIComponent(value) }), {});
return cookies;
}
	


function getUrl()
{
return window.location.href;
}
	



	

	
//uli
	
var passwordResetEmail;
var commentPhoto = $("#myCommentPhoto").attr("value");
	
var currentHref = window.location.href;
	
var clickDelay = 0;
	
	
var projectReplyTo = 0;	
	
	
var cfpt = "other";	
	
var newMessageTo;
var currentConvo;
var convoIsDeleted = 0;
var convoPrivacy = 0;
var otherUser;
var collabTo;
var convoEnded = 0;
	
var totalConvoLoaded = 0;
	
var messageOrCollab;
var sendNewMessageToSearch;	
var sendNewMessageToSearchStart = 10;
var sendNewMessageToSearchLimit = 10;

	
var scrollTime;
var cst = 0;
	
	
	
var newProfilePicInputUrl;	
var selectedProfFilter = 0;
var newProfilePicURL;
	
var isCollabId = "undefined";
var projectToApply;
	
var troupeSliderShowing = "requests"; 
var troupeToSearch;
var troupeSliderStart = 0;
	
var myTroupesStart = 0;

var boxToLoad = "INBOX";
var messagesStart = 15;
var messagesLimit = 15;

var convoRefreshTimer;
var lastMessageDate = 0;
var convoStart = 15;
var convoLimit = 15;
var name;
	
var messageFileURL;	
var currentFileSendType;
	

var postToReport;	
var reportType;
var postedByID;

	
	
var deleteBlinker;
var deletePostActive = 0;	
	
var postStart = 7;
var postLimit = 7;
	

	

var postPreviewContainer = document.getElementById("postPreviewContainer");
var fileToAddToPortfolio = document.getElementById("fileToAddToPortfolio");

	
	
var croppedOrOriginal = "cropped";	

var editable;
var editablePostComment;
var editablePostShare;
var previousWord;	

	
var isSeeking = 0;
	
var postCreateStep = 0;
var postUrl = "";	
var postUrlAudioCover = "";
var postUrlVideoCover="";
var videoCoverCroppieResult="";
var selectedVideoFit = "cover";
var postType;	
var selectedFilter = "0";
var postComment;	
var currentPostID;
var taggedString = ",";
var workedWithString = ",";	
var audioPostCoverURL;
	
var postCommentTagString = ",";
var previousWordToReplace = "";
	
var currentUsersPost;
var currentPostViewType;
var currentPostSource;
	
var video;
var videoPostCreate;
	
var audio = new Audio();
var audioFrom = "";
var currentAudioTime = document.getElementById('currentMediaTime');
var mediaSeeker = document.getElementById('mediaSeeker');	
	
var audioPostCreate = undefined;

var videoFrameCanvas;

var postVCnt = 0;

var pauseAllAudioVideo = 0;
	
var postExtrasToLoad = "";

//SUGGESTIONS
	
//CLOSE CONTAINER
$("body").on("click", ".closeMiscButton", function(){
$(".miscWrap").animate({width: "0%"}, "1000");
$(".miscWrap").fadeOut("slow");
setTimeout(function(){
$(".userSuggestionsContainer").empty();
$(".projectSuggestions").empty();
}, 2000);
});
//close container


if(currentHref.includes("troupebase.com/homebase.php")){	

}

function getSuggestions(){

$.ajax({
url: "../getsuggestions.php",
method: "POST",
data: {
getSuggestions: 1,
myTalentString: myTalentString

},
success: function(response){
constructSuggestions(response);
}
});		
	
$(".miscWrap").fadeIn(10);
$(".miscWrap").animate({width: "100%"}, "2000");
}

	
//FUNCTION CONS SUGG
function constructSuggestions(response){
var data = JSON.parse(response);

	
//SUGG USER
var suggestedUsers = data[0];
for(var i = 0; i < suggestedUsers.length; i++){
var user = suggestedUsers[i];

	
$(".userSuggestionsContainer").append("<div class='eachProjectGoal eachSuggestedUser"+user.id+"' style='margin-top: 0px; margin-bottom: 20px;'><div class='suggestedContent eachSuggestedUserContent"+user.id+"' style='color: white;'><img class='viewProfile' data-id='"+user.id+"' style='border: none; background-color: black; margin-top: 5px;' src='"+user.profilePic+"'><p>"+user.name+", "+user.state+"<br>"+user.talent+"</p><p style='margin-top: 5px; font-size: 15px;'>"+user.about+"</p></div></div>");
	
	
}
//sugg user

	
	
	
	
	
//SUGG PROJECTS
	var suggProjects = data[1];
for(var i = 0; i < suggProjects.length; i++){
var project = suggProjects[i];

$(".projectSuggestions").append("<div class='eachProjectGoal eachProjectGoal"+project.projectID+"'></div>");

$(".eachProjectGoal"+project.projectID).append("<div class='projectGoalContent projectGoalContent"+project.projectID+"'><img style='margin-top: 5px;' data-id='"+project.user+"' id='projectGoalProfilePic"+project.projectID+"' class='projectGoalProfilePic viewProfile projectGoalProfilePic"+project.projectID+"' src='"+project.profilePic+"'><p class='pgUserName"+project.projectID+"'>"+project.username+", "+project.userState+"</p><p class='projectGoalSubject"+project.projectID+"' id='projectGoalSubject"+project.projectID+"'>"+project.subject+"</p><p class='requiredPgTalent"+project.projectID+"' id='requiredTalent"+project.projectID+"'>For: "+project.requiredTalent+"</p><p style='font-size: 9px;' class='pgDateTime"+project.projectID+"'>"+project.dateTime+"</p><p id='projectGoalDet"+project.projectID+"' class='projectGoalDet"+project.projectID+"' style='Margin-top: 5px; white-space: pre-line; font-size: 14px;'>"+project.details+"</p></div>");
	
if(project.state !== ""){
$("#requiredTalent"+project.projectID).append(" in "+project.state);
}
$(".eachProjectGoal"+project.projectID).append("<button class='reportPG reportPG"+project.projectID+"' value='"+project.projectID+"' data-user = '"+project.user+"'>Report</button>");
	
	
	
	
	
	
//ICON
$(".eachProjectGoal"+project.projectID).append("<div style='margin-bottom: 5px;' class='projectGoalIcons projectGoalIcons"+project.projectID+"'>");
$(".projectGoalIcons"+project.projectID).append("<img class='sharePg sharePg"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/share.png'>");
if(userLoggedIn !== project.user){
$(".projectGoalIcons"+project.projectID).append("<img class='interested' id='interested"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/applyone.png'>");
}
if(userLoggedIn == project.user){
$(".projectGoalIcons"+project.projectID).append("<img class='viewInterested' value='"+project.projectID+"' data-subject='"+project.subject+"' src='https://troupebase.com/assets/applicant.png'>");
}
//icons	
	
	
//REPORT SLIDEDOWN
$(".eachProjectGoal"+project.projectID).append("<div class='reportPgSlider reportPgSlider"+project.projectID+"'>REPORT THIS PROJECT?<button class='confirmProjectGoalReport' style='color' data-user='"+project.user+"' data-id='"+project.projectID+"'>YES</button></div>");	
//report slidedown
	


	
	
}
//sugg projects
	
	
	
	
	
	
	
	
	
	

}
//function const sugg


//suggestions












	
	
//MEDIA CONTROLS
	

$("body").on("mousedown touchstart", ".mediaSeeker", function(){
isSeeking = 1;
});	
$("body").on("mouseup touchend", ".mediaSeeker", function(){
isSeeking = 0;
});	
	
$("body").on("input", ".mediaSeeker", function(){
var value = $(this).val();
value = Math.round(value);
var type = $(this).attr("data-type");
if(type == "audio"){
audio.currentTime = audio.duration * (value/100);
}
if(type == "video"){
video.currentTime = video.duration * (value/100);
}
isSeeking = 0;
});	


	
	



	

//RESUME POST


$("body").on("click", ".playPost",function(){
var postVCnt = $(this).attr("data-postVCnt");
var file = $(this).attr("data-file");
var postType = $(this).attr("data-posttype");
	
$(this).slideUp("fast");
$(".pausePost"+postVCnt).slideDown("fast");
	
//AUD
if(postType == "audio"){
if(audio.src == file){
audio.play();
}else{
loadAudio(postVCnt, file);
}
}
//aud
	
//VID
if(postType == "video"){
if(video.src == file){
video.play();
}else{
loadVideo(postVCnt, file);
}
}
//vid	
	
	
});
//RESUME POST


	

	




$("body").on("click", ".pausePost",function(){
var postVCnt = $(this).attr("data-postvcnt");
$(".playPost"+postVCnt).slideDown("fast");
$(".pausePost"+postVCnt).slideUp("fast");
if(audio.play){
audio.pause();
}
if(video.play){
video.pause();
}
});
	




//media controls
	
	


	



	
	
//TAGGED AND OTHER
	



//tagged and other
	



//DISCOVER

$("body").on("mousedown", ".showDiscFilt", function(){
$(".discoverFilterWrap").fadeIn("fast");
});
$("body").on("mousedown", ".hideDiscoverFilter", function(){
$(".discoverFilterWrap").fadeOut("fast");
});
$(".discoverTalentFilter").on("change", function(){
var talent = $(this).val();
var state = $(".discoverStateFilter").val();
window.location = "https://troupebase.com/discover.php?talent="+talent+"&state="+state+"";
});
$(".discoverStateFilter").on("change", function(){
var state = $(this).val();
var talent = $(".discoverTalentFilter").val();
window.location = "https://troupebase.com/discover.php?talent="+talent+"&state="+state+"";
});
//discover


















//TOGGLE VIDEO FIT

//toggle video fit
	
	
	
	
//POST INTERACTIONS
	
	



	








	







	




	



//FUNCTION KEEP TRACK OF TAGS

	
function keepTrackOfPostAts(){
	console.log("@ = " + taggedString)
var caption = $(editablePostShare).html();
var tagsCheck =taggedString.split(',');
for(i=0; i<tagsCheck.length - 1; i++){
var currentTag = tagsCheck[i];
if(caption.includes("@"+currentTag)){
}else{
if(taggedString !==","){
taggedString = taggedString.replace(currentTag+",", "");
}
}
}
}
	
	

	


function keepTrackOfCommentAts(){

var caption = $(editablePostComment).html();
var tagsCheck = postCommentTagString.split(',');
for(i=0; i<tagsCheck.length - 1; i++){
var currentTag = tagsCheck[i];
if(caption.includes("@"+currentTag)){
}else{
if(postCommentTagString !== ","){
postCommentTagString = postCommentTagString.replace(currentTag+",", "");
}
}
}

}

//keep trach of tags

	
	











	



	



	
	
//STARS
$("body").on("mousedown", ".submitStar", function(){
var postID = $(this).attr("value");
var user = $(this).attr("data-user");
var rank = "up";
$(this).slideUp(10);
$(".undoStar"+postID).slideDown(10);
$(".goldStar"+postID).slideDown(10);
$(".star"+postID).slideUp(10);
$(".postContainer"+postID).attr("data-liked", "1");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: #214844'>LIKED!</p>");
$("#successResponseDropDown").slideDown(50);
setTimeout(function(){
$("#successResponseDropDown").slideUp(50);
}, 1500);
updateRank(rank, postID, user);
});
$("body").on("mousedown", ".undoStar", function(){
var postID = $(this).attr("value");
var rank = "down";
var user = $(this).attr("data-user");
$(this).slideUp(10);
$(".submitStar"+postID).slideDown(10);
$(".star"+postID).slideDown(10);
$(".goldStar"+postID).slideUp(10);
$(".postContainer"+postID).attr("data-liked", "0");
updateRank(rank, postID, user);
});
//stars
	
	



	
	
//GET POST	


function getPost(postID, dateTime)
{
$.ajax({
url: "../formhandlers/getpost.php",
method: "POST",
data: {
postID: postID,
isWebsite: 1
},
success: function(response){
viewPost(response, dateTime);
clickDelay = 0;
}
});	
}


//get post
	






$("body").on("click", ".star", function(){
var id = $(this).attr("value");
$(this).slideUp(10);
$(".goldStar"+id).slideDown(10);
});
$("body").on("click", ".goldStar", function(){
var id = $(this).attr("value");
$(this).slideUp(10);
$(".star"+id).slideDown(10);
});
//post interactions
	
	
	
	
	



	

	
//SELECTED AUDIO PLAYER//
$("body").on("click", ".playSelectedAudio", function(){
$(this).slideUp(50);
$(".pauseSelectedAudio").slideDown(50);
if(audio.pause){
audio.play();
}
});
$("body").on("click", ".pauseSelectedAudio", function(){
$(this).slideUp(50);
$(".playSelectedAudio").slideDown(50);
if(audio.play){
audio.pause();
}
});
//
	
	





	

	
	

	






	


//SHARE VIDEO
function shareVideo(){

var video = document.getElementById("fileToShare").files[0];	
var caption = $("#shareSomethingDesc").html();	
caption = stripHtmlFromString(caption);
	
var formdata = new FormData();
	
formdata.append("video", video);
formdata.append("videoFit", "-");
formdata.append("thumbTime", thumbTime);
formdata.append("caption", caption);
formdata.append("partOfPortfolio", partOfPortfolio);
formdata.append("optionalPostLink", optionalLink);
formdata.append("taggedString", taggedString);
formdata.append("workedWithString", workedWithString);
formdata.append("selectedFilter", selectedFilter);
formdata.append("shareCity", shareCity);
formdata.append("shareState", shareState);
formdata.append("shareCountry", shareCountry);
formdata.append("userTalents", userLoggedInTalents);
formdata.append("isWebsite", 1);
var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", requestProgress, false);
ajax.addEventListener("load", shareAjaxResponse, false);
ajax.open("POST", "https://troupebase.com/formhandlers/sharevideo.php");
ajax.send(formdata);		

clickDelay = 0;	
}




	




//SHARE AUDIO
function shareAudio(){
if(shareFromCroppieOrOriginal == "croppie"){
var audioCover = selectedCoverForAudioURL;
}else{
var audioCover = document.getElementById("selectedCoverForAudio").files[0];	
}
	
var audio = document.getElementById("fileToShare").files[0];	

var caption = $("#shareSomethingDesc").html();	
caption = stripHtmlFromString(caption);
	
var formdata = new FormData();
formdata.append("audio", audio);
formdata.append("audioCover", audioCover);
formdata.append("coverExt", selectedCoverForAudioExt);
formdata.append("ext", fileToShareExt);
formdata.append("partOfPortfolio", partOfPortfolio);
formdata.append("optionalLink", optionalLink);
formdata.append("taggedString", taggedString);
formdata.append("workedWithString", workedWithString);
formdata.append("caption", caption);
formdata.append("originalOrCrop", shareFromCroppieOrOriginal);
formdata.append("selectedFilter", selectedFilter);
formdata.append("shareCity", shareCity);
formdata.append("shareState", shareState);
formdata.append("shareCountry", shareCountry);
formdata.append("userTalents", userLoggedInTalents);
formdata.append("isWebsite", 1);
var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", requestProgress, false);
ajax.addEventListener("load", shareAjaxResponse, false);
ajax.open("POST", "https://troupebase.com/formhandlers/shareaudio.php");
ajax.send(formdata);	
	

clickDelay = 0;
}

	

//STRIP HTML TAGS FROM STRING
function stripHtmlFromString(text){
return text.replace(/(<([^>]+)>)/gi, "");
}




//SHARE PHOTO
function sharePhoto()
{

	
if(shareFromCroppieOrOriginal == "croppie"){
var photo = shareCroppieURL;
}else{
var photo = document.getElementById("fileToShare").files[0];	
}

	
var caption = $("#shareSomethingDesc").html();	
caption = stripHtmlFromString(caption);


var formdata = new FormData();
formdata.append("photo", photo);
formdata.append("ext", fileToShareExt);
formdata.append("partOfPortfolio", partOfPortfolio);
formdata.append("optionalLink", optionalLink);
formdata.append("taggedString", taggedString);
formdata.append("workedWithString", workedWithString);
formdata.append("caption", caption);
formdata.append("originalOrCrop", shareFromCroppieOrOriginal);
formdata.append("selectedFilter", selectedFilter);
formdata.append("shareCity", shareCity);
formdata.append("shareState", shareState);
formdata.append("shareCountry", shareCountry);
formdata.append("userTalents", userLoggedInTalents);
formdata.append("isWebsite", 1);
var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", requestProgress, false);
ajax.addEventListener("load", shareAjaxResponse, false);
ajax.open("POST", "https://troupebase.com/formhandlers/sharephoto.php");
ajax.send(formdata);	

	
	
}

//photo


	







//next step

//ADD POST FUNCTION
function addPost(response)
{
clickDelay = 0;
$(".audioPostUploadSlider").remove();
$("#successResponseDropDown").slideUp();
$(".eachUpSlider1").remove();
$(".eachUpSlider2").remove();
$(".videoPostUploadSlider").remove();
removeProgressBar();
removeLayOver();
	
var post = JSON.parse(response);

var postTypeIcon = "";
if(post.type == "a"){
postTypeIcon = "../assets/audio3.png";
}
if(post.type == "v"){
postTypeIcon = "../assets/video.png";
}	

$(".portfolioScroll").prepend("<div class='postContainer' id='postContainer"+post.postID+"' data-id='"+post.postID+"' data-datetime = 'Now'><img src='"+post.coverPhoto+"' class='filter"+post.filter+"'><div class='posttypeicon posttypeicon"+post.postID+"'><img id='postTypeImg"+post.postID+"' src='"+postTypeIcon+"'></div> </div>");	
	
if(post.type == "p"){
$(".posttypeicon"+post.postID).remove();
}	
if(post.type == "a"){
$("#postTypeImg"+post.postID).css("width", "14px");
$("#postTypeImg"+post.postID).css("height", "14px");
}	
	
	
$("#postContainer"+post.postID).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var postID = $(this).attr("data-id");
var dateTime = $(this).attr("data-datetime");
getPost(postID, dateTime);
}
});	
	
	
}
	
	

function loadLayOver()
{
$("#profileLoaderContainer").append("<div class='universalcontainer layover' style='width: 100%; background-color: transparent;'></div>");
}
function removeLayOver()
{
$(".layover").remove();
}







$("body").on("click", ".closeUploadSlider", function(){
$(".uploadSlider").slideUp(50);	
resetPostEditor();
});



	
$("body").on("click", ".addToPortfolio", function(){
$("#fileToAddToPortfolio").trigger("click");
});
	
	









	













	




	
//PROGRESS STUFF
function loadProgressBar()
{
$("#profileLoaderContainer").append("<div id='progressBarSlider'><div id='progressBarContainer'><div id='progressBarMessage'><p id='progressBarStatus'>0%</p></div><div id='progressBarMessageFill'></div></div></div>");
}

function requestProgress(e){
var total = (e.loaded/e.total) * 100;
total = Math.round(total);
$("#progressBarStatus").text("POSTING: "+total+"%");
$("#progressBarMessageFill").css("width", total+"%");
if(total == 100){
$("#progressBarStatus").text("Please Wait..");
}
}	
function removeProgressBar()
{
$("#progressBarSlider").remove();
}
	


function shareAjaxResponse(e){
clickDelay = 0;
	
if(e.target.responseText == "fstl" || e.target.responseText == "error"){
shareError();
return;
} 
if(e.target.responseText.includes("error")){
shareError();
return;
} 


addNewPostToFeed(e.target.responseText);		

}

	
	


//ADD NEW POST TO FEED
function addNewPostToFeed(response){

resetPostEditor();
removeLayOver();
removeProgressBar();
	
	
var data = JSON.parse(response);
var post = data[0];

	
	
	
var container = $("#feedScroll"+userLoggedIn);
var justPosted = 1;
constructMediaPost(post, container, justPosted);	
	
	
	
}












function shareError(){
$("#confirmShareButton").css("background-color", "#718785");
$("#confirmShareButton").text("SHARE!");
removeLayOver();
removeProgressBar();
showAlert("Upload Failed", "red");
}

//







	


	







$("body").on("change", ".cr-slider", function(){
$image_crop.croppie('result', {
type: 'canvas',
size: 'viewport'
}).then(function(response){
postUrl = response;
});
});
	

//TOGGLE FULL POST PHOTO
$("body").on("mousedown", ".ufpfp", function(){
var value = $(this).attr("value");
if(value == "cropper"){
$(this).attr("value","full");
$('#uploadimageForPhoto').croppie('destroy');
$(this).text("CROP");
drawPostPhotoToCanvas();
croppedOrOriginal = "original";
}
if(value == "full"){
$(this).attr("value","cropper");
$(this).text("USE ORIGINAL");
$(".photoPostUploadSlider").empty();
loadPhotoPostControlOne();
croppedOrOriginal = "cropped";
}
})

	

function drawPostPhotoToCanvas()
{
var nw, nh, canvas, cw, h, aspect, ctx;
	
var fileToAddToPortfolio = document.getElementById("fileToAddToPortfolio");
postUrl = URL.createObjectURL(fileToAddToPortfolio.files[0]);	
var img = new Image();
img.src = postUrl;	
	
img.onload = function(){
	
$(".photoPreviewWrap").append("<img id='fullPhotoPreviewImgDimensions' src='"+postUrl+"' style='width: 100%; height: auto;'>");	
$(".previewWrap").css("height", "auto");

var imagewidth = $("#fullPhotoPreviewImgDimensions").width();
var imageheight = $("#fullPhotoPreviewImgDimensions").height();

$(".photoPreviewWrap").append("<canvas id='photoPreviewCanvasForOriginalSize' style='width: 100%; height: "+imageheight+"px'></canvas>");
$("#fullPhotoPreviewImgDimensions").remove();
	alert("now");
canvas = document.getElementById("photoPreviewCanvasForOriginalSize");
ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;
cw = canvas.width;
nw = img.naturalWidth;
nh = img.naturalHeight;
aspect = nw / nh;
h = cw / aspect;
canvas.height = h;
ctx.drawImage(img, 0, 0, cw, h);	
setTimeout(function(){
postUrl = canvas.toDataURL();
}, 500);
}
	
}




	






$("body").on("click", ".closeCollabCon", function(){
var collabConCount = $(this).attr("value");
$(".colabcon"+collabConCount).fadeOut("slow");
setTimeout(function(){
$(".colabcon"+collabConCount).remove();
closeDivLoader();
}, 1000);
});


	
	

//TOGGLE MY POSTS
var collabConCount = 0;
$("body").on("mousedown", ".filterPortfolio", function(){
var user = $(this).attr("data-user");
$(".myPostTogCon"+user).slideToggle(50);
});
	
$("body").on("mousedown", ".toggleMyCollabs", function(){
var user = $(this).attr("data-user");
var name = $(this).attr("data-name");
$(".myPostTogCon"+user).slideToggle(50);
conCollabsCon(user, name, collabConCount);
collabConCount = collabConCount + 1;
});
	

//CONSTRUCT COLLAB POSTS
function conCollabsCon(user, name, collabConCount){
$("#profileLoaderContainerSlider").slideDown(100);
$("#profileLoaderContainer").append("<div class='colabcon colabcon"+collabConCount+"'><div class='colabconhead'><i class='fas fa-backspace closeCollabCon backarrows' value='"+collabConCount+"' style='position: absolute; left: 10%; top: 5px;'></i>"+name+"'s Collaborations</div><div class='collPostScroll collPostScroll"+collabConCount+"' id='collPostScroll"+collabConCount+"' data-scrollstart = '0' data-user='"+user+"' data-container='"+collabConCount+"'></div></div>");
var start = $(".collPostScroll"+collabConCount).attr("data-scrollstart");
loadCollabPosts(user, collabConCount, start);
}
	


function loadCollabPosts(user, collabConCount, start){
$.ajax({
url: "https://troupebase.com/colposts.php",
method: "POST",
data: {
user: user,
start: start,
loadPosts: 1,
timeZone: timeZone
},
success: function(response){
constrCollabPosts(response, user, collabConCount, start);
}
});
}
	
	


//CON COLLAB POSTS
function constrCollabPosts(response, user, collabConCount, start){
$(".colabcon"+collabConCount).fadeIn("slow");
if(response == "end"){
return;
}
var newStart = parseInt(start) + 12;
$(".collPostScroll"+collabConCount).attr("data-scrollstart", newStart);

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var collab = data[i];	
	

	
if(collab.type=='photo'){
collab.coverPhoto = collab.file;
}


$(".collPostScroll"+collabConCount).append("<div class='eachColPost eachColPost"+collabConCount+" eachColPost"+collab.postID+"'><div class='clcollab clcollab"+collab.postID+"'><br><br>REMOVE YOURSELF FROM THIS COLLABORATION?<br><button class='conbuttneg confirmleavecoll' data-postid='"+collab.postID+"'>YES</button></div><div class='eachcolposttop'><div class='eachcolpostleft'><p><span style='font-size: 10px'>Likes: "+collab.totalranks+"<br>"+collab.dateTime+"</span><br>"+collab.caption+"</p></div><div class='eachcolpostright'><img src='"+collab.coverPhoto+"' class='viewThisPost' data-id='"+collab.postID+"'></div></div><img class='star"+collab.postID+"' src='https://troupebase.com/assets/notliked.png' style='display: none; width: 15px; height: 15px;'><img class='goldStar"+collab.postID+"' src='https://troupebase.com/assets/liked.png' style='display: none; width: 15px; height: 15px;'><br>Collaborations:<div class='castlist castlist"+collab.unix+"'></div><div class='reportPostContainer'><button class='reportcolpost conbuttneg' style='font-size: 10px;' data-user='"+collab.postID+"'>Report</button><button style='font-size: 10px;' data-postid='"+collab.postID+"' class='leavecol'>Leave Collab</button></div><div class='confirmReportPostContainer confirmReportColContainer"+collab.postID+"'>CONFIRM REPORT POST?<button class='conColPostReportButton confirmPostReportButton"+collab.postID+"' data-user = '"+collab.user+"' data-postid='"+collab.postID+"'>YES</button></div></div>");
	
	
var collabedusers = collab.collabarray;
for(var j = 0; j < collabedusers.length; j++){
var collabuser = collabedusers[j];	

var talent = collabuser.talent;
talent = talent.replace(/,\s*$/, "");
	
$(".castlist"+collab.unix).append("<div class='eachCollab'><div class='eachCollabCont'><div class='selworkwithimage'><img src='"+collabuser.pic+"' class='viewProfile' data-id='"+collabuser.troupeID+"'></div><div class='selworkwithdet' style='padding-left: 3px'>"+collabuser.name+"<br>"+talent+"</div></div></div>");
	
}
	
	
if(collab.liked == 1){
$(".goldStar"+collab.postID).slideDown(10);
}else{
$(".star"+collab.postID).slideDown(10);
}
	
	
$(".collPostScroll"+collabConCount).on("scroll", function(){
var user = $(this).attr("data-user");
var collabConCount = $(this).attr("data-container");
var start = $(this).attr("data-scrollstart");
var elmnt = document.getElementById("collPostScroll"+collabConCount);
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
loadCollabPosts(user, collabConCount, start)
}
}, 150);
});

	
}
}
	



	
$("body").on("click", ".sharePost", function(){
var postID = $(this).attr("value");
});
	


	
	
$("body").on("click", ".confirmleavecoll", function(){
var id = $(this).attr("data-postid");
leavecolpost(id);
});
	


function leavecolpost(id){
$.ajax({
url: "../formHandlers/leavecolpost.php",
method: "POST",
data: {
id: id
},
success: function(response){
if(response=="success"){
$(".clcollab"+id).text("<br><br>YOU LEFT THIS COLLAB");
$(".clcollab"+id).slideDown("fast");
setTimeout(function(){
$(".eachColPost"+id).fadeOut("slow");
},2000);
}
}
});
}



$("body").on("click", ".leavecol", function(){
var id = $(this).attr("data-postid");
$(".clcollab"+id).slideDown("fast");
setTimeout(function(){
$(".clcollab"+id).slideUp("fast");
}, 2500);
});



//con col posts
	
	



	



//FILE SELECT
	
$("body").on("click", ".selectAudioIcon", function(){
$("#audioCoverInput").trigger("click");
});
	








$("body").on("click", ".selectVideoCover", function(){
$("#videoCoverInput").trigger("click");
});
	
$("body").on("change", "#videoCoverInput", function(){
var file = $(this).val();
var ext = file.split('.').pop();
ext = ext.toLowerCase();
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){

var videoCoverInput = document.getElementById("videoCoverInput");
postUrlVideoCover = URL.createObjectURL(videoCoverInput.files[0]);	

$('.videoCoverPreview').croppie('destroy');
setTimeout(function(){
var width = $(".videoCoverPreview").width();
var square = width - 20;	
	
$image_crop = $(".videoCoverPreview").croppie({
enableExit: true,
viewport: {
width: square,
height: square,
type: 'square'
},
boundary: {
width: width,
height: width
}
});	

	
$image_crop.croppie('bind', {
url: postUrlVideoCover
});

$(".postCreatorNext").slideDown("fast");	
$(".selectVideoCoverContainer").slideDown("fast");
$(".nextPostStepVideo").slideDown(10);
	
},300);	
	
	
	
	
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>COVER MUST BE A PHOTO</p>");
showSuccess();	
}
	

});

	



	




//file select
	


	







//GET POSTS
function loadPosts(user, time){
var start = $(".portfolioScroll"+time).attr("data-start");
$.ajax({
url: "../formhandlers/loadposts.php",
method: "POST",
data: {
user: user,
start: start,
limit: 10,
isWebsite: 1
},
success: function(response){
constructPosts(response, time, start);
}
});	
}

//view portfolio	
	
	
	
	
	
	
	

	
	
//RESET MY POST
function rbtomp(){
$(".togposts").css("background-color", "transparent");
$(".togposts").css("color", "black");
$(".toggleMyPosts").css("background-color", "#214844");
$(".toggleMyPosts").css("color", "white");
$(".portfolioScroll"+userLoggedIn).slideDown();
}
//
	
	

$(".cancelPostToPortfolio").on("click", function(){
$(".addToPortfolioContainer").slideUp(50);
});	
	
	





	

	


	



//SELECT PHOTO
$("body").on("click", ".selectPostIcon", function(){
$("#fileToAddToPortfolio").trigger("click");
});
//
	


	





	







	
//CHANGE FILTER
$("body").on("mousedown", ".eachFilter", function(){
$(".eachFilter").css("border", "none");
$(this).css("border", "5px solid #214844");
selectedFilter = $(this).attr("value");
for(var i = 0; i<17; i++){
$(".postfinalPrevImg").removeClass("filter"+i);
}
$(".postfinalPrevImg").addClass("filter"+selectedFilter);

if($(".previewVideo").is(":visible")){
for(var i = 0; i<17; i++){
$(".previewVideo").removeClass("filter"+i);
}
$(".previewVideo").addClass("filter"+selectedFilter);
}
	
	
});
	

$("body").on("mousedown", ".vidfilter", function(){
$(".vidfilter").css("border", "none");
$(this).css("border", "5px solid #214844");
selectedFilter = $(this).attr("value");
for(var i = 0; i<17; i++){
$("#previewVideo").removeClass("filter"+i);
}
$("#previewVideo").addClass("filter"+selectedFilter);
	
});
	
	


//change filter
	


	






/*portfolio POST*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//GOT TO BUSINESS
$(".baseBusiness").on("mousedown", function(){
$("body").fadeOut(1500);
setTimeout(function(){
window.location = "https://troupebase.com/business/business.php";
}, 2000);
});
//	
	
	
	
	

	
	
	
	
	
	

	
	
	
	
	
	
	
	












	
	
	
	
	
	
	
//GO TO SHED
$(".shedIcon").on("click", function(){
$("body").fadeOut(3000);
setTimeout(function(){
window.location = "https://troupebase.com/shed.php";
},3100);
});
//
	
	
	
	
	

	


	
	
	
//FEATURE ME
$("body").on("click", ".allowfeature", function(e){
var featurePermission = $(this).attr("value");
$(".featurepermission").slideUp(150);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>Please Wait..</p>");
$("#successResponseDropDown").slideDown(50);
$.ajax({
url: "https://troupebase.com/formHandlers/featureuser.php",
method: "POST",
data: {
featurePermission: featurePermission
},
success: function(response){
if(response == "success"){
if(featurePermission == "1"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>YOU WILL BE NOTIFIED IF YOU ARE FEATURED</p>");
$(".featurestatus").text("You Are Opted In!");
setTimeout(function(){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>YOU MAY OPT OUT IN YOUR SETTINGS</p>");
}, 3000);
setTimeout(function(){
$("#successResponseDropDown").slideUp(50);
}, 6000);
}else{
$(".youAreCurrentlyFeatured").slideUp();
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>YOU WILL NOT BE FEATURED</p>");
$(".featurestatus").text("You Are Opted Out!");
setTimeout(function(){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>YOU MAY OPT BACK IN IN YOUR SETTINGS</p>");
}, 3000);
setTimeout(function(){
$("#successResponseDropDown").slideUp(50);
}, 6000);
}
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>SOMETHING WENT WRONG</p>");
$(".featurestatus").text("You Are Opted Out!");
setTimeout(function(){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>YOU MAY OPT IN IN YOUR SETTINGS</p>");
}, 3000);
setTimeout(function(){
$("#successResponseDropDown").slideUp(50);
}, 6000);
}
}
});
});

$(".showFeatureOpt").on("click", function(){
$(".featurepermission").slideDown(50);
});
	

//feature me
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//PASSWORD RESET
	
	
$("body").on("click", "#submitNewPassword", function(){		
var newpwd = $("#newPassword").val();
var confirmPwd = $("#confirmNewPassword").val();
if(newpwd !== confirmPwd){
alert("PASSWORDS DO NOT MATCH");
return;
}
if(newpwd.length < 8){
alert("PASSWORD 8 CHARACTERS MINIMUM");
return;
}
$("#submitNewPassword").slideUp(50);
$.ajax({
url: "https://troupebase.com/resetpwd.php",
method: "POST",
data: {
newpwd: newpwd,
email: passwordResetEmail,
submitNewpwd: 1
},
success: function(response){
if(response == "success"){
$(".cancelPasswordReset").trigger("click");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>PASSWORD SUCCESSFULLY UPDATED</p>");
showSuccess();
setTimeout(function(){
var loc = "https://troupebase.com/homebase.php";
window.location = loc;
}, 2000);
}else{
$("#submitNewPassword").slideDown(50);
alert("SOMETHING WENT WRONG, TRY AGAIN");
}
}
});
});	
	
	
	
	
	
	
$("body").on("click", "#submitPwdResetPin", function(){	
var pin = $("#paswordResetPin").val();
if(pin.length>10){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>INCORRECT PIN</p>");
showSuccess();	
return;
}
if(pin == ""){
alert("ENTER RESET CODE");
}else{
$("#submitPwdResetPin").slideUp(50);
$.ajax({
url: "https://troupebase.com/resetpwd.php",
method: "POST",
data: {
pin: pin,
email: passwordResetEmail,
submitPasswordPin: 1
},
success: function(response){
if(response == "success"){
$("#accountToReset").slideUp(50);
$("#newPasswordSlider").slideDown(50);
}
if(response=="accountnotfound"){
alert("ACCOUNT NOT FOUND");
$("#submitPwdResetPin").slideDown(50);
}
if(response=="incorrectpin"){
alert("INCORRECT PIN");
$("#submitPwdResetPin").slideDown(50);
}
}
});
}
});
	
	
	
	
$("body").on("click", "#submitPwdReset", function(){	
var email = $("#paswordResetEmail").val();
if(email.length>100){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>CHECK CHARACTER LIMITS</p>");
showSuccess();
return;
}
passwordResetEmail = email;
if(email == ""){
alert("ENTER EMAIL");
}else{
$(this).slideUp(50);
$.ajax({
url: "https://troupebase.com/resetpwd.php",
method: "POST",
data: {
email: email,
submitPasswordReset: 1
},
success: function(response){
if(response == "success"){
$("#submitPwdReset").slideDown(50);
$("#accountToReset").slideUp(50);
$("#confirmPasswordResetPin").slideDown(50);
}else{
alert("ACCOUNT NOT FOUND");
$("#submitPwdReset").slideDown(50);
}
}
});
}
});
	
	
$("body").on("click", ".cancelPasswordReset", function(){	
$("#accountToReset").slideDown(50);
$("#submitPwdResetPin").slideDown(50);
$("#submitNewPassword").slideDown(50);
$("#confirmPasswordResetPin").slideUp(50);
$("#passwordResetSlider").slideUp(50);
$("#newPasswordSlider").slideUp(50);
});	
	
	
$("body").on("click", ".forgotPassword", function(){
$("#passwordResetSlider").slideDown(50);
});
//password reset
	
	
	
	
	
	
	
	
	
	
	

	
	
//BLOCKED USERS
	
	
$("body").on("click", ".confirmUnblock", function(){		
var id = $(this).attr("value");
$.ajax({
url: "../formhandlers/unblock.php",
method: "POST",
data: {
troupeID: id,
isWebsite: 1
},
success: function(response){
if(response == "success"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>User Unblocked</p>");
showSuccess();
$(".blockedUser"+id).fadeOut(1000);
}
}
});
});	
	
	
$("body").on("click", ".submitUnblock", function(){	
var id = $(this).attr("value");
$("#unblockMenu"+id).animate({"left":"110%"}, "fast");
$("#confirmUnblockSlider"+id).slideDown(50);
setTimeout(function(){
$("#confirmUnblockSlider"+id).slideUp(50);
}, 3000);
});	
	
	


	
	
	
$("body").on("mouseover touchstart", ".viewBlockedOptions", function(){
$(this).slideUp(50);
var id = $(this).attr("value");
$("#unblockMenu"+id).animate({"left":"65%"}, "slow");
setTimeout(function(){
$("#viewBlockedOptions"+id).slideDown(1000);
$("#unblockMenu"+id).animate({"left":"110%"}, "fast");
}, 3000);
});	
	
	
	
$("body").on("click", "#blockedUsers", function(){
var time = Date.now();
$("#profileLoaderContainer").append("<div id='blockedUsersSlider'><div id='blockedUsersBanner'><div id='closeBlockedUsers'><i class='fas fa-backspace closeBlockedUsers'></i></div><div id='blockedUsersHeading'><p>BLOCKED USERS</p></div></div><div id='blockedScroller' class='blockedScroller"+time+"' data-start='0'></div> </div>");
	
$(".blockedScroller"+time).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+300){
var start = $("#blockedScroller").attr("data-start");
getBlocked(start);
}
}, 170);
});


getBlocked(0);	
	
$("#blockedUsersSlider").animate({width: "100%"});	
	
});
	


function getBlocked(start)
{
	
var newStart = parseInt(start) + 7;
$("#blockedScroller").attr("data-start", newStart);
	
$.ajax({
url: "https://troupebase.com/formhandlers/blockedusers.php",
method: "POST",
data: {
isWebsite: 1,
start: start,
getBlocked: 1
},
success: function(response){
	alert(response);
conBlockUsers(response);
}
});
	
}

	
function conBlockUsers(response)
{

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var blocked = data[i];	

$("#blockedScroller").append("<div class='troupeBox blockedUser"+blocked.id+"' id='blockedUser"+blocked.id+"'><div class='confirmUnblockSlider' id='confirmUnblockSlider"+blocked.id+"'><br><span style='color: black; font-weight: bold;'>CONFIRM UNBLOCK?</span><br><button style='color: green;' class='confirmUnblock' value='"+blocked.id+"'>YES</button></div><button class='viewBlockedOptions' id='viewBlockedOptions"+blocked.id+"' value='"+blocked.id+"'><</button><div class='unblockMenu' id='unblockMenu"+blocked.id+"'><button class='submitUnblock' value='"+blocked.id+"'>UNBLOCK</button></div><div class='troupeBoxContent'><div class='troupePhoto'><img src='"+blocked.profilePic+"'></div><div class='troupeDetails'><p style='margin-top: 30px; margin-bottom: 0px; font-weight: bold;'>"+blocked.name+"</p><p style='margin: 0px;'>"+blocked.talents+"</p><p style='margin: 0px; font-weight: bold;'>"+blocked.state+"</p> </div></div></div>");
	
}
	
}
	
$("body").on("click", ".closeBlockedUsers", function(){
$("#blockedUsersSlider").animate({width: "0%"});	
setTimeout(function(){
$("#blockedUsersSlider").remove();	
}, 500);
});
//blocked users
	
	
	
	
	
	
	
	
	
	
	
	
	
//POLICIES

$("body").on("click", ".acceptPrivacy", function(){
$(".policySlider").remove();
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
if(TroupeBaseID !== undefined && TroupeBaseID !== "" && TroupeBaseID !== "undefined" && TroupeBaseID !== "null"){
}else{
$("#profileLoaderContainerSlider").slideUp(100);
}
});	
	
	
$("body").on("click", ".declineTermsOfUser", function(){
$.ajax({
url: "https://troupebase.com/formhandlers/verification.php",
method: "POST",
data: {
declineTermsOfUser: 1,
isWebsite: 1
},
success: function(){
loguserout();
}
});
});
	
	
//ACCEPT TOU
$("body").on("click", ".acceptTermsOfUse", function(){
$(".policySlider").fadeOut();
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
if(TroupeBaseID !== undefined && TroupeBaseID !== "" && TroupeBaseID !== "undefined" && TroupeBaseID !== "null"){
}else{
$("#profileLoaderContainerSlider").slideUp(100);
}
setTimeout(function(){
}, 500);
$.ajax({
url: "https://troupebase.com/formhandlers/verification.php",
method: "POST",
data: {
acceptTermsOfUse: 1,
isWebsite: 1
}
});
});	
	
	
	
$("body").on("click", ".viewPolicy", function(){
$("#profileLoaderContainerSlider").slideDown();
var policy = $(this).attr("value");
loadPolicy(policy);
});
	
function loadPolicy(policy){
$("#profileLoaderContainer").append("<div class='policySlider'><div class='policyHeading'><p style='margin: 0px;'>troupebase</p><p id='troupeBasePolicyName' style='margin: 0px;'>POLICY NAME</p></div><div class='policyScroller'><div class='policyContent'></div></div><div class='policyButtons'><!-- Buttons --></div></div>");
	
if(policy == "about"){
$(".policyContent").load("https://troupebase.com/policies/about.php",{
policy: policy
});
$(".policyButtons").append("<button style='background-color: white; color: green;' class='acceptPrivacy'>GOT IT</button>");
}
if(policy == "privacy"){
$("#troupeBasePolicyName").text("PRIVACY POLICY");
$(".policyContent").load("https://troupebase.com/policies/privacy.php",{
policy: policy
});
$(".policyButtons").append("<button style='background-color: white; color: green;' class='acceptPrivacy'>GOT IT</button>");
}	
if(policy == "dmca"){
$("#troupeBasePolicyName").text("DMCA NOTICE");
$(".policyContent").load("https://troupebase.com/policies/dmca.php",{
policy: policy
});
$(".policyButtons").append("<button style='background-color: white; color: green;' class='acceptPrivacy'>GOT IT</button>");
}	
if(policy == "tou"){
$("#troupeBasePolicyName").text("TERMS of USE");
$(".policyContent").load("https://troupebase.com/policies/termsofuse.php",{
policy: policy
});
$(".policyButtons").append("<p style = 'color: white; margin-top: 2px; margin-bottom: 0px;'>You must accept to continue</p>");
$(".policyButtons").append("<button style='border: none;' class='declineTermsOfUser'>Decline</button><button style='background-color: white; color: green;' class='acceptTermsOfUse'>ACCEPT</button>");
}	
	
	
	
$(".policySlider").animate({width: "100%"});
}

//policies
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
//EMAIL VERIFY
$("#submitEmailPin").on("click", function(){
$(this).slideUp(50)
var pin = $("#emailPinField").val();
if(pin == ""){
$("#submitEmailPin").slideDown(50);
alert("PLEASE ENTER PIN");
}else{

$.ajax({
url: "https://troupebase.com/formHandlers/verification.php",
method: "POST",
data: {
pin: pin,
checkEmailPin: 1
},
success: function(response){
if(response == "success"){
window.location = "https://troupebase.com/homebase.php";
}else{
alert("PIN DOES NOT MATCH");
$("#submitEmailPin").slideDown(50)
}
}
});

}
});
//email verify	
	
	
	
	
	
	
	
	
	
	
	
//PROJECT SEARCH

$("body").on("change", "#projectTalentFilter, #projectStateFilter", function(){
var talent = $("#projectTalentFilter").val();
var state = $("#projectStateFilter").val();
window.location = "https://troupebase.com/projectsearch.php?talent="+talent+"&state="+state;
});	
	
	
//project search
	
	
	
	

	
	
//APPLY UNAPPLY PROJECT GOAL
	
	


$("body").on("click", "#submitPgApp", function(){
var details = $("#applyToPgMessage").val();
if(details.length > 400){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>CHECK CHARACTER LIMIT</p>");
showSuccess();
return;
}
if(details == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>WRITE SOMETHING</p>");
showSuccess();
return;
}
$(this).slideUp(50);
$("#confirmPgToApplyContainer").slideDown(50);
});

	
	





$("body").on("click", "#confirmPgApply", function(){
$("#projectApplySlider").slideUp(100);
$("#submitPgApp").slideDown(50);
$("#confirmPgToApplyContainer").slideUp(100);
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>PLEASE WAIT..</p>");
$("#successResponseDropDown").slideDown(50);
$(".eachProjectGoal"+projectToApply).fadeOut("slow");
var details = $("#applyToPgMessage").val();
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
projectID: projectToApply,
details: details,
apply: 1
},
success: function(response){
if(response == "success"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>RESPONSE SENT</p>");
showSuccess();
}else{
$(".eachProjectGoal"+projectToApply).fadeIn("slow");
}
}
});
});	



	




$("body").on("click", "#cancelPgApply", function(){
$("#projectApplySlider").slideUp(100);
$("#submitPgApp").slideDown(50);
$("#confirmPgToApplyContainer").slideUp(50);
});


//show pg apply form	
	




	
	
$("body").on("click", ".confirmApplyToProject", function(){
var id = $(this).attr("value");
$("#projectGoalConfirmApply"+id).slideUp(50);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: #009688'>Please wait..</p>");
$("#successResponseDropDown").slideDown(50);
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
projectID: id,
apply: 1
},
success: function(response){
if(response == "success"){
$("#eachProjectGoal"+id).fadeOut();
setTimeout(function(){
$("#eachProjectGoal"+id).remove();
}, 1000);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: #009688'>SUCCESSFULY APPLIED!</p>");
setTimeout(function(){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").slideUp(50);
}, 3000);
}
}
});
});
	
	
	
	
	
	
$("body").on("click", ".unapply", function(){
var projectID = $(this).attr("value");
$("#pgInterestedContainer"+projectID).empty();
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
projectID: projectID,
unapply: 1
},
success: function(response){
$("#formHandlerDiv").append(response);
}
});
});
	
	
//apply unapply project goal
	

	
	
	
	
	
	
	
	
	
//BACK TO INDEX
var current = "";
$("body").on("mouseover mousedown touchstart click", ".tip", function(){
current = $("#troupebaseLogo").text();
var tip = $(this).attr("data-tip");
$("#troupebaseLogo").text(tip);
}).on("mouseout mouseup touchend", ".tip", function(){
$("#troupebaseLogo").text(current);
if (window.location.href.indexOf("homebase") != -1){
$("#troupebaseLogo").text("Homebase");
}
});

//JOIN THE BASE BUTTON
$(".signUp").on("click", function(){
var loc = "https://troupebase.com/signup.php";
window.location = loc;
});	
//join the base button
	
	
	
	
	
	

	
	
//SIGNUP	
$("#createAccount").on("click", function(){
var name = $("#name").val();
var email = $("#email").val();
var email = email.toLowerCase(email);
var password = $("#password").val();
if(name.length > 100 || email.lenght > 100 || password.length > 100){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMITS</p>");
showSuccess();
return;
}

if(document.getElementById('13older').checked){
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>YOU MUST BE 13 OR OLDER TO REGISTER</p>");
showSuccess();
return;
}
	
if(password.length < 8){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>PASSWORD TOO SHORT</p>");
showSuccess();
return;
}	
	
createNewAccount(name, email, password);	
	
});	
	
//GET DEVICE
function getDevice()
{


		if (navigator.userAgent.match(/iPhone/i)) {
			return "iPhone";
		} else if (navigator.userAgent.match(/iPad/i)) {
			return "iPad";
		} else if(screen.width <= 699) {
			return "Mobile";
		} else if(navigator.userAgent.match(/Mac OS X/i)) {
			return "Mac";
		} else {
			return "PC";
		}

	
}

	
//CREATE NEW ACCOUNT FUNCTION
function createNewAccount(name, email, password)
{
	
var device = getDevice();

$.ajax({
url: "https://troupebase.com/formhandlers/signupone.php",
method: "POST",
data: {
isWebsite: 1,
Name: name,
Email: email,
Pass: password,
device: device
},
success: function(response){
if(response == "PASSWORD TOO SHORT" || response == "ENTER ALL FIELDS" || response == "INVALID EMAIL" || response == "EMAIL ALREADY IN USE"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>"+response+"</p>");
showSuccess();
	return;
}

conHomebase(response);
	
	
}
});
	
	
}
	


//create new account
	

	
	
















//CONSTRUCT HOMEBASE & SET ULI VARIABLES
function setULIVars(user){
var data = JSON.parse(user);
var user = data[0];
var talents = data[2];
	
var profilePic = user.profilePic;
if(profilePic == ""){
profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
userLoggedInProfilePic = profilePic;
userLoggedIn = user.id;
userLoggedInName = user.name;
userLoggedInState = user.state;
userLoggedInCity = user.city;
userLoggedInCountry = user.country;
userLoggedInAlias = user.alias;
userLoggedInTalents = user.talentString;
	

}
	
	


//CONTRUCT HOMEBASE
function conHomebase(user)
{
	

	$("#logo").fadeIn();
	
	 setULIVars(user);
	
	var data = JSON.parse(user);
	var user = data[0];
	var sessionData = data[1];
	
	var expiryDate = new Date();
  	expiryDate.setMonth(expiryDate.getMonth() + 1);
	
	localStorage.setItem('TroupeBaseID', user.id);
	document.cookie = "TroupeBaseID="+user.id+";expires="+ expiryDate +";domain=.troupebase.com;path=/";
	
	localStorage.setItem('SessionID', sessionData);
	document.cookie = "SessionID="+sessionData+";expires="+ expiryDate +";domain=.troupebase.com;path=/";
	
	localStorage.setItem('TimeZone', user.timeZone);
	document.cookie = "TimeZone="+user.timeZone+";expires="+ expiryDate +";domain=.troupebase.com;path=/";
	
	
	
	
	var profilePic = user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}else{
		$("#goToHomeBase").empty();
		$("#goToHomeBase").append('<img src="'+profilePic+'" class="t1 tutorial tip" id="goToHomeIcon" data-tip="Homebase">');
	}
	localStorage.setItem('profilePic', profilePic);
	
	

	var name = user.name;
	if(user.alias !== ""){
	name = user.name + " (@"+user.alias+")";
	}
	
	var talents = user.talent;
	if(talents == ""){
	talents = "Talents: None Selected";
	}
	
	var location = user.state;
	if(location == ""){
	var state = "Location: None Selected";
	}


	$("#profileLoaderContainerSlider").slideDown(100);
	$("#profileLoaderContainer").append("<div class='homebasecontainer'></div>");
	



	
	$(".homebasecontainer").append("<div class='feedUpperX' id='feedUpperX"+userLoggedIn+"'></div><div id='notificationContainer'><img src='https://troupebase.com/assets/projectsfour.png' class = 'tip fas fa-tasks viewProjectGoals tutorial t7' data-name='"+user.name+"' data-profilepic='"+user.profilePic+"' data-user='"+user.id+"' data-tip='My Projects' style='display: none;'><img src='https://troupebase.com/assets/troupesicon.png' class='tip t8 tutorial' id = 'troupesIcon' style='background-color: White;' data-tip='My Troupes' data-user='"+user.id+"'><img src='https://troupebase.com/assets/collabsicon.png' class='tip t9 vcr ncricon' data-tip='My Collabs'><img src='https://troupebase.com/assets/newMessageIcon.png' class='tip notificationIcons myInbox tutorial t10' value='messages' data-tip='Messages'><img src='https://troupebase.com/assets/bell.png' class='tip notificationIcons notifications tutorial t10' value='Notifications' data-tip='Notifications'></div>");
	
	//PROFILE PIC
	$(".homebasecontainer").append("<div id='uliProfilePhotoContainer'><img src='"+profilePic+"' id='featuredTroupePhoto' class='userLoggedInPhoto userLoggedInLink thisUsersPic"+user.id+" filter"+user.photoFilter+"'></div>");
	
	//PROFILE DETAILS
$(".homebasecontainer").append("<div id='profileDetails'><image src='../assets/showprofilesettingsone.png' class='tutorial t5' id='openProfileSettings'/><p id='currentName'><span class='thisusersname"+user.id+"'>"+name+"</span></p><p style='font-size: 17px;' id='userLoggedInTalents'></p><p id='currentProfileMessage'>"+user.projectGoal+"</p><a href='"+user.website+"' style='color: #b0c7b0; font-weight: bold;' class='websiteRedirect' id='currentWebsite'>"+user.website+"</a></div>");
	
	
	//SM LINKS
	$(".homebasecontainer").append("<div id='smLinks'><img src='assets/smIcons/facebook.png' id='facebookIcon' class='myfblink smRedirect' value=''><img src='assets/smIcons/ig.png' id='instagramIcon' class='myiglink smRedirect' value=''><img src='assets/smIcons/appleMusic.png' id='applemusicIcon' class='myapplemusiclink smRedirect' value=''><img src='assets/smIcons/amazon.png' id='amazonIcon' class='myamazonlink smRedirect' value=''><img src='assets/smIcons/spotify.png' id='spotifyIcon' class='myspotifylink smRedirect' value=''><img src='assets/smIcons/youtube.png' id='youtubeIcon' class='myyoutubelink smRedirect' value=''><img src='assets/smIcons/tidal.png' id='tidalIcon' class='mytidallink smRedirect' value=''><img src='assets/smIcons/twitch.png' id='twitchIcon' class='mytwitchlink smRedirect' value=''><img src='assets/smIcons/tiktok.png' id='tiktokIcon' class='mytiktoklink smRedirect' value=''><img src='assets/smIcons/soundcloud.png' id='soundcloudIcon' class='mysoundcloudlink smRedirect' value=''></div>");
	
		var smLinks = user.smLinks.split(',');
		for(var i = 0; i < smLinks.length; i++) {
			var thisLink = smLinks[i];		
			
			if(thisLink.includes("facebook=")){//fb
			var link = thisLink.replace("facebook=", "");
				$(".myfblink").attr("value", link);
				$(".myfblink").css('display', 'initial');
			}
			
			if(thisLink.includes("instagram=")){//ig
			var link = thisLink.replace("instagram=", "");
				$(".myiglink").attr("value", link);
				$(".myiglink").css('display', 'initial');
			}
			
			if(thisLink.includes("applemusic=")){//applemusic
			var link = thisLink.replace("applemusic=", "");
				$(".myapplemusiclink").attr("value", link);
				$(".myapplemusiclink").css('display', 'initial');
			}
			
			
			if(thisLink.includes("amazon=")){//amazon
			var link = thisLink.replace("amazon=", "");
				$(".myamazonlink").attr("value", link);
				$(".myamazonlink").css('display', 'initial');
			}
			
			
			if(thisLink.includes("spotify=")){//spotify
			var link = thisLink.replace("spotify=", "");
				$(".myspotifylink").attr("value", link);
				$(".myspotifylink").css('display', 'initial');
			}
			
			
			if(thisLink.includes("youtube=")){//youtube
			var link = thisLink.replace("youtube=", "");
				$(".myyoutubelink").attr("value", link);
				$(".myyoutubelink").css('display', 'initial');
			}
			
			
			
			if(thisLink.includes("tidal=")){//tidal
			var link = thisLink.replace("tidal=", "");
				$(".mytidallink").attr("value", link);
				$(".mytidallink").css('display', 'initial');
			}
			
			
			
			
				if(thisLink.includes("twitch=")){//twitch
			var link = thisLink.replace("twitch=", "");
				$(".mytwitchlink").attr("value", link);
					$(".mytwitchlink").css('display', 'initial');
			}
			
			
			
			
				if(thisLink.includes("tiktok=")){//tiktok
			var link = thisLink.replace("tiktok=", "");
				$(".mytiktoklink").attr("value", link);
					$(".mytiktoklink").css('display', 'initial');
			}
			
			
				if(thisLink.includes("soundcloud=")){//soundcloud
			var link = thisLink.replace("soundcloud=", "");
				$(".mysoundcloudlink").attr("value", link);
					$(".mysoundcloudlink").css('display', 'initial');
					
			}
			
		
			
		}
		//

	



	//SHARE AND CREATE POST CONTROL
    $(".homebasecontainer").append("<div class='shareCreatePostControlWrap'><div class='heading'>Share Something</div><div class='centeredIcons shareIcons'><img class='fileToShare hoverimage sharecontrolicons' src='../assets/attachicon.png'><img src='../assets/projectsfour.png' class='sharecontrolicons hoverimage shareNewProjectGoal' id='shareNewProjectGoal'><hr style='width: 100px;'></div><div id='attachmentAndSubmitShare'><div id='fileBeingShared'></div><div id='fileBeingShareConfirm'><button id='confirmShareButton'>SHARE!</button></div> </div></div></div>");


//OPEN NEW PROJECT GOAL FORM
$("#shareNewProjectGoal").on("click", function(){
loadNewProjectForm();
});

	



//SUBMIT SHARE
$("#confirmShareButton").on("click", function(){
	
$("#confirmShareButton").text('...');
$("#confirmShareButton").css("background-color", "grey");
$('#submitShareButton').css("background-color", 'grey');
loadProgressBar();
loadLayOver();

if(clickDelay == 0){
clickDelay = 1;
//photo
if(uploadType == "photo"){
sharePhoto();
}
if(uploadType == "audio"){
shareAudio();
}
if(uploadType == "video"){
shareVideo();
}
}
});








//SUBMIT SHARE FILE TO SHARE
$(".fileToShare").on("click", function(){
if($(".fileToShareCreator").length > 0){
$(".fileToShareCreator").fadeIn();
return;
}
$("#fileToShare").trigger("click");
});
$("#submitShareButton").on("click", function(){
if($("#shareSomethingDesc").html() !== ""){
$("#submitShareButton").css("background-color", "transparent");
$(this).css("display", "none");
$("#confirmShareButton").slideDown(100);
setTimeout(function(){
$("#confirmShareButton").css("display", "none");
$("#submitShareButton").slideDown(100);
}, 3000);
return;
}else{
showAlert("Write Something", "red");
}
});


//FILE TO SHARE ON CHANGE

$("#fileToShare").on("change", function(){
$(".fileToShareDiv").remove();
var file = $(this).val();
var ext = file.split('.').pop();
ext = ext.toLowerCase();
var size = document.getElementById('fileToShare').files[0].size;
var type;
	
//PHOTO
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){
type = "photo";
if(size > 16000000){
showAlert("PHOTO EXCEEDS 15MB", "red");
return;
}
}
//
	
	
	
//AUDIO
if(ext == "wav" || ext == "mp3" || ext =="m4a"){
type = "audio";
if(size > 62914560){
showAlert("AUDIO EXCEEDS 60MB", "red");
return;
}
}	
	

if(ext == "mp4" || ext == "webm" || ext =="ogg" || ext == "mov"){
type = "video";
if(size > 1073741824){
showAlert("Video EXCEEDS 1 GIG", "red");
return;
}	
if(size > 1073741824){
showAlert("Video EXCEEDS 1 GIG", "red");
return;
}
}
	
if(type == undefined){
showAlert("Unsupported File Type", "red");
resetPostEditor();
return;
}
	
	
loadFileToShareControl(file, type, ext);
	
	
});

	






//OPEN FILE SELECT
$(".shareAFile").on("click", function(){
$("#fileToShare").trigger("click");
});

	
$("#shareSomethingDesc").on("input", function(){
var details = $(this).html();
if(details == ""){
$("#submitShareButton").css("background-color", "transparent");
}else{
$("#submitShareButton").css("background-color", "#214844");
}
});


	//
	
	



 //FEED 

$(".homebasecontainer").append("<div class='feedLowerX' id='feedLowerX"+userLoggedIn+"' style='margin-top: 50px;'></div>");//LOWER X
	
$(".homebasecontainer").append("<div class='feed' id='feed"+userLoggedIn+"'><div class='feedHandle' id='feedHandle"+userLoggedIn+"' data-position = 'up' data-user='"+userLoggedIn+"'><div class='feedHandleIcons'><img src='../assets/menu.png' class='toggleFeed hoverimage showMainFeed toggleFeed"+userLoggedIn+"' data-user='"+userLoggedIn+"' id='backtomymainfeed' value='all' style='opacity: 1;'><img src='../assets/media.png' class='toggleFeed hoverimage toggleFeed"+userLoggedIn+"' data-user='"+userLoggedIn+"' value='media'><img src='../assets/projectsfour.png' class='toggleFeed hoverimage toggleFeed"+userLoggedIn+"' data-user='"+userLoggedIn+"' value='pg'><img src='../assets/expandright.png' class='expandRightPG' id='expandRightPG' style='border: none; display: none;'><img src='../assets/pgresponses.png' class='showmypgresponses' id='showmypgresponses' style='border: none; display: none;'></div><div class='feedProfileImage'><div id='feedProfImage"+userLoggedIn+"' class='feedProfImage' data-user='"+userLoggedIn+"'><img src='"+profilePic+"'></div></div><img class='feedHandleToggleImage' id = 'feedHandleImg"+userLoggedIn+"' src='../assets/expandup.png' data-user='"+userLoggedIn+"' data-position = 'up'></div><div class='feedScroll' id='feedScroll"+userLoggedIn+"' data-start = '0'><div class='newPostprependHere' id='newPostprependHere'></div><div class='nothingSharedYet' id='nothingSharedYet"+userLoggedIn+"'><br>NOTHING SHARED YET</div></div></div>");
getFeedPosts(userLoggedIn, 0);
	
$("#feedScroll"+userLoggedIn).on("scroll", function(){
var start = $("#feedScroll"+userLoggedIn).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
getFeedPosts(userLoggedIn, start);
}
}, 150);
});





			//SETTINGS
		$("#profileLoaderContainer").append("<div id='profileSettingsContainer'><div id='heading'><p>PROFILE SETTINGS</p></div><div class='settingsContent'></div></div>");
	
	
	//SETTINGS - profile pic upload
				$(".settingsContent").append("<br><p>Profile Photo</p><input type='file' style='font-size: 14px; border: none; cursor: pointer;' id='newProfilePic' name='newProfilePic'>");	

		//SETTINGS - Name
		$(".settingsContent").append("<p>Name</p><input type='text' placeholder='Name' id='newName' value='"+user.name+"'><span id='newNameCount' style='margin-left: 5px; color: White;'></span>");	
	
//SETTINGS - username
		$(".settingsContent").append("<p><p>Username</p><div class='iuns' style='width: 100%; text-align: center; color: red;'></div><input type='text' placeholder='USERNAME' id='desiredAlias' value='"+user.alias+"' autocomplete='off'><span id='desiredAliasCount' style='margin-left: 5px;color: white;'></span>");
	
	if(user.alias == ""){
	$(".iuns").append("<p style='font-size: 10px; color: red;'>ENTER A USERNAME SO OTHERS CAN SEARCH YOU</p>");
	}
	

//SETTINGS - talent
		$(".settingsContent").append("<p>My Talents</p><div class='itns' style='width: 100%; text-align: center; color: red;'></div><div class='selectedTalents'></div><select id='newTalent'><option value='Talent' selected='selected'>Talent</option><option value='Actor'>Actor</option><option value='Artist'>Artist</option><option value='Comedian'>Comedian</option><option value='Culinary Baking'>Culinary Baking</option><option value='Dancer'>Dancer</option><option value='Fashion'>Fashion</option><option value='Gamer'>Gamer</option><option value='Graphic Design'>Graphic Design</option><option value='Health Fitness'>Health Fitness</option><option value='MUA'>MUA</option><option value='Model'>Model</option><option value='Music Composer'>Music Composer</option><option value='Musician'>Musician</option><option value='Podcast'>Podcast</option><option value='Photography Video'>Photography Video</option><option value='Programmer'>Programmer (Web/Mobile)</option><option value='Rapper'>Rapper</option><option value='Singer'>Singer</option><option value='Vlogger'>Vlogger</option><option value='Writer'>Writer</option></select>");

var talentString = user.talentString;	
if(talentString == ","){
$(".itns").append("<p style='font-size: 10px; color: red;' id='notalentselected'>SELECT AT LEAST ONE TALENT</p>");
$("#profileSettingsContainer").stop().animate({width: "100%"}, "fast", "linear");
}
	
var talentsArray = talentString.split(',');	
for(var t = 0; t < talentsArray.length; t++){
var thisTalent = talentsArray[t];
if(thisTalent !== ""){
var klass = thisTalent.replace(" ", "");
$(".selectedTalents").append("<span class='"+klass+" eachselectedtalent' style='color: white;'>"+thisTalent+"</span> <button class='deleteThisTalent "+klass+"' value = '"+thisTalent+"' style = 'color: red; background-color: white; border: 1px solid grey; border-radius: 2px;'>x</button>");
	
}
}
	
var talentText = talentString.replace(',', ''); 
talentText = talentText.replace(/,\s*$/, "");
talentText = talentText.replace(/,/g, ', ');
$("#userLoggedInTalents").append(talentText + ", "+userLoggedInState);

	
//SETTINGS - location
		$(".settingsContent").append('<p>Location</p><div class="ilns" style="width: 100%; text-align: center; color: red;"></div><input type="text" id="myLocationSelector" placeholder="SELECT LOCATION">');

	$("#myLocationSelector").val(user.city+", "+user.state);
	
	if(user.state == "" || user.country == ""){
	$(".ilns").append("<p style='font-size: 10px; color: red;'>ENTER YOUR LOCATION</p>");
	}
	if(user.state !== ""){
	$("#currentStateSelector").val(user.state);
	}
	
	
	

	
$("#myLocationSelector").on("focus", function(){
$(this).blur();
loadLocationSearchWindow();
});







//SETTINGS - website
$(".settingsContent").append("<p>Website</p><input type='text' id='newWebsite' placeholder='YOUR WEBSITE LINK' value=''>");
	$("#newWebsite").val(user.website);

//SETTINGS - sm links
$(".settingsContent").append("<p>SOCIAL LINKS</p><select id='addSocialLink'><option value='Add Link' selected='selected' disabled>ADD LINK</option><option value='facebook'>Facebook</option><option value='instagram'>Instagram</option><option value='applemusic'>Apple Music</option><option value='amazon'>Amazon</option><option value='spotify'>Spotify</option><option value='youtube'>Youtube</option><option value='tidal'>Tidal</option><option value='twitch'>Twitch</option><option value='tiktok'>TikTok</option><option value='soundcloud'>Soundcloud</option></select>");

//SETTINGS - sm links - link inputs
$(".settingsContent").append("<div id='smLinks'><div id='newFacebookLinkContainer' class='newSocialMediaLinks'><p>Facebook</p><input type='text' id='newFacebookLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='facebook'>x</button></div><div id='newInstagramLinkContainer' class='newSocialMediaLinks'><p>Instagram</p><input type='text' id='newInstagramLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='instagram'>x</button></div><div id='newAppleMusicLinkContainer' class='newSocialMediaLinks'><p>Apple Music</p><input type='text' id='newAppleMusicLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='applemusic'>x</button></div><div id='newAmazonLinkContainer' class='newSocialMediaLinks'><p>Amazon</p><input type='text' id='newAmazonLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='amazon'>x</button></div><div id='newSpotifyLinkContainer' class='newSocialMediaLinks'><p>Spotify</p><input type='text' id='newSpotifyLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='spotify'>x</button></div><div id='newYoutubeLinkContainer' class='newSocialMediaLinks'><p>Youtube</p><input type='text' id='newYoutubeLink' placeholder='COMPLETE URL'><button class='removeSocialLink'value='youtube'>x</button></div><div id='newTidalLinkContainer' class='newSocialMediaLinks'><p>Tidal</p><input type='text' id='newTidalLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='tidal'>x</button></div><div id='newTwitchLinkContainer' class='newSocialMediaLinks'><p>Twitch</p><input type='text' id='newTwitchLink' placeholder='COMPLETE URL'><button class='removeSocialLink'value='twitch'>x</button></div><div id='newTikTokLinkContainer' class='newSocialMediaLinks'><p>TikTok</p><input type='text' id='newTikTokLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='tiktok'>x</button></div><div id='newSoundcloudLinkContainer' class='newSocialMediaLinks'><p>Souncloud</p><input type='text' id='newSoundcloudLink' placeholder='COMPLETE URL'><button class='removeSocialLink' value='soundcloud'>x</button></div></div>");

	var smLinks = user.smLinks.split(',');
	for(var i = 0; i < smLinks.length; i++) {
		if(smLinks[i].includes("facebook=")){
			var thisLink = smLinks[i].replace("facebook=", "");
			$("#newFacebookLinkContainer").slideDown(100);
			$("#newFacebookLink").val(thisLink);
		}
		if(smLinks[i].includes("instagram=")){
			var thisLink = smLinks[i].replace("instagram=", "");
			$("#newInstagramLinkContainer").slideDown(100);
			$("#newInstagramLink").val(thisLink);
		}
		if(smLinks[i].includes("applemusic=")){
			var thisLink = smLinks[i].replace("applemusic=", "");
			$("#newAppleMusicLinkContainer").slideDown(100);
			$("#newAppleMusicLink").val(thisLink);
		}
		if(smLinks[i].includes("amazon=")){
			var thisLink = smLinks[i].replace("amazon=", "");
			$("#newAmazonLinkContainer").slideDown(100);
			$("#newAmazonLink").val(thisLink);
		}
		if(smLinks[i].includes("spotify=")){
			var thisLink = smLinks[i].replace("spotify=", "");
			$("#newSpotifyLinkContainer").slideDown(100);
			$("#newSpotifyLink").val(thisLink);
		}
		if(smLinks[i].includes("youtube=")){
			var thisLink = smLinks[i].replace("youtube=", "");
			$("#newYoutubeLinkContainer").slideDown(100);
			$("#newYoutubeLink").val(thisLink);
		}
		if(smLinks[i].includes("tidal=")){
			var thisLink = smLinks[i].replace("tidal=", "");
			$("#newTidalLinkContainer").slideDown(100);
			$("#newTidalLink").val(thisLink);
		}
		if(smLinks[i].includes("twitch=")){
			var thisLink = smLinks[i].replace("twitch=", "");
			$("#newTwitchLinkContainer").slideDown(100);
			$("#newTwitchLink").val(thisLink);
		}
		if(smLinks[i].includes("tiktok=")){
			var thisLink = smLinks[i].replace("tiktok=", "");
			$("#newTikTokLinkContainer").slideDown(100);
			$("#newTikTokLink").val(thisLink);
		}
		if(smLinks[i].includes("soundcloud=")){
			var thisLink = smLinks[i].replace("soundcloud=", "");
			$("#newSoundcloudLinkContainer").slideDown(100);
			$("#newSoundcloudLink").val(thisLink);
		}
		
	}
	


$("#desiredAlias").on("focus", function(){
$(".iuns").empty();
});
$("#newTalent").on("mousedown", function(){
$(".itns").empty();
});
$("#currentStateSelector").on("mousedown", function(){
$(".ilns").empty();
});

	

//SETTINGS - about
$(".settingsContent").append("<p>About<span id='aboutMeCount' style='color: white;'></span></p><textarea id='newProfileMessage'>"+user.projectGoal+"</textarea>");
	$("#newProfileMessage").val(user.projectGoal);



//SETTINGS - PRIVACY
$(".settingsContent").append("<div id='privacySettingsContainer'><button id='showPrivacySettings'>Show privacy settings</button><div id='privacySettingsSlider'><p style='text-decoration: underline;'>PRIVACY</p><span style='color: white;'>Who can send me Troupe Requests</span><br><select id='troupeRequestPrivacy'><option value='everyone'>EVERYONE</option><option value='noOne'>NO ONE</option></select><br><span style='color: white;'>Who can send me Collab Requests</span><br><select id='collabRequestPrivacy'><option value='everyone'>EVERYONE</option><option value='troupesOnly'>MY TROUPES ONLY</option><option value='noOne'>NO ONE</option></select><br><span style='color: white;'>CONVO SENT/READ RECEIPT</span><br><select id='toggleMessageReceipt'><!-- TROUPE REQUESTS--><option value='1'>ALLOW</option><option value='0'>DON'T ALLOW</option></select><br><br><button id='blockedUsers'>BLOCKED USERS</button></div></div><br><br><button id='done'>DONE</button><br><br><button id='logout'>LOGOUT</button><br><br><br><br><button class='showTutorial'>Walkthrough</button><br><br><div class='policiesContainer'><button class='viewPolicy' value='about'>ABOUT</button><button class='viewPolicy' value='privacy'>PRIVACY</button><button class='viewPolicy' value='dmca'>DMCA</button><button class='viewPolicy' value='tou'>TOU</button></div>");

	var privacyTR = user.privacyTR;
	if(user.privacyTR == ""){
	var privacyTR = "everyone";
	}
	$("#troupeRequestPrivacy").val(privacyTR);
	
	var privacyCR = user.privacyCR;
	if(user.privacyCR == ""){
	var privacyCR = "everyone";
	}
	$("#collabRequestPrivacy").val(privacyCR);
	

	

	$("#toggleMessageReceipt").val(user.messageReceipt);
	
		//
	


	//AFTER CONSTRUCTION
	$(".homebasecontainer").animate({width: "100%"});
	if(user.name == "" || user.alias == "" || user.state == "" || user.country==""){
	$("#profileSettingsContainer").stop().animate({width: "100%"}, "fast", "linear");
	}

	




}
	
	
	
$("body").on("mousedown", ".feedProfImage", function(){
var user = $(this).attr("data-user");
$("#feedHandleImg"+user).trigger("mousedown");
});
	

	







//GET USERS FEED POSTS
function getFeedPosts(user, start){
$.ajax({
url: "https://troupebase.com/formhandlers/getfeed.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){
constructFeed(user, start, response);
}
});	
	
}
	

	
	





//CONSTRUCT FEED
function constructFeed(user, start, response){
if(response == "end"){
return;
}
	
	
var newStart = parseInt(start) + 20;
$("#feedScroll"+user).attr("data-start", newStart);		
	
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){	
	
var post = data[i];
$("#nothingSharedYet"+user).remove();
	
	//USERS TALENTS
	var talentText = "";
let talents = post.userObj.talentString;
	talents = talents.split(',');
	for(var t = 0; t<talents.length; t++){
	var thisTalent = talents[t];
	if(thisTalent !==""){
		talentText = talentText+thisTalent+", ";
	}
	}
	
	talentText = talentText.replace(/,(\s+)?$/, ''); 
	
	
	//REQUIRED TALENTS
	var rtalentString = "";
	var requiredTalents = post.requiredTalent;
	requiredTalents = requiredTalents.split(',');
	for(var rt = 0; rt<requiredTalents.length; rt++){
	var thisReqTalent = requiredTalents[rt];
		if(thisReqTalent !==""){
		rtalentString = rtalentString+thisReqTalent+", ";
	}
	}
	
	rtalentString = rtalentString.replace(/,(\s+)?$/, ''); 

	//LOCATION 
	var locationString = "Location: "+post.city+", "+post.state;
	
	if(post.state == "" || post.state == "null"){
	var locationString = "Location: Any";
	}
	
	

	
//IF IS MEDIA
if(post.type == "v" || post.type == "a" || post.type == "p"){
var container = $("#feedScroll"+user);
constructMediaPost(post, container);	
}
//end if media


//IF PROJECT GOAL
if(post.type == "pg"){
var container = $("#feedScroll"+user);
constructProjectGoal(post, container);
}
//end if project goal


	
	
	
}
}

	



	

//GET COUNTER START
function getCounterStart(){
var time = Date.now();
var counter = time+1;
return counter;
}
	
	





	



//CONSTRUCT MEDIA POST
function constructMediaPost(post, container, justPosted){
var counter = Math.random();
counter = counter.toString();
counter = counter.replace(".", "");
	
	
	
//DETERMINE TYPE ICON
if(post.type == "v"){
var typeOfImage = "../assets/videoIconOne.png";
var deleteText = "Video?";
}
if(post.type == "a"){
var typeOfImage = "../assets/audioIconOne.png";
var deleteText = "Audio?";
}
if(post.type == "p"){
var typeOfImage = "";
var deleteText = "Photo?";
}	

	
var smallimage = post.smallimage;
	
//IF NO SMALL IMAGE AVAILABLE
if(smallimage == ""){
if(post.type == "p"){
smallimage = post.photo;
}
if(post.type == "a" || post.type == "v"){
smallimage = post.coverPhoto;
}
}
	
//REMOVE EXCESS LINE BREAKS	
post.caption = removeExcessLB(post.caption);	
var shortCaption = post.caption.substring(0,140);	

$(container).append("<div id='eachFeedPostWrap"+post.id+"' class='eachFeedPostWrap eachFeedPostWrap"+post.id+"'><div class='eachFeedPost'><div class='eachFeedPostImage filter"+post.filter+"' id='eachFeedPostImage"+post.id+"'><div class='typeofpostimg' id='typeofpostimg"+post.id+"'><img src='"+typeOfImage+"'></div><img src='"+smallimage+"' id='eachFeedPhoto"+post.id+"' class='viewPost hoverimage' data-id='"+post.id+"' data-dateTime='"+post.dateTime+"'></div><div class='eachFeedPostInfoWrap'><div class='eachFeedPostInfo'><div class ='projectShortBody' id='projectShortBody"+counter+"'>"+shortCaption+"</div><div class='fullProjectCaption fullProjectCaption"+counter+"' id='fullProjectCaption"+counter+"' data-id='"+post.id+"'>"+post.caption+"</div><br><span>"+post.dateTime+"</span><div class='eachFeedPostControls'><img src='../assets/delete.png' class='hoverimage deletePost' id='deletePost"+counter+"' data-counter = '"+counter+"' value='"+post.id+"'><img class='hoverimage sharePg sharePg"+post.id+"' id='sharePg"+post.id+"' value='"+post.id+"' src='../assets/sharethree.png' style='margin-right: 15px;'><button class='redTextOnlyButton reportpostbutton reportpostbutton"+counter+"' id='reportpostbutton"+post.id+"' data-counter = '"+counter+"' value='"+post.id+"'>Report</button></div><div class='confirmdeletediv confirmdeletediv"+post.id+"' id='confirmdeletediv"+counter+"'>Delete "+deleteText+"<button class='confirmDeleteButton confirmDeletePost' id='conDelPost"+post.id+"' value='"+post.id+"'>YES</button></div><div class='confirmdeletediv' id='confirmReportDiv"+counter+"'>Report "+deleteText+"<button class='confirmDeleteButton confirmReportPost' id='conDelPost"+post.id+"' value='"+post.id+"'>YES</button></div></div></div></div></div>");	
if(post.type == "p"){
$("#typeofpostimg"+post.id).remove();
}
	

var shortCaptionLength = shortCaption.length;
var fullCaptionLength = post.caption.length;
	
if(shortCaptionLength < fullCaptionLength){
$("#projectShortBody"+counter).append(" <button class='viewMoreButton viewFullProjectCaption' data-counter='"+counter+"'>View More</button>");
}

	
//BUTTON CHECK
	if(post.user !== post.userLoggedIn){
	$("#deletePost"+counter).remove();
	$("#totalbutton"+post.id).remove();
	$("#viewInterested"+post.id).remove();
	}else{
	$("#interested"+post.id).remove();
	}


	
//PREPEND IF JUST POSTED
if(justPosted == 1){
var elem = document.querySelector('#eachFeedPostWrap'+post.id);
var clone = elem.cloneNode(true);
$('#eachFeedPostWrap'+post.id).remove();
$(container).prepend(clone);
makeElementBlink(clone);
//$("#eachFeedPostWrap"+post.id).remove();
}
	
}

	



	



//REMOVE EXCESS LINE BREAKS
function removeExcessLB(string){
var string = string.replace(/\n\s*\n\s*\n/g, '\n\n');
return string;
}

	
	



//CONSTRUCT PROJECT GOAL
function constructProjectGoal(post, container, view){

var counter = Math.random();
counter = counter.toString();
counter = counter.replace(".", "");
	//USERS TALENTS
	var talentText = "";
let talents = post.userObj.talentString;
	talents = talents.split(',');
	for(var t = 0; t<talents.length; t++){
	var thisTalent = talents[t];
	if(thisTalent !==""){
		talentText = talentText+thisTalent+", ";
	}
	}
	
	talentText = talentText.replace(/,(\s+)?$/, ''); 
	
	
	//REQUIRED TALENTS
	var rtalentString = "";
	var requiredTalents = post.requiredTalent;
	requiredTalents = requiredTalents.split(',');
	for(var rt = 0; rt<requiredTalents.length; rt++){
	var thisReqTalent = requiredTalents[rt];
		if(thisReqTalent !==""){
		rtalentString = rtalentString+thisReqTalent+", ";
	}
	}
	
	rtalentString = rtalentString.replace(/,(\s+)?$/, ''); 

	//LOCATION 
	var locationString = "Location: "+post.city+", "+post.state;
	
	if(post.state == "" || post.state == "null"){
	var locationString = "Location: Any";
	}
		
	var deleteText = "Project Goal?";
	
	var profilePic = post.userObj.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
		
	var subject = post.subject;
	
	//REMOVE EXCESS LINE BREAKS
	post.caption = removeExcessLB(post.caption);
	if(view == "myResponses"){
	post.myResponse = removeExcessLB(post.myResponse);
	}

	var shortCaption = post.caption.substring(0, 140);

$(container).append("<div id='eachFeedPostWrap"+post.id+"' class='eachFeedPostWrap eachFeedPostWrap"+post.id+"'><div class='eachProjectGoalFeed'><div class='postedBy'><div class='postedByPhoto'><img id='projectGoalUserPic"+post.id+"' src='"+profilePic+"'></div><div class='postedByName'><span style='font-weight: bold;' id='projectGoalName"+post.id+"'>"+post.userObj.name+"</span> - <span id='projectGoalUsersTalentAndState"+post.id+"'>"+talentText+", "+post.userObj.state+"</span><br><span>Looking for: "+rtalentString+"</span><br><span>"+locationString+"</span><br><span>Subject: "+subject+"</span><br><span style='font-size: 11px;'>"+post.dateTime+"</span><br></div></div><div class='pgbody'><div class ='projectShortBody' id='projectShortBody"+counter+"'>"+shortCaption+"</div><div class='fullProjectCaption fullProjectCaption"+counter+"' id='fullProjectCaption"+counter+"' data-id='"+post.id+"'>"+post.caption+"</div><div class='pgrespdiv pgrespdiv"+post.id+" pgrespdiv"+counter+"' id='pgrespdiv"+counter+"'></div><div class='pgrespstat' id='pgrespstat"+counter+"'></div><div class='myProjectResponseDiv' id='myProjectResponseDiv"+counter+"'><span style='font-weight: bold;'>My Response:</span><br>"+post.myResponse+"<img src='../assets/delete.png' class='hoverimage' id='deleteMyPgRespSubmit"+counter+"' data-counter='"+counter+"'><div class='deleteMyPGResponse' id='deleteMyPGResponse"+counter+"'>Delete your response? <button class='confirmDeleteButton' id='confirmDeleteMyPgResp"+counter+"' data-id='"+post.id+"'>Yes</button></div></div><div class='eachFeedPostControls' id='eachFeedPostControls"+counter+"'><img src='../assets/delete.png' class='hoverimage deletePost' id='deletePost"+counter+"' data-counter = '"+counter+"' value='"+post.id+"'><img class='hoverimage sharePg sharePg"+post.id+"' id='sharePg"+post.id+"' value='"+post.id+"' src='../assets/sharethree.png'><img class='hoverimage viewInterested viewInterested"+post.id+"' id='viewInterested"+post.id+"' value='"+post.id+"' data-subject='"+post.id+"' src='../assets/totalresponses.png' style='margin-right: 0px;'><div id='pgRespImgHere"+counter+"'><img class='interested hoverimage interested"+post.id+"' id='interested"+post.id+"' data-postedby='"+post.user+"' data-projectid='"+post.id+"' data-counter='"+counter+"' src='../assets/messagetwo.png' style='margin-right: 15px;'></div><button class='totalbutton' id='totalbutton"+post.id+"' style='margin-right: 15px;'>"+post.totalApplicants+"</button><button class='redTextOnlyButton reportpostbutton reportpostbutton"+counter+"' id='reportpostbutton"+post.id+"' value='"+post.id+"' data-counter='"+counter+"'>Report</button></div><div class='confirmdeletediv confirmdeletediv"+post.id+"' id='confirmdeletediv"+counter+"'>Delete "+deleteText+"<button class='confirmDeleteButton confirmDeletePost' id='conDelPost"+post.id+"' value='"+post.id+"'>YES</button></div><div class='confirmdeletediv confirmReportDiv"+post.id+"' id='confirmReportDiv"+counter+"'>Report "+deleteText+"<button class='confirmDeleteButton confirmReportPost' id='conDelPost"+post.id+"' value='"+post.id+"'>YES</button></div></div></div></div>");
	
var shortCaptionLength = shortCaption.length;
var fullCaptionLength = post.caption.length;
	
if(shortCaptionLength < fullCaptionLength){
$("#projectShortBody"+counter).append(" <button class='viewMoreButton viewFullProjectCaption' data-counter='"+counter+"'>View More</button>");
}

if(view == "responses" || view == "myResponses"){
$("#eachFeedPostControls"+counter).empty();
	
if(view == "myResponses"){
$("#eachFeedPostControls"+counter).append("<button class='viewMoreButton' id='viewMyProjectResponse"+post.id+"' data-id='"+post.id+"' data-counter='"+counter+"'>View My Response</button>");
	
$("#deleteMyPgRespSubmit"+counter).on("click", function(){
$(this).slideUp(10);
var counter = $(this).attr("data-counter");
$("#deleteMyPGResponse"+counter).slideDown(10);
setTimeout(function(){
$("#deleteMyPGResponse"+counter).slideUp(10);
$("#deleteMyPgRespSubmit"+counter).slideDown(10);
}, 2500);
});
	
	
$("#confirmDeleteMyPgResp"+counter).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var id = $(this).attr("data-id");
deleteMyPgResponse(id).then(function(response){
if(response == "success"){
$("#eachFeedPostWrap"+id).fadeOut("fast");
}else{
showAlert("Error occured, please try again later", "red");
}
clickDelay = 0;
});
}
});

	
	
	
}	
}	

	
$("#viewMyProjectResponse"+post.id).on("click", function(){
$(this).slideUp(10);
var counter = $(this).attr("data-counter");
$("#myProjectResponseDiv"+counter).slideDown("slow");
});


	
	//RESPONSE CHECK
var responseStatus = post.responseStatus;
if(responseStatus>0){
$(".interested"+post.id).slideUp(10);
$("#pgrespstat"+counter).append("<span style='color: #214844; font-weight: bold;'>Your responded to this project</span> <img class='hoverimage delprojresp' data-id='"+post.id+"' data-counter = '"+counter+"' src='../assets/delete.png'>");
}

	
	
	//BUTTON CHECK
	if(post.user !== post.userLoggedIn){
	$("#deletePost"+counter).remove();
	$("#totalbutton"+post.id).remove();
	$("#viewInterested"+post.id).remove();
	}else{
	$("#interested"+post.id).remove();
	}



}
	
	
//DELETE MY PG RESPONSE
function deleteMyPgResponse(id){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/deleteMyPgResponse.php",
method: "POST",
data: {
id: id,
isWebsite: 1
},
success: function(response){

resolve(response);

}
});
});	
}



//SHOW FULL PROJECT DETAILS
$("body").on("click", ".viewFullProjectCaption",function(){
var counter = $(this).attr("data-counter");
$("#projectShortBody"+counter).css("display", "none");
$(".fullProjectCaption"+counter).css("display", "block");
});
	
	

//DELETE PROJECT RESPONSE
$("body").on("click", ".delprojresp", function(){
var id = $(this).attr("data-id");
var counter = $(this).attr("data-counter");
$(".eachFeedPostWrap").css("opacity", .1);
$(".eachFeedPostWrap"+id).css("opacity", 1);
loadConfirmScreen("delete", "pg", id, counter);
});
	


function loadConfirmScreen(to, type, id, counter){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmingcontainer' id='confirmingcontainer' style='width: 100%;'><div class='portfolioHeading'><div class='topTopConIcons'></div></div><div class='postScroller'><div class='confirmWrap'><div id='confirmMessageHere'></div></div></div></div>");

if(to == "delete" && type == "pg"){
var message = "Delete Your response to this project?";
}
	
	
$("#confirmMessageHere").append("<span style='font-weight: bold; font-size: 18px;'>"+message+"</span><br><button class='nvmbutton' id='nvmbutton"+time+"'>Nevermind</button><button class='yesconbutton' id='yesconbutton"+time+"'>Yes</button>");
	
	
	
//CONFIRM
$("#yesconbutton"+time).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
if(to == "delete" && type == "pg"){
$("#pgrespstat"+counter).empty();
deleteProjectResponse(id).then(function(response){
clickDelay = 0;
$(".confirmingcontainer").remove();
if(response == "success"){
$("#pgrespstat"+counter).empty();
$("#pgRespImgHere"+counter).append("<img class='interested hoverimage interested"+id+"' id='interested"+id+"' data-postedby='' data-projectid='"+id+"' data-counter='"+counter+"' src='../assets/messagetwo.png' style='margin-right: 15px;'>");
}else{
showAlert("Something went wrong", "red");
}
setTimeout(function(){
$(".eachFeedPostWrap").fadeTo("slow", 1);
}, 1500);
});
}
	
}
});

	
//SCRATCH THAT
$("#nvmbutton"+time).on("click", function(){
if(clickDelay == 0){
if(to == "delete" && type == "pg"){
$(".eachFeedPostWrap").css("opacity", 1);
$("#confirmingcontainer").remove();
}	



}
});
	

}
	


	
	
//DELETE PROJECT RESPONSE
function deleteProjectResponse(id){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/deleteprojectresponse.php",
method: "POST",
data: {
id: id,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});
	
	

});		
}



	

//DELETE POST
$("body").on("click", ".deletePost",function(){
var id = $(this).attr("value");
var counter = $(this).attr("data-counter");
$(this).slideUp(10);
$("#confirmdeletediv"+counter).slideDown(100);
setTimeout(function(){
$("#deletePost"+counter).slideDown(100);
$(".confirmdeletediv"+id).slideUp(100);
}, 2500);
});
	
$("body").on("click", ".confirmDeletePost",function(){
var id = $(this).attr("value");
$(".eachFeedPostWrap"+id).fadeOut("slow");
deletePost(id).then(function(response){
if(response == "error"){
$(".eachFeedPostWrap"+id).fadeIn("slow");
showAlert("An error occured", "red");
}
}).catch(function(response){
});
});
	
function deletePost(id){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/deletepost.php",
method: "POST",
data: {
id: id,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});
	
	

});	
}
	


	


//REPORT POST
$("body").on("click", ".reportpostbutton", function(){
var id = $(this).attr("value");
var counter = $(this).attr("data-counter");
$(this).slideUp(10);
$("#confirmReportDiv"+counter).slideDown(100);
setTimeout(function(){
$(".reportpostbutton"+counter).slideDown(10);
$("#confirmReportDiv"+counter).slideUp(100);
}, 2500);
});
	
$("body").on("click", ".confirmReportPost",function(){
var id = $(this).attr("value");
$(".eachFeedPostWrap"+id).fadeOut("slow");
reportPost(id).then(function(response){
if(response == "error"){
$("#eachFeedPostWrap"+id).fadeIn("slow");
showAlert("An error occured", "red");
}
}).catch(function(response){
});
});

function reportPost(id){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/reportpost.php",
method: "POST",
data: {
id: id,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});
	
	

});	
}
















	



//TOGGLE FEED
$("body").on("click", "#showmypgresponses", function(){
$(".feedContainer"+userLoggedIn).remove();
$(this).css("opacity", 1);
loadMyPGResponses();
});
	

function loadMyPGResponses(){
var time = Date.now();
$("#feedScroll"+userLoggedIn).append("<div class='feedContainer feedContainerPG feedContainer"+userLoggedIn+"' id='feedContainerPg"+time+"' data-start = '0'></div>");	

//GET INITIAL 20
var start = $("#feedContainerPg"+time).attr("data-start");
var container = document.getElementById('feedContainerPg'+time);
getMyProjectResponses(start).then(function(response){
if(response == "end"){
return;
}

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var post = data[i];
constructProjectGoal(post, container, "myResponses");
}

});
	
	


showAlert("Projects You Responded To", "black");
}
	
function getMyProjectResponses(start){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/myProjectResponses.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){

resolve(response);

}
});
});	
}


$("body").on("click", ".toggleFeed", function(){
if(clickDelay == 0){
clickDelay = 1;
var user = $(this).attr("data-user");
var value = $(this).attr("value");
var feedPosition = $("#feedHandleImg"+user).attr("data-position");

$(".feedContainer"+user).remove();

if(feedPosition == "up"){
$("#feedHandleImg"+user).trigger("mousedown");
}
	
$(".expandRightPG").css("display", "none");
$(".showmypgresponses").css("display", "none");
$(".toggleFeed"+user).css("opacity", .4);
$(this).css("opacity", 1);
$("#showmypgresponses").css("opacity", .4);

	
//LOAD PROJECT GOALS ONLY IN FEED
if(value == "pg"){
$("#feedScroll"+user).append("<div class='feedContainer feedContainerPG feedContainer"+user+"' id='feedContainerPg"+user+"' data-start = '0'></div>");	

$(".expandRightPG").slideDown(10);
$(".showmypgresponses").slideDown(10);
	
	
//GET INITIAL 20
var start = $("#feedContainerPg"+user).attr("data-start");
var container = document.getElementById('feedContainerPg'+user);
getProjectGoals(user, start).then(function(response){
if(response == "end"){
return;
}

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var post = data[i];
constructProjectGoal(post, container);
}
	
var newStart = parseInt(start) + 20;
$(container).attr("data-start", newStart);		
	
});

	
	
//SCROLL
$("#feedContainerPg"+user).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+200){
//GET NEXT 20
var start = $("#feedContainerPg"+user).attr("data-start");
var container = document.getElementById('feedContainerPg'+user);
getProjectGoals(user, start).then(function(scrollResp){
if(scrollResp == "end"){
return;
}
var newStart = parseInt(start) + 20;
$(container).attr("data-start", newStart);	
var data = JSON.parse(scrollResp);
for(var i = 0; i < data.length; i++){
var post = data[i];
constructProjectGoal(post, container);
}
});
	
}
}, 150);
});	
	

	
showAlert("Your Project Goals", "black");
}
	
	

//LOAD MEDIA ONLY
if(value == "media"){
	
$("#feedScroll"+user).append("<div class='feedContainer feedContainerMedia feedContainer"+user+"' id='feedContainerMedia"+user+"' data-start = '0'></div>");	

var start = $("#feedContainerMedia"+user).attr("data-start");
var container = document.getElementById('feedContainerMedia'+user);
getUserMediaPostOnly(user, start).then(function(response){
if(response == "end"){
return;
}

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var post = data[i];
constructMediaPost(post, container);
}
	
var newStart = parseInt(start) + 20;
$(container).attr("data-start", newStart);	

	
});
	
	
	
//SCROLL
$("#feedContainerMedia"+user).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+200){
//GET NEXT 20
var start = $("#feedContainerMedia"+user).attr("data-start");
var container = document.getElementById('feedContainerMedia'+user);	
	
getUserMediaPostOnly(user, start).then(function(response){
if(response == "end"){
return;
}
	
	

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var post = data[i];
constructMediaPost(post, container);
}
	
var newStart = parseInt(start) + 20;
$(container).attr("data-start", newStart);	

	
});
	
	
}	
}, 150);
});
	
	

showAlert("Your Media Posts", "black");
}



	


//SHOW ALL IN FEED
if(value == "all"){
$(".feedContainer"+user).fadeOut(100);
setTimeout(function(){
$(".feedContainer"+user).remove();
clickDelay = 0;
}, 150);
showAlert("All Posts", "black");
}
	
	
	clickDelay = 0;
}	
});




	


//GET USERS MEDIA POST ONLY
function getUserMediaPostOnly(user, start){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/getusersmediaonly.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){

resolve(response);

}
});
});	
}



	
	


	



	
//VIEW POST
$("body").on("click", ".viewPost", function(){

if(clickDelay == 0){
clickDelay = 1;
var postID = $(this).attr("data-id");
var dateTime = $(this).attr("data-datetime");
getPost(postID, dateTime);
}
});		



	



//FILE TO SHARE CONTROLS
	
var uploadType = "";
var fileToShareURL;
var shareFromCroppieOrOriginal = "croppie";
var shareCroppieURL = "";
var partOfPortfolio = 0;
var optionalLink = "";
var fileToShareExt = "";
var selectedCoverForAudioURL = "";
var selectedCoverForAudioExt = "";
var isScrollingSelectedAudio = 0;	
var frameVideo;
var videoFrameSeek;
var thumbTime = 0;
var shareCity = "";
var shareState = "";
var shareCountry = "";
function loadFileToShareControl(file, type, ext)
{
	
	var time = Date.now();
	fileToShareExt = ext;
	var fileToShare = document.getElementById("fileToShare");
	fileToShareURL = URL.createObjectURL(fileToShare.files[0]);

var time = Date.now();	
	
	
//PHOTO
if(type == "photo"){
uploadType = "photo";
shareFromCroppieOrOriginal = "croppie";
let image = new Image();	
var time = Date.now();
	

$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough fileToShareCreator' style='width: 100%; background-color: black;'><div class='portfolioHeading'>Edit Post<div class='topTopConIcons'></div></div><div class='postScroller' id='editPostScroll"+time+"'></div></div>");	


$("#editPostScroll"+time).append("<div class='fileSharePostPrev' id='fileSharePostPrev'></div>");
$("#fileSharePostPrev").append("<div class='croppieContainer' id='croppieContainer"+time+"'></div>");
$("#fileSharePostPrev").append("<div class='fileShareCanvasCon' id='fileShareCanvasCon'><img src='"+fileToShareURL+"' style='width: 350px; height: auto;' class='originalImageSizeToShare'></div>");
image.onload = function() {	

//CONSTRUCT THE CROPPER	
var width = $("#croppieContainer"+time).width();
var square = width;	
$image_crop = $("#croppieContainer"+time).croppie({
enableExit: true,
viewport: {
width: square,
height: square,
type: 'square'
},
boundary: {
width: width,
height: width
}
});
$image_crop.croppie('bind', {
url: fileToShareURL
});


$("#editPostScroll"+time).append("<div class='toggleOrignalCrop' id='toggleOrignalCrop"+time+"'><div class='toggleOrignalCropImg'><img class='hoverimage' src='../assets/fullimageone.png' id='useoriginal'><img class='hoverimage' src='../assets/cropimageone.png' style='display: none;' id='cropfiletoshare'></div></div>");
$("#editPostScroll"+time).append("<div class='shareFileInputsCon'><div class='shareFileInputs'><div class='shareFileInputFields'></div></div></div>");

$(".shareFileInputFields").append("<span style='font-weight: bold;'>Filters</span><div class='filtersForShareCon'><div class='filtersScrollForShare'></div></div>");
var filterNumber = 0;
for (i = 0; i < 17; i++) {
$(".filtersScrollForShare").append("<div class='sharefilter' value='"+filterNumber+"'><img src='"+fileToShareURL+"' class='filter"+filterNumber+"' value='"+filterNumber+"'></div>");
filterNumber++;
}
	

	
//TOGGLE CROP
$("#useoriginal").on("click", function(){
$(this).css("display", "none");
$("#cropfiletoshare").slideDown(100);
$("#croppieContainer"+time).slideUp(100);
$("#fileShareCanvasCon").slideDown(100);
shareFromCroppieOrOriginal = "original";
});	
$("#cropfiletoshare").on("click", function(){
$(this).css("display", "none");
$("#useoriginal").slideDown(100);
$("#croppieContainer"+time).slideDown(100);
$("#fileShareCanvasCon").slideUp(100);
shareFromCroppieOrOriginal = "croppie";
});		
	
	 	 
$(".shareFileInputFields").append("<span style='font-weight: bold;'>Link</span><div class='filtersForShareCon' style='height: auto; overflow: hidden; background-color: black;'><input id='optionalLinkInput' type='text' placeholder='OPTIONAL LINK'></div>");	

//COLLABORATIONS
$(".shareFileInputFields").append("<div class='shareOthersCollaborated'><div class='shareOthersCollabAddICon'><span style='font-weight: bold;'>Collaborations</span> - Others you collaborated with<img class='hoverimage' src='../assets/addone.png' id='loadWWSC'></div><div class='selectedworkedwith'></div></div>");


	


//LOCATION
$(".shareFileInputFields").append("<span style='font-weight: bold;'>Location</span><div class='shareLocationInputs' id='shareLocationInputs'></div>");	
	loadLocationSearch();





//CAPTION
$(".shareFileInputFields").append("<span style='font-size: 12px;' id='shareSomethingLim'>3000</span><div id='shareSomethingDesc' data-placeholder='Say something about this post..' contenteditable='true'></div><div class='userToTagInShare' id='userToTagInShare"+time+"' data-start='0'></div>");
getEditablePostShare();
var element = document.getElementById("userToTagInShare"+time);
appendScrollUserToTag(element);	






	//CONTINUE BUTTONS
$(".shareFileInputFields").append("<div class='confirmShareFileButtons'><button class='conabanpost'>CONFIRM ABANDON!</button><button class='abanPost'>Abandon Post</button><button style='float: right; color: white;' id='confirmFileToShare'>DONE</button></div><br><br><br><br>");



}
 image.src = fileToShareURL;

	

	
}
	// end if photo	




	
	



//AUDIO
if(type == "audio"){
var time = Date.now();
shareFromCroppieOrOriginal = "original";
var selectedAudio = new Audio();
selectedAudio.src = fileToShareURL;
uploadType = "audio";
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough fileToShareCreator' style='width: 100%; background-color: black;'><div class='portfolioHeading'>Edit Post<div class='topTopConIcons'></div></div><div class='postScroller' id='editPostScroll"+time+"'></div></div>");		

	
	
	
//PREVIEW
$("#editPostScroll"+time).append("<div class='selectedAudioPlayerWrap'><div class='selectedAudioContainer'><div class='selectedAudioPreview'><div class='selectAnAudioCoverWrap'><img src='../assets/addcover1.png' class='hoverimage' id='selectAnAudioCover"+time+"'></div><div class='selectedAudioControls' style='display: none;'><div class='selectedAudioPlay'><img class='hoverimage' src='../assets/fullimageone.png' id='useoriginal' style='display: none;'><img class='hoverimage' src='../assets/cropimageone.png' id='cropfiletoshare'></div></div></div></div></div>");

	

	
	
//SEEKER
$("#editPostScroll"+time).append("<div class='selectedAudioSeeker'><img class='hoverimage' src='../assets/playMedia.png' id='playSelectedAudio"+time+"'><img class='hoverimage' src='../assets/pause.png' id='pauseSelectedAudio"+time+"' style='display: none;'><input type='range' min='0' max='100' value='0' id='selectedAudSeek"+time+"'></div>");
	
var selectedAudSeek = document.getElementById('selectedAudSeek'+time);
$(selectedAudSeek).on("mousedown", function(){
isScrollingSelectedAudio = 1;
});
$(selectedAudSeek).on("mouseup", function(){
isScrollingSelectedAudio = 0;
});
$(selectedAudSeek).on("input", function(){
var newSeekPosition = $(this).val();
selectedAudio.currentTime = (newSeekPosition/100) * selectedAudio.duration;
});
selectedAudio.addEventListener('timeupdate', function(){
var currentProgress = (selectedAudio.currentTime / selectedAudio.duration) * 100;
if(isScrollingSelectedAudio == 0){
selectedAudSeek.value= currentProgress;
}
});


	
//INPUTS
$("#editPostScroll"+time).append("<div class='shareFileInputsCon'><div class='shareFileInputs'><div class='shareFileInputFields'></div></div></div>");
	
//FILTERS
$(".shareFileInputFields").append("<span style='font-weight: bold;' class='selAudFilters'>Filters</span><div class='filtersForShareCon selAudFilters'><div class='filtersScrollForShare'></div></div>");

//LINK
$(".shareFileInputFields").append("<span style='font-weight: bold;'>Link</span><div class='filtersForShareCon' style='height: auto; overflow: hidden; background-color: black;'><input id='optionalLinkInput' type='text' placeholder='OPTIONAL LINK'></div>");	
	
//COLLABORATIONS
$(".shareFileInputFields").append("<div class='shareOthersCollaborated'><div class='shareOthersCollabAddICon'><span style='font-weight: bold;'>Collaborations</span> - Others you collaborated with<img class='hoverimage' src='../assets/addone.png' id='loadWWSC'></div><div class='selectedworkedwith'></div></div>");

	

//LOCATION
$(".shareFileInputFields").append("<span style='font-weight: bold;'>Location</span><div class='shareLocationInputs' id='shareLocationInputs'></div>");	



//CAPTION
$(".shareFileInputFields").append("<span style='font-size: 12px;' id='shareSomethingLim'>3000</span><div id='shareSomethingDesc' data-placeholder='Say something about this post..' contenteditable='true'></div><div class='userToTagInShare' id='userToTagInShare"+time+"' data-start='0'>here man</div>");
getEditablePostShare();
var element = document.getElementById("userToTagInShare"+time);
appendScrollUserToTag(element);
	


	

	//CONTINUE BUTTONS
$(".shareFileInputFields").append("<div class='confirmShareFileButtons'><button class='conabanpost'>CONFIRM ABANDON!</button><button class='abanPost'>Abandon Post</button><button style='float: right; color: white;' id='confirmFileToShare'>DONE</button></div><br><br><br><br>");


	
//TOGGLE CROP
$("#useoriginal").on("click", function(){
$(this).css("display", "none");
$("#cropfiletoshare").slideDown(100);
shareFromCroppieOrOriginal = "original";
$("#selectedAudioCoverImg").remove();
var input = document.getElementById('selectedCoverForAudio');
selectedCoverForAudioURL = URL.createObjectURL(input.files[0]);
$(".selectedAudioPreview").append('<div id="selectedAudioCoverImg"><img src="'+selectedCoverForAudioURL+'" class="filter'+selectedFilter+'" id="selAudCoverPrev"></div>');
});	
$("#cropfiletoshare").on("click", function(){
shareFromCroppieOrOriginal = "croppie";
$("#cropfiletoshare").slideUp(100);
$("#useoriginal").slideDown(100);
loadAudioCoverCropper();
});		



	
	//PLAY
	$("#playSelectedAudio"+time).on("click", function(){
	$(this).css("display", "none");
	$("#pauseSelectedAudio"+time).css("display","initial");
	selectedAudio.play();
	});
	//pause
	$("#pauseSelectedAudio"+time).on("click", function(){
	$(this).css("display", "none");
	$("#playSelectedAudio"+time).css("display", "initial");
	selectedAudio.pause();
	});
	




	$("#selectAnAudioCover"+time).on("click", function(){
		$("#selectedCoverForAudio").trigger("click");
	});

	
	loadLocationSearch();

}
	//endif audio
	



	
	





//VIDEO
if(type == "video"){
var time = Date.now();
uploadType = "video";

$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough fileToShareCreator' style='width: 100%; background-color: black;'><div class='portfolioHeading'>Edit Post<div class='topTopConIcons'></div></div><div class='postScroller' id='editPostScroll"+time+"'></div></div>");
	
//VIDEO PLAYER
if(ext == "mov"){
ext = "mp4";
}
$("#editPostScroll"+time).append("<div class='selectedVideoWrap'><video class='selvidplayer' id='video"+time+"' playsinline><source src='"+fileToShareURL+"' type='video/"+ext+"'>Your browser does not support the video tag.</video></div>");
video = document.getElementById("video"+time);

	
//CONTROLS
$("#editPostScroll"+time).append("<div class='selectedAudioSeeker'><img class='hoverimage' src='../assets/playMedia.png' id='playSelectedVideo"+time+"'><img class='hoverimage pauseSelected' src='../assets/pause.png' id='pauseSelectedVideo"+time+"' style='display: none;'><input type='range' min='0' max='100' value='0' id='selectedAudSeek"+time+"'></div>");	


//INPUTS
$("#editPostScroll"+time).append("<div class='shareFileInputsCon' style='display: none;'><div class='shareFileInputs'><div class='shareFileInputFields'></div></div></div>");	
	
	
	
//SELECT FRAME
$(".shareFileInputFields").append("<span style='font-weight: bold; display: none;' id='selectFrameHead'>Preview Thumb</span><div class='selectFrameContainer' style='display: none;'><video id='videoThumb"+time+"' playsinline><source src='"+fileToShareURL+"' type='video/"+ext+"'>Your browser does not support the video tag.</video><input id='videoFrameSeek"+time+"' type='range' min='0' max='100' value='0'></div>");	
frameVideo = document.getElementById("videoThumb"+time);
videoFrameSeek = document.getElementById("videoFrameSeek"+time);
$(videoFrameSeek).on("input", function(){
video.pause();
var newSeekPosition = $(this).val();
frameVideo.currentTime = (newSeekPosition/100) * frameVideo.duration;
thumbTime = frameVideo.currentTime;
thumbTime = new Date(thumbTime * 1000).toISOString().substr(11, 8);
$("#pauseSelectedVideo"+time).trigger("click");
});	
	
	


	


	
//FILTERS
$(".shareFileInputFields").append("<span style='font-weight: bold;' class='selAudFilters'>Filters</span><div class='filtersForShareCon selAudFilters'><div class='filtersScrollForShare'></div></div>");




//LINK
$(".shareFileInputFields").append("<span style='font-weight: bold;'>Link</span><div class='filtersForShareCon' style='height: auto; overflow: hidden; background-color: black;'><input id='optionalLinkInput' type='text' placeholder='OPTIONAL LINK'></div>");	

	


//COLLABORATIONS
$(".shareFileInputFields").append("<div class='shareOthersCollaborated'><div class='shareOthersCollabAddICon'><span style='font-weight: bold;'>Collaborations</span> - Others you collaborated with<img class='hoverimage' src='../assets/addone.png' id='loadWWSC'></div><div class='selectedworkedwith'></div></div>");


//LOCATION
$(".shareFileInputFields").append("<span style='font-weight: bold;'>Location</span><div class='shareLocationInputs' id='shareLocationInputs'></div>");	


//CAPTION
$(".shareFileInputFields").append("<span style='font-size: 12px;' id='shareSomethingLim'>3000</span><div id='shareSomethingDesc' data-placeholder='Say something about this post..' contenteditable='true'></div><div class='userToTagInShare' id='userToTagInShare"+time+"' data-start='0'>here man</div>");
getEditablePostShare();
var element = document.getElementById("userToTagInShare"+time);
appendScrollUserToTag(element);
	

	
//CONTINUE BUTTONS
$(".shareFileInputFields").append("<div class='confirmShareFileButtons'><button class='conabanpost'>CONFIRM ABANDON!</button><button class='abanPost'>Abandon Post</button><button style='float: right; color: white;' id='confirmFileToShare'>DONE</button></div><br><br><br><br>");







//CHECK LENGTH 
video.preload = "metadata";  
video.addEventListener("loadedmetadata", function(){
if(video.duration > 90){
resetPostEditor();
$(".fileToShareCreator").remove();
showAlert("Video is longer than 90 seconds", "red");
return;
}
video.currentTime  = 0;	
});
	

	


//CANVAS
frameVideo.preload = "metadata";  
frameVideo.addEventListener("loadedmetadata", function(){

frameVideo.currentTime = 1;

frameVideo.onseeked = () => {
if($(".sharefilter").length == 0){
var filterNumber = 0;
for (i = 0; i < 17; i++) {
$(".filtersScrollForShare").append("<div class='sharefilter' value='"+filterNumber+"'><canvas class='imageForVidFilter' id='imageForVidFilter"+filterNumber+"' width='70' height='70'></canvas></div>");
appendFiltersForVideo(time, filterNumber);
filterNumber++;
}
}
}	
});	
	
	
	
	
	
//SEEK
var selectedAudSeek = document.getElementById('selectedAudSeek'+time);
$(selectedAudSeek).on("mousedown", function(){
isScrollingSelectedAudio = 1;
});
$(selectedAudSeek).on("mouseup", function(){
isScrollingSelectedAudio = 0;
});
$(selectedAudSeek).on("input", function(){
var newSeekPosition = $(this).val();
video.currentTime = (newSeekPosition/100) * video.duration;
});
video.addEventListener('timeupdate', function(){
var currentProgress = (video.currentTime / video.duration) * 100;
if(isScrollingSelectedAudio == 0){
selectedAudSeek.value= currentProgress;
}
});
	



	
	//PLAY
	$("#playSelectedVideo"+time).on("click", function(){
	$(this).css("display", "none");
	$("#pauseSelectedVideo"+time).css("display","initial");
	$(".selAudFilters").slideDown(100);
	$("#selectFrameHead").slideDown(100);
	$(".selectFrameContainer").slideDown(100);
	$(".shareFileInputsCon").slideDown(100);
	frameVideo.play();
	frameVideo.pause();;
	video.play();
	});
	//pause
	$("#pauseSelectedVideo"+time).on("click", function(){
	$(this).css("display", "none");
	$("#playSelectedVideo"+time).css("display", "initial");
	video.pause();
	});
		

	
	loadLocationSearch();

}
//end if video







}
//


	

	
//ABANDON POST
$("body").on("click", ".conabanpost", function(){
resetPostEditor(1);
});
$("body").on("click", ".abanPost", function(){
$(this).slideUp(10);
$("#confirmFileToShare").slideUp(10);
setTimeout(function(){
$(".conabanpost").slideDown(150);
}, 500);
setTimeout(function(){
$(".conabanpost").slideUp(10);
$(".abanPost").slideDown(10);
$("#confirmFileToShare").slideDown(10);
}, 3000);
});



	
//USER TO TAG SHARE SCROLL
function appendScrollUserToTag(element){
$(element).on("scroll", function(){


var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+100){

getUsersToTag(userToTagSearch, userToTagStart);
userToTagStart = userToTagStart + 7;

	
}
}, 150);	
	
	
	
});	
}

	



	
//LOCATION CONTROLS FOR SHARE
function loadLocationSearch(){
$("#shareLocationInputs").append("<button class='chooseLocationForShare' id='chooseLocationForShare'>SELECT</button>");
}
	
	
	







//TOGGLE SEARCH
$("body").on("click", "#showDiscSearch",function(){
var state = $(this).attr("value");
if(state == "hidden"){
$("#discoverscrollwrap").addClass("discoverscrollwrap1");
$("#discovermenuwrap").addClass("discovermenuwrap1");
$("#discovermenuicons").slideUp(100);
$("#discoversearchheading").slideDown(100);
$("#discoversearchinputs").slideDown(100);
$(this).attr("value", "showing");
}else{
$("#discoverscrollwrap").removeClass("discoverscrollwrap1");
$("#discovermenuwrap").removeClass("discovermenuwrap1");
$("#discovermenuicons").slideDown(100);
$("#discoversearchheading").slideUp(100);
$("#discoversearchinputs").slideUp(100);
$(this).attr("value", "hidden");
}
});
	
$("body").on("mousedown touchstart", "#discoverScroller", function(){
if($("#showDiscSearch").attr("value") == "showing"){
$("#showDiscSearch").trigger("click");
$("#talentDiscoverSearch").val('');
}
});
	




	


//OPEN TALENT FILTER
$("body").on("click", ".chooseTalentsFilter",function(){
var time = Date.now();
if(clickDelay == 0){
if($("#talentFiltContainer").length > 0){
$("#talentFiltContainer").fadeIn(100);
return;
}
$("#profileLoaderContainer").append("<div class='universalcontainer universalSeeThrough universalcontainer"+time+" universalSeeThrough' id='talentFiltContainer' style='width: 100%;'><div id='talentFilterWrap' class='talentFilterWrap'></div></div>");	

var talents = arrayOfTalents.split(',');
$("#talentFilterWrap").append("<div class='eachTalentFilter hoverElement' data-value=''>All</div>");	
for(var i = 0; i < talents.length; i++){
if(talents[i] !== ""){

var value = talents[i];
if(value == "Programmer (Web/Mobile)"){
value = "Programmer";
}

$("#talentFilterWrap").append("<div class='eachTalentFilter hoverElement' data-value='"+value+"'>"+talents[i]+"</div>");

}
}
	
	
}
});




//OPEN LOCATION SEARCH	
$("body").on("click", ".chooseLocationForShare",function(){
loadLocationSearchWindow();
});
	

function loadLocationSearchWindow(){
var time = Date.now();
if(clickDelay == 0){
if($("#locationSearchWrap").length > 0){
$("#locationSearchWrap").fadeIn();
return;
}
$("#profileLoaderContainer").append("<div class='universalcontainer universalSeeThrough universalcontainer"+time+" universalSeeThrough' id='locationSearchWrap' style='width: 100%;'><div class='searchcontainersheading' style='position: initial;'><input type='text' class='locationforshare' id='locationforshare"+time+"' placeholder='Search Location'><button class='cwwt' id='closelocationsearch"+time+"'>x</button></div><div id='locationSearchScroller' data-start='0'></div></div>");
	
	
	
	
$("#locationforshare"+time).on("keyup", function(){
$("#locationSearchScroller").empty();
$("#locationSearchScroller").attr("data-start", 0);
var start = $("#locationSearchScroller").attr("data-start");
var value = $(this).val();
getLocations(value, start).then(function(response){
constructLocations(response);
});
});
	
	
	
	
	
//CLOSE
$("#closelocationsearch"+time).on("click", function(){
$("#locationSearchWrap").fadeOut("fast");
});
setTimeout(function(){
clickDelay = 0;
}, 250);
}	
}


	

function getLocations(value, start){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/getlocations.php",
method: "POST",
data: {
value: value,
start: start,
isWebsite: 1
},
success: function(response){

if (response !== "error")
resolve(response);
else
reject("Something Went Wrong Please Try Again");
	
}
});
	
	

});	
}




function constructLocations(response){
if(response == "end"){
return;
}

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var location = data[i];

$("#locationSearchScroller").append("<div class='eachLocation hoverelement' id='eachLocation"+location.id+"' data-id='"+location.id+"'><span id='eachLocationCommaString"+location.id+"' style='display: none;'>"+location.name+","+location.StateName+","+location.countryName+"</span><p id='thisLocationText"+location.id+"'>"+location.name+", "+location.StateName+"</p></div>");


}	
}
	
	



//WHEN LOCATION SELECTS
$("body").on("click", ".eachLocation", function(){
var id = $(this).attr("data-id");
$(".eachLocation").css("background-color", "transparent");
$("#eachLocation"+id).css("background-color", "#214844");
let location = $("#thisLocationText"+id).html();
let locationString = $("#eachLocationCommaString"+id).text();
$(".chooseLocationForShare").html(location);
$("#locationSearchWrap").fadeOut(100);
	
//IF POST SHARE
if($(".fileToShareCreator").length > 0){
let Arr = locationString.split(',');
shareCity = Arr[0];
shareState = Arr[1];
shareCountry = Arr[2];
}
	
	
	
//IF UPDATING LOCATION
if($("#myLocationSelector").length > 0){
let Arr = locationString.split(',');
userLoggedInCity = Arr[0];
userLoggedInState = Arr[1];
userLoggedInCountry = Arr[2];
$("#myLocationSelector").val(userLoggedInCity+", "+userLoggedInState);
}
	
	
//IF CREATING PROJECT GOAL
if($(".newProjectForm").length > 0){
let Arr = locationString.split(',');
projectCity = Arr[0];
projectState = Arr[1];
projectCountry = Arr[2];
}



});

	

	




	




//FUNCTION APPEND VIDEO FILTERS
function appendFiltersForVideo(time, filterNumber){
var video = document.getElementById("videoThumb"+time);
var canvas = document.getElementById('imageForVidFilter'+filterNumber);

window.requestAnimationFrame(() => {
window.requestAnimationFrame(() => {
	
canvas.height = 70;
canvas.width = 70;
	
canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
	
});	
});

}



	
	

//APPLY FILTER TO SHARE
$("body").on("click", ".sharefilter",function(){
$(".sharefilter").css("border", "none");
$(this).css("border", "3px solid white");
selectedFilter = $(this).attr("value");
for(var i = 0; i<17; i++){
$(".cr-image").removeClass("filter"+i);
$(".originalImageSizeToShare").removeClass("filter"+i);
$("#selAudCoverPrev").removeClass("filter"+i);
$(".selvidplayer").removeClass("filter"+i);
}
$(".cr-image").addClass("filter"+selectedFilter);
$(".originalImageSizeToShare").addClass("filter"+selectedFilter);	
$("#selAudCoverPrev").addClass("filter"+selectedFilter);
$(".selvidplayer").addClass("filter"+selectedFilter);
});




	
	
//LOAD AUDIO COVER CROPPER
function loadAudioCoverCropper(){
if($(".audioCoverCropper").length > 0){
$(".audioCoverCropper").fadeIn(100);
return;
}
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer audioCoverCropper' style='width: 100%; background-color: black;'><div class='portfolioHeading'>Crop Cover<div class='topTopConIcons'></div></div><div class='postScroller' id='editPostScroll"+time+"'></div></div>");	

$("#editPostScroll"+time).append("<div class='croppieContainer' id='croppieContainer"+time+"'></div>");
	
//CONTINUE BUTTONS
$("#croppieContainer"+time).append("<button style='float: right; color: white;' id='confirmAudioCoverCrop"+time+"'>CONTINUE</button>");
	
//CONSTRUCT THE CROPPER	
var width = $("#croppieContainer"+time).width();
var square = width;	
$image_crop = $("#croppieContainer"+time).croppie({
enableExit: true,
viewport: {
width: square,
height: square,
type: 'square'
},
boundary: {
width: width,
height: width
}
});
$image_crop.croppie('bind', {
url: selectedCoverForAudioURL
});
	
	
//CONTINUE
$("#confirmAudioCoverCrop"+time).on("click", function(){
$image_crop.croppie('result', {
 type: 'canvas',
 size: {width: 500, height: 500},
quality: 1
}).then(function(response){
selectedCoverForAudioURL = response;
$("#selectedAudioCoverImg").remove();
$(".selectedAudioPreview").prepend('<div id="selectedAudioCoverImg"><img src="'+selectedCoverForAudioURL+'" class="filter'+selectedFilter+'" id="selAudCoverPrev"></div>');
$(".audioCoverCropper").fadeOut(100);
});
});
	
	
}

	







//SELECT AUDIO COVER ON CHANGE
$("#selectedCoverForAudio").on("change", function(event){
var selectedAudioCoverInput = $(this).val();
var size = document.getElementById('selectedCoverForAudio').files[0].size;
var ext = selectedAudioCoverInput.split('.').pop();
ext = ext.toLowerCase();
selectedCoverForAudioExt = ext;

if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){
if(size > 16000000){
showAlert("File exceeds 15MB", "red");
}else{
var input = document.getElementById('selectedCoverForAudio');
selectedCoverForAudioURL = URL.createObjectURL(input.files[0]);	
$(".selectAnAudioCoverWrap").remove();
$(".selectedAudioPreview").prepend("<div id='selectedAudioCoverImg'><img src='"+selectedCoverForAudioURL+"' id='selAudCoverPrev'></div>");
$(".selectedAudioControls").slideDown(100);	
	
var filterNumber = 0;
for (i = 0; i < 17; i++) {
$(".filtersScrollForShare").append("<div class='sharefilter' value='"+filterNumber+"'><img src='"+selectedCoverForAudioURL+"' class='filter"+filterNumber+"' value='"+filterNumber+"'></div>");
filterNumber++;
}
$(".selAudFilters").slideDown();
	
}	
}else{
showAlert("Unaccepted Format", "red");
}
});
		
	
	





//CONFIRM ATTACH
$("body").on("click", "#confirmFileToShare", function(){
$("#attachedFileIcon").empty();
optionalLink = $("#optionalLinkInput").val();
var caption = $("#shareSomethingDesc").text();
var length = caption.length;
if(length > 3000){
showAlert("Check Character Limits", "red");
return;
}
//PHOTO
if(uploadType == "photo"){
var text = "photo";
//IF CROPPIE
if(shareFromCroppieOrOriginal == "croppie"){
$image_crop.croppie('result', {
 type: 'canvas',
 size: {width: 500, height: 500},
quality: 1
}).then(function(response){
shareCroppieURL = response;
appendShareFile(uploadType, text, shareCroppieURL);
});
}else{
appendShareFile(uploadType, text, fileToShareURL);
}
}// end if photo
	
	

	
//AUDIO
if(uploadType == "audio"){
var text = "audio";
if(selectedCoverForAudioURL == ""){
showAlert("A cover photo is required", "red");
return;
}
if(shareFromCroppieOrOriginal == "croppie"){
appendShareFile(uploadType, text, selectedCoverForAudioURL);
}else{
var input = document.getElementById('selectedCoverForAudio');
selectedCoverForAudioURL = URL.createObjectURL(input.files[0]);	
appendShareFile(uploadType, text, selectedCoverForAudioURL);
}
}
	
	


//VIDEO
if(uploadType == "video"){
var text = "video";
appendShareFile(uploadType, text, fileToShareURL);
}



	

});	



	





//APPEND SHARE FILE
function appendShareFile(uploadType, text, fileToShareURL){
$(".pauseSelected").trigger("click");
$(".fileToShareCreator").fadeOut("fast");
$("#fileBeingShared").empty();
setTimeout(function(){
$("#confirmShareButton").slideDown(100);
if(uploadType == "photo" || uploadType == "audio"){
$("#fileBeingShared").append("Attached "+text+" <img class='fadeInfileToShareCreator' src='"+fileToShareURL+"' class='filter"+selectedFilter+" hoverimage'>");
$("#fileBeingShared").fadeTo("fast", .3).fadeTo("fast", 1).fadeTo("fast", .3).fadeTo("fast", 1);
}else{
var ext = fileToShareExt;
if(ext == "mov"){
ext = "mp4";
}	
$("#fileBeingShared").append("Attached "+text+ "<video class='fadeInfileToShareCreator filter"+selectedFilter+"' id='finalVidPrev' playsinline><source class='fpVideoSrc' src='"+fileToShareURL+"' type='video/"+ext+"'>Your browser does not support the video tag.</video>");
let video = document.getElementById("finalVidPrev");
video.preload = "metadata";  
video.addEventListener("loadedmetadata", function(){
video.currentTime  = 1;
});
}
}, 500);	
}

	



	
	
//FADE IN FILE TO SHARE CREATOR
$("body").on("click", ".fadeInfileToShareCreator", function(){
$(".fileToShareCreator").fadeIn();
});



//LOAD WORKED WITH SEARCH
$("body").on("click", "#loadWWSC", function(){
loadWWSC();
});
	
	






	



	
//EXPAND FEED	
$("body").on("mousedown", ".feedHandleToggleImage", function(){
var user = $(this).attr("data-user");
var img = document.getElementById('feedHandleImg'+user);
var position = $(this).attr("data-position");
if(position == "up"){
$("#feedProfImage"+user).slideDown();
img.style.transform = 'rotate(180deg)';
$(this).attr("data-position", "down");
var bodyRect = document.body.getBoundingClientRect();
var element = document.getElementById('feedUpperX'+user);
var elemRect = element.getBoundingClientRect();
var offset   = elemRect.top - bodyRect.top;
offset = offset - 28;
$("#feed"+user).animate({top: offset+"px"});
}else{
$("#feedProfImage"+user).slideUp();
img.style.transform = 'rotate(0deg)';
$(this).attr("data-position", "up");
var bodyRect = document.body.getBoundingClientRect();
var element = document.getElementById('feedLowerX'+user);
var elemRect = element.getBoundingClientRect();
var offset   = elemRect.top - bodyRect.top;
offset = offset - 28;
$("#feed"+user).animate({top: offset+"px"});
}
});


	

	


//EDITABLE SHARE DIV
$("body").on("input", editablePostShare,function(e){
var key = e.keyCode;
var value = $(this).text();
var length = value.length;


});


	


	







	

	





	



	



//ACCEPT COLLABED WITH	
function acceptCollabWith(noteID, postID, userFrom){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/acceptcollabwith.php",
method: "POST",
data: {
notificationID: noteID,
postID: postID,
userFrom: userFrom,
isWebsite: 1
},
success: function(response){


resolve(response);

	
}
});
	
	

});	
	
}


//
	

	





$("body").on("click", ".showLoginForm", function(){
$("#signupMessage").text("Login");
$("#signupFormItems").slideUp(100);
$(".loginFormContainer").slideDown(100);
$(".welcomepolicycon").slideUp(100);
});

	

$("body").on("click", ".showSignupForm", function(){
$("#signupMessage").text("Signup");
$("#signupFormItems").slideDown(100);
$(".loginFormContainer").slideUp(100);
$(".welcomepolicycon").slideDown(100);
});

//signup
	
	
//LOGIN
$("body").on("click", "#submitLogin", function(){
var device = getDevice();
var email = $("#loginEmail").val();
var password = $("#loginPassword").val();
if(email.length > 100 || password.lenght > 100){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMITS</p>");
showSuccess();
return;
}
var login = 1;
if(email !== '' && password !==''){
$.ajax({
url: "https://troupebase.com/formhandlers/login.php",
method: "POST",
data: {
email: email,
password: password,
device: device,
isWebsite: 1
},
success: function(response){
if(response == "not found"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>USER NOT FOUND</p>");
showSuccess();
return;
}
if(response == "wrong password"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>INCORRECT LOGIN</p>");
showSuccess();
return;
}	

	
conHomebase(response);
}
});
}else{
alert("ENTER ALL FIELDS");
}
});
//login
	
	
	
//PROFILE SETTINGS
	




	
$("body").on("change", "#toggleMessageReceipt",function(){
messageReceipt = $(this).val();
$.ajax({
url: "https://troupebase.com/formhandlers/updatemessagereceipt.php",
method: "POST",
data: {
messageReceipt: messageReceipt,
isWebsite: 1
}
});
});


$("body").on("click", "#openProfileSettings",function(){
$("#profileSettingsContainer").animate({width: "100%"});
});
	
//REMOVE LINK
$("body").on("click", ".removeSocialLink", function(){
	
var link = $(this).attr("value");
var update = 1;
var removeLink = 1;
	
	
if(link == "facebook"){
var currentLink = $("#facebookIcon").attr("value");
currentLink = "facebook="+currentLink;
$("#newFacebookLinkContainer").slideUp(100);
$("#newFacebookLink").val("");
$("#facebookIcon").remove();
}
	
	
if(link == "instagram"){
var currentLink = $("#instagramIcon").attr("value");
currentLink = "instagram="+currentLink;
$("#newInstagramLinkContainer").slideUp(100);
$("#newInstagramLink").val("");
$("#instagramIcon").remove();
}
	
if(link == "applemusic"){
var currentLink = $("#applemusicIcon").attr("value");
currentLink = "applemusic="+currentLink;
$("#newAppleMusicLinkContainer").slideUp(100);
$("#newAppleMusicLink").val("");
$("#applemusicIcon").remove();
}
	
if(link == "amazon"){
var currentLink = $("#amazonIcon").attr("value");
currentLink = "amazon="+currentLink;
$("#newAmazonLinkContainer").slideUp(100);
$("#newAmazonLink").val("");
$("#amazonIcon").remove()
}
	
if(link == "spotify"){
var currentLink = $("#spotifyIcon").attr("value");
currentLink = "spotify="+currentLink;
$("#newSpotifyLinkContainer").slideUp(100);
$("#newSpotifyLink").val("");
$("#spotifyIcon").remove();
}
	
if(link == "youtube"){
var currentLink = $("#youtubeIcon").attr("value");
currentLink = "youtube="+currentLink;
$("#newYoutubeLinkContainer").slideUp(100);
$("#newYoutubeLink").val("");
$("#youtubeIcon").remove();
}
	
if(link == "tidal"){
var currentLink = $("#tidalIcon").attr("value");
currentLink = "tidal="+currentLink;
$("#newTidalLinkContainer").slideUp(100);
$("#newTidalLink").val("");
$("#tidalIcon").remove();
}
	
if(link == "twitch"){
var currentLink = $("#tidalIcon").attr("value");
currentLink = "tidal="+currentLink;
$("#newTwitchLinkContainer").slideUp(100);
$("#newTwitchLink").val("");
$("#twitchIcon").remove();
}
	
if(link == "tiktok"){
var currentLink = $("#tiktokIcon").attr("value");
currentLink = "tiktok="+currentLink;
$("#newTikTokLinkContainer").slideUp(100);
$("#newTikTokLink").val("");
$("#tiktokIcon").remove();
}
	
if(link == "soundcloud"){
var currentLink = $("#soundcloudIcon").attr("value");
currentLink = "soundcloud="+currentLink;
$("#newSoundcloudLinkContainer").slideUp(100);
$("#newSoundcloudLink").val("");
$("#soundcloudIcon").remove();
}
	
return;

$("#formHandlerDiv").load("https://troupebase.com/formHandlers/profileSettings.php",{
currentLink: currentLink,
update: update,
userLoggedIn: userLoggedIn,
removeLink: removeLink
});	
	
});	
//
	
	

	
//ADD SOCIAL LINK
$("body").on("change", "#addSocialLink",function(){
var linkToAdd = $(this).val();
if(linkToAdd == "facebook"){
$("#newFacebookLinkContainer").slideDown(100);
}
if(linkToAdd == "instagram"){
$("#newInstagramLinkContainer").slideDown(100);
}
if(linkToAdd == "applemusic"){
$("#newAppleMusicLinkContainer").slideDown(100);
}
if(linkToAdd == "amazon"){
$("#newAmazonLinkContainer").slideDown(100);
}
if(linkToAdd == "spotify"){
$("#newSpotifyLinkContainer").slideDown(100);
}
if(linkToAdd == "youtube"){
$("#newYoutubeLinkContainer").slideDown(100);
}
if(linkToAdd == "tidal"){
$("#newTidalLinkContainer").slideDown(100);
}
if(linkToAdd == "twitch"){
$("#newTwitchLinkContainer").slideDown(100);
}
if(linkToAdd == "tiktok"){
$("#newTikTokLinkContainer").slideDown(100);
}
if(linkToAdd == "soundcloud"){
$("#newSoundcloudLinkContainer").slideDown(100);
}
$("#addSocialLink").val("Add Link");
});
//


	
	


//UPDATE PROFILE PIC

	
//CANCEL PROFILE PIC UPLOAD
$("body").on("click", ".cancelProfilePicUpload", function(){
$(".profilePictureCropper").fadeOut(100);
$("#newProfilePic").val("");
newProfilePicURL="";
selectedProfFilter= 0;
setTimeout(function(){
$(".profilePictureCropper").remove();
}, 150);
});
//cancel profile pic upload

	
	



//COMPLETE PROFILE PIC UPLOAD
$("body").on("click", ".completeProfPicUpload", function(){
$(this).slideUp(10);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>PLEASE WAIT..</p>");
showSuccess();	

var profilepic = newProfilePicURL;
if(newProfilePicURL !=="" && newProfilePicURL !== null){
$.ajax({
url: "https://troupebase.com/formhandlers/updateprofilepic.php",
method: "POST",
data: {
profilepic: profilepic,
selectedProfFilter: selectedProfFilter,
isWebsite: 1
},
success: function(response){
if(response == "error"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SOMETHING WENT WRONG, TRY AGAIN</p>");
showSuccess();	
return;
}

var data = JSON.parse(response);
var photoDetails = data[0];
	
setItem("profilePic", photoDetails.photo);

var userLoggedIn = localStorage.getItem("TroupeBaseID");
	
$("#uliProfilePhotoContainer").empty();
$("#uliProfilePhotoContainer").append("<img src='"+photoDetails.photo+"' id='featuredTroupePhoto' class='userLoggedInPhoto userLoggedInLink thisUsersPic"+userLoggedIn+" filter"+photoDetails.filter+"'>");

$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>PROFILE PIC SUCCESSFULLY UPDATED!</p>");
showSuccess();	
$(".cancelProfilePicUpload").trigger("click");
}
});	
	
}
	
});








//CHANGE FILTER
$("body").on("click", ".eachProfilePicFilter", function(){
for(var i = 0; i<17; i++){
$(".croppedProfileIMG").removeClass("filter"+i);
}
selectedProfFilter = $(this).attr("value");	
$(".croppedProfileIMG").addClass("filter"+selectedProfFilter);
});
//change filer


$("body").on("click", ".showProfilePicFilters", function(){
$(this).fadeOut(100);
	
$image_crop.croppie('result', {
type: 'canvas',
size: 'viewport',
quality: .5
}).then(function(response){
newProfilePicURL = response;
$(".croppedProfilePic").append("<img class='croppedProfileIMG' src='"+response+"'>");
});
	
	
$(".profPicPreviewContainer").slideUp(10);
$(".profpicuploadhead").text("FILTER");
$(".croppedProfilePic").slideDown(10);
$(".profilePicFiltersContainer").slideDown(10);
$(".completeProfPicUpload").slideDown(10);
});




	


//
	


//UPDATE BACKGROUND PIC

$("#backGroundPicForm").on("submit", function(e){
e.preventDefault();
$("#backGroundPicForm").slideUp(100);
$("#profileSettingsResponse").text("CHECKING PHOTO..");
$.ajax({
url: "https://troupebase.com/formHandlers/backgroundPhoto.php?user="+userLoggedIn,
method: "POST",
data: new FormData(this),
contentType: false,
processData: false,
success: function(response){
$("#formHandlerDiv").text(response);
}
});
});

	
$("#newBackgroundPic").on("change", function(){
$("#backGroundPicForm").trigger("submit");
});


//update background pic


//UPDATE PROFILE PIC	
$("body").on("change", "#newProfilePic", function(e){
loadProfilePicUploader();
});

function loadProfilePicUploader()
{

$("#profileLoaderContainer").append("<div class='profilePictureCropper'><div class='croppedProfilePic'></div><div class='profPicPreviewContainer'></div><div style='width: 100%; text-align: center' class='profpicuploadhead'>RESIZE PHOTO</div><br><div class='profilePicFiltersContainer'><div class='profilePicFilters'></div></div><br><div class='confirmProfPicCropButton'><button class='profilepicuploadbuttons completeProfPicUpload' style='display: none;'>NEXT</button><button class='profilepicuploadbuttons showProfilePicFilters'>NEXT</button><br><br><br><button class='cancelProfilePicUpload'>Nevermind</button></div></div>");
	
var file = $("#newProfilePic").val();
var ext = file.split('.').pop();
ext = ext.toLowerCase();
var size = event.target.files[0].size;
	
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){

var newProfilePicInput = document.getElementById("newProfilePic");
var newProfilePicInputUrl = URL.createObjectURL(newProfilePicInput.files[0]);	

setTimeout(function(){

var width = $(".profPicPreviewContainer").width();
var square = width - 20;
	
$image_crop = $(".profPicPreviewContainer").croppie({
enableExit: true,
viewport: {
width: square,
height: square,
type: 'circle'
},
boundary: {
width: width,
height: width
}
});
	
$image_crop.croppie('bind', {
url: newProfilePicInputUrl
});	
	
var filterNumber = 0;
$(".filtersScroll").empty();
for (i = 0; i < 17; i++) {
$(".profilePicFilters").append("<div class='profPicFilter'><img src='"+newProfilePicInputUrl+"' class='eachProfilePicFilter filter"+filterNumber+"' value='"+filterNumber+"'></div>");
filterNumber++;
}
	
}, 200);
	
	
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>UNSUPPORTED FORMAT</p>");
showSuccess();
$(".cancelProfilePicUpload").trigger("click");
}
	

}

//


	


//REPORT ERROR
$(".submitErrorReport").on("click", function(){
var details = $(".errorReportDetails").val();
if(details == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>TELL US ABOUT THE ERROR</p>");
showSuccess();
return;
}
if(details.length>200){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMIT</p>");
showSuccess();
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>THANK YOU FOR YOUR REPORT</p>");
showSuccess();
$(".reportErrorsForm").slideUp(50);
$(".errorReportDetails").val("");
$.ajax({
url: "https://troupebase.com/formHandlers/reporterror.php",
method: "POST",
data: {
details: details,
reportError: 1
}
});
}
});
$(".reportErrorsButton").on("click", function (){
$(".reportErrorsForm").slideDown(50);
});
$(".cancelErrorReport").on("click", function(){
$(".reportErrorsForm").slideUp(50);
});
//report error




	
	
	
//DONE PROFILE UPDATE
$("body").on("click", "#done",function(){
var alias = $("#desiredAlias").val();
if($("#notalentselected").length > 0){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SELECT AT LEAST ONE TALENT</p>");
showSuccess();
return;
}
if(alias.length > 30){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>USERNAME CANNOT BE OVER 30 CHARACTER</p>");
showSuccess();
return;
}
if(alias == "" || alias == undefined){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>YOU MUST PROVIDE A USERNAME</p>");
showSuccess();
return;
}
$(this).slideUp(50);
$(".reportErrorsButton").slideUp(50);
$.ajax({
url: "https://troupebase.com/formhandlers/updateusername.php",
method: "POST",
data: {
alias: alias,
isWebsite: 1
},
success: function(response){
if(response=="success"){
updateSettings();
}else{
if(response == "taken"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>USERNAME TAKEN</p>");
showSuccess();
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CONNECTION ERROR TRY AGAIN LATER</p>");
showSuccess();
}

	
}
$("#done").slideDown(50);
}
});
});


	

//UPDATE SETTINGS FUNCTION
function updateSettings(){
	
var newName = $("#newName").val();
if(newName == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>NAME REQUIRED</p>");
showSuccess();
return;
}
var newProfileMessage = $("#newProfileMessage").val();
if(newProfileMessage.length > 100 || newName.length > 50 ){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMITS</p>");
showSuccess();
return;
}

$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>PLEASE WAIT..</p>");
$("#successResponseDropDown").slideDown();
	

if(userLoggedInState == "" || userLoggedInCity == "" || userLoggedInCountry == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>PLEASE SELECT YOUR LOCATION</p>");
showSuccess();
return;
}
	

	
var timeZone = userLoggedInState;
if(timeZone == "" || timeZone == undefined || timeZone == "undefined" || timeZone == "SELECT ONE"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>PLEASE SELECT YOUR LOCATION</p>");
showSuccess();
return;
}
	
var timeZoneStorage = timeZone.replace(' ','_', timeZone);
if(userLoggedInCountry == "United States"){
timeZoneStorage = "America/"+timeZoneStorage;
}
if(userLoggedInCountry !== "United States"){
timeZoneStorage = userLoggedInCountry+"/"+timeZoneStorage;
}
var expiryDate = new Date();
expiryDate.setMonth(expiryDate.getMonth() + 1);
localStorage.setItem('TimeZone', timeZoneStorage);
document.cookie = "TimeZone="+timeZoneStorage+";expires="+ expiryDate +";domain=.troupebase.com;path=/";
var troupeRequestPrivacy = $("#troupeRequestPrivacy").val();
var collabRequestPrivacy = $("#collabRequestPrivacy").val();
var projectGoalVisibility = $("#projectGoalVisibility").val();
var newWebsite = $("#newWebsite").val();
if(newWebsite !==""){
newWebsite = newWebsite.toLowerCase();
if(newWebsite.includes("http")){
}else{
newWebsite="http://"+newWebsite;
}
}	
$("#currentWebsite").html(newWebsite);
var newFacebookLink = $("#newFacebookLink").val();	
if(newFacebookLink !==""){
newFacebookLink = newFacebookLink.toLowerCase();
if(newFacebookLink.includes("http")){
}else{
newFacebookLink="http://"+newFacebookLink;
}
}
var newInstagramLink = $("#newInstagramLink").val();
if(newInstagramLink !==""){
newInstagramLink = newInstagramLink.toLowerCase();
if(newInstagramLink.includes("http")){
}else{
newInstagramLink="http://"+newInstagramLink;
}
}
var newAppleMusicLink = $("#newAppleMusicLink").val();
if(newAppleMusicLink !==""){
newAppleMusicLink = newAppleMusicLink.toLowerCase();
if(newAppleMusicLink.includes("http")){
}else{
newAppleMusicLink="http://"+newAppleMusicLink;
}
}
var newAmazonLink = $("#newAmazonLink").val();
if(newAmazonLink !==""){
newAmazonLink = newAmazonLink.toLowerCase();
if(newAmazonLink.includes("http")){
}else{
newAmazonLink="http://"+newAmazonLink;
}
}
var newSpotifyLink = $("#newSpotifyLink").val();
if(newSpotifyLink !==""){
newSpotifyLink = newSpotifyLink.toLowerCase();
if(newSpotifyLink.includes("http")){
}else{
newSpotifyLink="http://"+newSpotifyLink;
}
}
var newYoutubeLink = $("#newYoutubeLink").val();
if(newYoutubeLink !==""){
newYoutubeLink = newYoutubeLink.toLowerCase();
if(newYoutubeLink.includes("http")){
}else{
newYoutubeLink="http://"+newYoutubeLink;
}
}
var newTidalLink = $("#newTidalLink").val();
if(newTidalLink !==""){
newTidalLink = newTidalLink.toLowerCase();
if(newTidalLink.includes("http")){
}else{
newTidalLink="http://"+newTidalLink;
}
}
var newTwitchLink = $("#newTwitchLink").val();
if(newTwitchLink !==""){
newTwitchLink = newTwitchLink.toLowerCase();
if(newTwitchLink.includes("http")){
}else{
newTwitchLink="http://"+newTwitchLink;
}
}
var newTikTokLink = $("#newTikTokLink").val();
if(newTikTokLink !==""){
newTikTokLink = newTikTokLink.toLowerCase();
if(newTikTokLink.includes("http")){
}else{
newTikTokLink="http://"+newTikTokLink;
}
}
var newSoundcloudLink = $("#newSoundcloudLink").val();
if(newSoundcloudLink !==""){
newSoundcloudLink = newSoundcloudLink.toLowerCase();
if(newSoundcloudLink.includes("http")){
}else{
newSoundcloudLink="http://"+newSoundcloudLink;
}	
}
	

$.ajax({
url: "https://troupebase.com/formhandlers/updateprofile.php",
method: "POST",
data: {
newName: newName,
newCity: userLoggedInCity,
newState: userLoggedInState,
newCountry: userLoggedInCountry,
timeZone: timeZoneStorage,
newWebsite: newWebsite,
troupeRequestPrivacy: troupeRequestPrivacy,
collabRequestPrivacy: collabRequestPrivacy,
projectGoalVisibility: projectGoalVisibility,
newFacebookLink: newFacebookLink,
newInstagramLink: newInstagramLink,
newAppleMusicLink: newAppleMusicLink,
newAmazonLink: newAmazonLink,
newSpotifyLink: newSpotifyLink,
newYoutubeLink: newYoutubeLink,
newTidalLink: newTidalLink,
newTwitchLink: newTwitchLink,
newTikTokLink: newTikTokLink,
newSoundcloudLink: newSoundcloudLink,
newProfileMessage: newProfileMessage,
isWebsite: 1
},
success: function(response){
if(response == "success"){
var userLoggedIn = localStorage.getItem("TroupeBaseID");
var alias = $("#desiredAlias").val();
userLoggedInState = userLoggedInState;
	
$(".thisusersname"+userLoggedIn).html(newName+" "+" (@"+alias+")");
$("#currentLocation").html("Location: "+userLoggedInState);
	

//UPDATE TALENTS AND LOCATION
var newTalentString = "";
var elements = document.getElementsByClassName("eachselectedtalent");
for (var i = 0; i < elements.length; i++){
var el = elements[i];
var talent = el.innerText;
newTalentString = newTalentString+talent+", ";
}
newTalentString = newTalentString+userLoggedInState;
$("#userLoggedInTalents").html(newTalentString);
	
	
$("#currentProfileMessage").html(newProfileMessage);
	
$("#profileSettingsContainer").animate({width: "0%"});
$("#successResponseDropDown").slideUp();
	
//UPDATE SOCIAL ICONS
if(newFacebookLink !== ""){
$(".myfblink").attr("value", newFacebookLink);
$(".myfblink").css("display", "initial");
}
if(newInstagramLink !== ""){
$(".myiglink").attr("value", newInstagramLink);
$(".myiglink").css("display", "initial");
}	
if(newAppleMusicLink !== ""){
$(".myapplemusiclink").attr("value", newAppleMusicLink);
$(".myapplemusiclink").css("display", "initial");
}		
if(newAmazonLink !== ""){
$(".myamazonlink").attr("value", newAmazonLink);
$(".myamazonlink").css("display", "initial");
}		
if(newSpotifyLink !== ""){
$(".myspotifylink").attr("value", newSpotifyLink);
$(".myspotifylink").css("display", "initial");
}		
if(newYoutubeLink !== ""){
$(".myyoutubelink").attr("value", newYoutubeLink);
$(".myyoutubelink").css("display", "initial");
}		
if(newTidalLink !== ""){
$(".mytidallink").attr("value", newTidalLink);
$(".mytidallink").css("display", "initial");
}	
if(newTwitchLink !== ""){
$(".mytwitchlink").attr("value", newTwitchLink);
$(".mytwitchlink").css("display", "initial");
}	
if(newTikTokLink !== ""){
$(".mytiktoklink").attr("value", newTikTokLink);
$(".mytiktoklink").css("display", "initial");
}	
if(newSoundcloudLink !== ""){
$(".mysoundcloudlink").attr("value", newSoundcloudLink);
$(".mysoundcloudlink").css("display", "initial");
}		


	
}
}
});	

	
	
}
//done profile update
	




$("body").on("click", "#showPrivacySettings", function(){
$(this).slideUp(100);
$("#privacySettingsSlider").slideDown(100);
});
	


	
	







//DELETE TALENT
$("body").on("click", ".deleteThisTalent", function(){
$("#userLoggedInTalents").html("");
var selection = $(this).attr("value");
var classToRemove = selection.replace(/\s/g, '');
$("."+classToRemove).remove();
$.ajax({
url: "https://troupebase.com/formhandlers/removeatalent.php",
method: "POST",
data: {
selection: selection,
isWebsite: 1
},
success: function(response){
if(response == "error"){

}else{

if($(".deleteThisTalent").length == 0){
$(".itns").append('<p style="font-size: 10px; color: red;" id="notalentselected">SELECT AT LEAST ONE TALENT</p>');
}

}
}
});	
});
//


	








//ADD TALENT
$("body").on("change", "#newTalent", function(){
var selection = $(this).val();
if(selection !== "Talent"){
if($("."+selection).length > 0){
}else{
$.ajax({
url: "https://troupebase.com/formhandlers/updatetalent.php",
method: "POST",
data: {
talent: selection,
isWebsite: 1
},
success: function(response){
if(response == "ALREADY SELECTED"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>TALENT ALREADY ADDED</p>");
showSuccess();
}
if(response == "MAX"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>3 TALENTS MAX</p>");
showSuccess();
}
if(response == "success"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: #214844'>TALENT ADDED</p>");
showSuccess();
var klass = selection.replace(" ", "");
$(".selectedTalents").append("<span class='"+klass+" eachselectedtalent' style='color: white;'>"+selection+"</span> <button class='deleteThisTalent "+klass+"' value = '"+selection+"' style = 'color: red; background-color: white; border: 1px solid grey; border-radius: 2px;'>x</button>");

$("#notalentselected").remove();
	
}
}
});	
}
$("#newTalent").val("Talent");
}
});
//
	





	
//profile settings

	



	








//SOCIAL MEDIA REDIRECT
$("#troupeAndRequestsScroller").on("click", ".smRedirect", function(){
var loc = $(this).attr("value");
window.open(loc);
});
$("body").on("click", ".smRedirect", function(){
var loc = $(this).attr("value");
window.open(loc);
});
//social media redirect
	

//WEBSITE REDIRECT
$("body").on("click", ".websiteRedirect", function(e){
e.preventDefault();
var loc = $(this).attr("href");
window.open(loc);
});
//
	



	
	


	
	

	


/*INBOX*/
	
	


$(".closeMessageToSearch").on("click", function(){
$(".newMessageToSelector").slideUp(50);
});
$(".sendNewCollabTo").on("click", function(){
messageOrCollab = "collab";
$("#newMessageOrCollabHeading").html("NEW COLLAB TO");
$(".newMessageToSelector").slideDown(50);
});
$(".sendNewMessageTo").on("click", function(){
messageOrCollab = "message";
$("#newMessageOrCollabHeading").html("NEW MESSAGE TO");
$(".newMessageToSelector").slideDown(50);
});
$(".clearNewMessageToSearch").on("click", function(){
$(this).slideUp(50);
$(".sendNewMessageToSearch").val('');
});
	

	





	


	






$("body").on("mousedown", "#currentMessageBox", function(){
$("#otherBoxesSlider").slideToggle(200);
});

	
	
	








	
	









	
	
	






	
	

	




	
//UPDATE CONVO FUNCTION
function updateConvo(start){

var currentConvo = $(".conversationContainer").attr("data-currentconvo");
var name = $(".conversationContainer").attr("data-name");
var otherUser = $(".conversationContainer").attr("data-otheruser");
var convoPrivacy = $(".conversationContainer").attr("data-convoprivacy");

	
$.ajax({
url: "https://troupebase.com/updateconvo.php",
method: "POST",
data: {
timeZone: timeZone,
convoID: currentConvo,
otherUser: otherUser,
name: name,
start: start,
isWebsite: 1,
loadConvo: 1
},
success: function(response){
constructConvoUpdate(response);
}
});



}
//update convo function
	
	




	


	




// FUNCTION LOAD CONVO
function loadConvo(subject, convoPrivacy, currentConvo, otherUser, name, troupeID, start, time){
$.ajax({
url: "https://troupebase.com/convo.php",
method: "POST",
data: {
timeZone: timeZone,
convoID: currentConvo,
otherUser: otherUser,
name: name,
start: start,
loadConvo: 1
},
success: function(response){
if(response == "end"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>Message could not be sent, please try again</p>");
showSuccess();
$("#eachActiveMessageDetails"+currentConvo).css("color", "red");
deleteErrorSentMess(currentConvo);
}else{
constructConvo(subject, response, convoPrivacy, currentConvo, otherUser, name, troupeID, start, time);
}
}
});
}
//funtion load convo

	


	




	
	


//TOTAL MESSAGE LOADED
function getTotalConvoLoaded(container){
totalConvoLoaded = container.children.length;
return totalConvoLoaded;
}	


//function construct convo
	


	


	


//

	





$("body").on("click", ".psf", function(){
var file = $(this).attr("data-file");
var filePreview = $(this).attr("data-filepreview");
var fileName = $(this).attr("data-filename");
var ext = $(this).attr("data-ext");
	
loadsp(file, filePreview, fileName, ext);	
	
});

	
//LOAD FILE PREVIEW
var prevaudio = new Audio();
function loadsp(file, filePreview, fileName, ext){
var isvidaud = 0;
$("#profileLoaderContainerSlider").slideDown(50);
$("#profileLoaderContainer").append("<div class='sfpcon'><div class='sfpcontent'><div class='fpheading'><i class='fas fa-backspace closefp backarrows' aria-hidden='true'></i>File Preview</div><div class='fptitle' style='color: #92a09f; font-weight: bold;'></div><div class='fpscroll'><div class='pfaudiocon'><img src='https://troupebase.com/assets/audioIcon.png'><br><span class='fpat'></span><br></div><div class='filepreviewcon'></div><img class='pfp' src='https://troupebase.com/assets/playButton.png'><img src='https://troupebase.com/assets/pauseButton.png' class='pausefp'> <a href='https://troupebase.com/shared/download.php?originalname="+fileName+"&fileToDownload="+file+"'><img src='https://troupebase.com/assets/dl.png' class='dlsharedfile'></a> </div></div></div>");
	
	$(".fptitle").html(fileName);
	
//PHOTO
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){
cfpt = "photo";
$(".filepreviewcon").replaceWith("<img class='fpi' src='"+filePreview+"'><br>");
}
//photo
	
	
//VID
if(ext == "mp4" || ext == "webm" || ext =="ogg" || ext == "mov"){
cfpt = "vid";
if(ext == "mov"){
ext = "mp4";
}	


$(".filepreviewcon").append("<video class='fpVideo' id='fpVideo' playsinline><source class='fpVideoSrc' src='"+filePreview+"' type='video/"+ext+"'>Your browser does not support the video tag.</video>");

video = document.getElementById("fpVideo");
	video.play();

isvidaud = 1;
	$(".pausefp").slideDown(10);
}
//vid
	
	
//AUD
if(ext == "wav" || ext == "mp3" || ext =="m4a"){
cfpt = "aud";
$(".filepreviewcon").slideUp(10);
$(".pfaudiocon").slideDown(10);
$(".fpat").html(fileName);
$(".pausefp").slideDown(10);
prevaudio.src = filePreview;
prevaudio.play();
}
//aud
	
	
	

//OTHER

if(cfpt == "other"){
     $(".filepreviewcon").append("NO PREVIEW AVAILABLE");
	$(".filepreviewcon").css("height", "auto");

}

//other



	
if(isvidaud == 1){
$(".pausefp").slideDown(10);
}
	
	
$(".sfpcon").fadeIn("fast");
}
	

$("body").on("click", ".dlsharedfile", function(){
if(cfpt == "aud" || cfpt == "vid"){
$(".pausefp").trigger("click");
}
});

//load file preview
	

	



//PAUSE PLAY FP	
$("body").on("click", ".pausefp", function(){
if(cfpt == "aud"){
prevaudio.pause();
}
if(cfpt == "vid"){
video.pause();
}
$(this).slideUp(10);
$(".pfp").slideDown(10);
});


$("body").on("click", ".pfp", function(){
if(cfpt == "aud"){
prevaudio.play();
}
if(cfpt == "vid"){
video.play();
}
$(this).slideUp(10);
$(".pausefp").slideDown(10);
});	

//pause play fp


//CLOSE FILE PREVIEW
$("body").on("click", ".closefp", function(){
	closefp();
});
//close file preview

	


function closefp(){
if(cfpt == "vid"){
video.pause();
video = "";
}
if(cfpt == "aud"){
prevaudio.pause();
}

$(".sfpcon").fadeOut("fast");
cfpt = "other";
setTimeout(function(){
$(".sfpcon").remove();
closeDivLoader();
}, 300);
}
	

//function construct convo



	












	
$("body").on("mousedown", "#youreTalkingTo", function(){
$("#conversationOptions").slideToggle();
});
$("#convoScroller").on("mousedown", function(){
$("#conversationOptions").slideUp(100);
});
	
$("body").on("keyup", "#newMessageTextarea", function(e){
var keyCode = e.keyCode;
var message = $(this).val();
if(message !==""){
$("#sendMessage").css("background-color", "#b0c7b0");
}else{
$("#sendMessage").css("background-color", "white");
}
if(keyCode == 13){

}
});
	
$("body").on("click", "#sendMessage",function(){
var currentConvo = $(this).attr("data-currentConvo");
var otherUser = $(this).attr("data-otherUser");
addMessage(currentConvo, otherUser);
});

	


	

	



$("body").on("mousedown", ".submitPermDeleteConvo", function(){
var convoID = $(this).attr("value");
$(".deleteConvoPermContainer").slideUp(100);
$("#confirmPermDeleteConvoContainer"+convoID).slideDown(100);
setTimeout(function(){
$(".deleteConvoPermContainer").slideDown(100);
$(".confirmPermDeleteConvoContainer").slideUp(100);
},3000);
});
	

	


	


//OPEN INBOX
$("body").on("click", ".myInbox", function(){
if(clickDelay == 0){
clickDelay = 1;
loadMessenger();
}
});
//inbox
	

	
//LOAD MESSENGER
function loadMessenger(){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+"' id='MESSENGER' style='width: 100%; background-color: black;'><div class='portfolioHeading' style='color: white;'><i class='fas fa-backspace closebuttonstopleft closeMessenger backarrows'></i>Messenger</div><div class='messengerWrap'><div class='messengerContainer'><div class='messengerScroll' id='messengerScroll'></div><div class='messengerIcons'><div class='messengerIconsImg'><img src='../assets/activeconvos.png' class='hoverimage'><img src='../assets/composetwo.png' class='hoverimage newMessageToSearch'></div></div></div></div></div>");
	
	
	
	
	
//GET CHATS
let start = 0;
getActiveChats(start).then(function(r){
if(r == "end"){
return;
}
		console.log(r);
var data = JSON.parse(r);
for(var i = 0; i < data.length; i++){
var thisChat = data[i]; 
var container = document.getElementById("messengerScroll");
constructEachActiveChat(container, thisChat);
}	
	
	
});	
	
	
clickDelay = 0;
}
	
	

	



//CONSTRUCT EACH ACTIVE CHAT
function constructEachActiveChat(container, thisChat){

	
	var profilePic = thisChat.user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}	
	
	
$(container).append("<div class='eachActiveChatDiv' id='eachActiveChatDiv"+thisChat.id+"'></div>")	

$("#eachActiveChatDiv"+thisChat.id).append("<div class='inFlexAutoHigh'><div class='profilePicLeft'><img class='hoverimage loadChat' src='"+profilePic+"' id='loadChat"+thisChat.id+"'></div><div class='eachActiveChatDetails textAlignInitial'><span style='font-weight: bold;'>"+thisChat.user.name+"</span><br>Last: "+thisChat.last+"<br><span style='font-size: 11px;'>"+thisChat.dateTime+"</span></div></div>");

//LOAD CHAT
$("#loadChat"+thisChat.id).on("click", function(){
var id = thisChat.id;
loadConversation(id);
});
	
}




	



//GET ACTIVE CHats
function getActiveChats(start){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/activechats.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});

});
}




$("body").on("click", ".closeMessenger", function(){
if(clickDelay == 0){
clickDelay = 1;
$("#MESSENGER").fadeOut("fast");
setTimeout(function(){
$("#MESSENGER").remove();
clickDelay = 0;
}, 1000);
}
});






	

//NEW MESSAGE TO SEARCH (SEARCH FORM);
$("body").on("click", ".newMessageToSearch", function(){
newMessageToSearch();
});
function newMessageToSearch(){
var time = Date.now();
$("#profileLoaderContainerSlider").slideDown(50);
$("#profileLoaderContainer").append("<div class='wwCon'><div class='portfolioHeading' style='height: 60px; position: initial'><p style='color: white; margin:0px;'>Start New Convo With</p><input type='text' class='searchUserToChatWith' id='searchUserToChatWith"+time+"' placeholder='Search'><button class='cwwt'>x</button></div><div class='newConvoUserSearch' id='newConvoUserSearch"+time+"' data-start='0'></div></div>");
	
	var container = document.getElementById("newConvoUserSearch"+time);
	var klass = 'startNewConvoWithUser';
	
	//KEYUP
	$("#searchUserToChatWith"+time).on("keyup", function(){
	$("#newConvoUserSearch"+time).attr("data-start", 0);
	var user = $(this).val();
	var start = $("#newConvoUserSearch"+time).attr("data-start");
	getUserSearch(user, start).then(function(r){
	if(r == "end"){
	return;
	}
		
		$(container).empty();
		var data = JSON.parse(r);
	
		for(var i = 0; i < data.length; i++){
	
		var user = data[i];

		constructUserSearch(container, klass, user);
	
		}
		
		var newStart = parseInt(start) + 10;
		$("#newConvoUserSearch"+time).attr("data-start", newStart);	
		
		
	});
	});
	
	
	
	//SCROLL
	$("#newConvoUserSearch"+time).on("scroll", function(){
	var user = $("#searchUserToChatWith"+time).val();
	var start = $(this).attr("data-start");
	var elmnt = this;
	var y = elmnt.scrollHeight;
	var t = elmnt.scrollTop;
	var c = elmnt.clientHeight;
	clearTimeout(scrollTime);
	scrollTime = setTimeout(function(){
	if(y - t <= c+200){

		getUserSearch(user, start).then(function(r){
			if(r == "end"){
			return;
			}
		

		var data = JSON.parse(r);
	
		for(var i = 0; i < data.length; i++){
	
		var user = data[i];

		constructUserSearch(container, klass, user);
	
		}
		
		var newStart = parseInt(start) + 10;
		$("#newConvoUserSearch"+time).attr("data-start", newStart);	
		
		
	});

	}
	}, 150);	
	
	
	});
	
	
}


//NEW CHAT FORM
function newChatForm(id, name, profilePic){
if(id == userLoggedIn){
clickDelay = 0;
return;
}
	
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+"' id='newChatContWrap' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closeTroupesCon"+time+"'></i></div><div class='newChatWrap'><div class='newChatFormContainer'><img id='newchatform-profilepic' src='"+profilePic+"'><br>New message to <span style='font-weight: bold;' id='newchatform-name'>"+name+"</span><br><textarea id = 'myNewMessage' placeholder='Message'></textarea><br><button id='submitStartNewChat"+time+"'>SEND</button><button id='confirmStartNewChat"+time+"' style='display: none; font-weight: bold;'>COMFIRM!</button></div></div></div>");
	
	
	
	//CONFIRM
	$("#confirmStartNewChat"+time).on("click", function(){
	$(this).slideUp(10);
	$("#submitStartNewChat"+time).slideDown(10);
	loadLayOver();
	var message = $("#myNewMessage").val();
	if(message == ""){
	showAlert("Type a message", "red");
	removeLayOver();
	}else{
		$("#submitStartNewChat"+time).text("Please Wait..");
		sendNewMessage(id, message).then(function(r){
	
		removeLayOver();
			//SUCCESS
			if(r == "success"){
			$(".universalcontainer"+time).fadeOut("fast");
			showAlert("Message Sent", "green");
			return;
			}
			
			
			
			//IF IS ALREADY CHATTTING AND NONE OF THE ABOVE
			var elem = document.getElementById("newChatContWrap");
			$(elem).fadeOut(10);
			$(".cwwt").trigger("click");
			loadConversation(r);
			
			
			
		
		});
	}
	});
	
	
	
	
	
	//SUBMIT
	$("#submitStartNewChat"+time).on("click", function(){
	$(this).css("display", "none");
	$("#confirmStartNewChat"+time).slideDown(10);
	setTimeout(function(){
	$("#confirmStartNewChat"+time).css("display", "none");
	$("#submitStartNewChat"+time).slideDown(10);
	}, 2500);
	});
	
	
//CANCEL
$("#closeTroupesCon"+time).on("click", function(){
close(time);
});
	clickDelay = 0;
}

	

	



//LOAD CHAT CONTROL AND  CONVERSATION

function loadConversation(id){
var time = Date.now();
var chatWithName = "";
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+"' id='currentChatWrap' style='width: 0%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closechat'></i><img id='currentChatProfilePic' src=''></div><div id='conversationScrollAndTextArea'><div class='convoScroller' id='convoScroller"+time+"' data-start><div class='startChattingMessage' id='startChattingMessage'><div>Start Chatting</div></div></div><div class='convoMessageBoxAndIcons'><div class='convoIcon'><img class='hoverimage messenger-attach"+time+"' id='messenger-attach' src='../assets/attachicontwo.png'></div><div class='messageBox'><textarea class='myNewChatMessage' id='myNewChatMessage"+time+"' placeholder='TYPE MESSAGE'></textarea><button class='sendMessageButton' id='sendMessageButton"+time+"'>SEND</button></div></div></div></div>");
var container = document.getElementById("convoScroller"+time);
	
	
	
//ATTACH
$(".messenger-attach"+time).on("click", function(){

	loadAttachScreen(id);
	
});
	

	
	

//IF ENTER PRESSED
$("#myNewChatMessage"+time).on("keyup", function(e){
var key = e.keyCode;
if(key == 13){
$("#sendMessageButton"+time).trigger("click");
}
});
	
	
//SEND MESSAGE
$("#sendMessageButton"+time).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var message = $("#myNewChatMessage"+time).val();
if(message == ""){
clickDelay = 0
}else{


sendChatMessage(id, message).then(function(r){
clickDelay = 0;
if(r == "error"){
return;
}
if(r !== "error"){

$("#myNewChatMessage"+time).val("");
$("#sendMessageButton"+time).css("opacity", .3);	
$(".startChattingMessage").slideUp(10);

var message = JSON.parse(r)
 message = message[0];

var display = "none";
var older = 0;
constructEachMessage(container, chatWithName, message, display, older);

	
}else{
showAlert("Error Occured", "red");
}
});	
	

}
}
})
	



	
	
	
//KEYUP
$("#myNewChatMessage"+time).on("keyup", function(){
var message = $(this).val();
if(message == ""){
$("#sendMessageButton"+time).css("opacity", .3);
}else{
$("#sendMessageButton"+time).css("opacity", 1);
}
});	
	
	
if($("#myNewMessage").length > 0){
var message = $("#myNewMessage").val();
$("#myNewChatMessage"+time).val(message);
$("#sendMessageButton"+time).css("opacity", 1);
var profilePic = $("#newchatform-profilepic").attr("src");
var chatWithName = $("#newchatform-name").text();
$("#currentChatProfilePic").attr("src", profilePic);
$("#newChatContWrap").remove();
}

var img = document.getElementById('messenger-attach');
img.style.transform = 'rotate(45deg)';	
var elem = document.getElementById("currentChatWrap");
animateWidthToHund(elem);



//GET CHAT
var start = 0;
getChat(start, id).then(function(r){
if(r == "end"){
return;
}
var elem = document.getElementById('startChattingMessage');
fadeElementOutAndRemove(elem);
	
var dataBefore = JSON.parse(r);
var data = dataBefore.reverse();

for(var i = 0; i < data.length; i++){
	var message = data[i];
	var display = "";
	var older = 0;
	constructEachMessage(container, chatWithName, message, display, older);
}
	
//SCROLL
setTimeout(function(){
$("#convoScroller"+time).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(t < 10){

var start = getTotalConvoLoaded(container);
getOlderMessages(start, id).then(function(r){
if(r == "end"){
return;
}
var data = JSON.parse(r);

for(var i = 0; i < data.length; i++){
	var message = data[i];
	var display = "none";
	var older = 1;
	constructEachMessage(container, chatWithName, message, display, older);
}


});

	
}
}, 150);	
});
}, 2000);

});

	
	

//GET LATEST MESSAGES
convoRefreshTimer = setInterval(function(){
getLatestMessages(id, lastMessageDate).then(function(r){
if(r == "end"){
return;
}
var dataBefore = JSON.parse(r);
var data = dataBefore.reverse();

for(var i = 0; i < data.length; i++){
	var message = data[i];
	var display = "none";
	var older = 0;
	constructEachMessage(container, chatWithName, message, display, older);
}
});
}, 3000);


	



$("#newChatContWrap").remove();

}
	

	




	

//GET OLDER MESSAGES
function getOlderMessages(start, id){

 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/getoldermessages.php",
method: "POST",
data: {
id: id,
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});

});
}

	

	






	
//PAUSE ALL AUDIO TAGS
function pauseAllAudioTags(){
var audios = document.getElementsByTagName('audio');
for(var i = 0, len = audios.length; i < len;i++){

            audios[i].pause();


}
}




//ATTACH PHOTO
function attach(chatID, input, type){
pauseAllAudioTags();

if(type == "audio"){
var audio = input.files[0];
}
if(type == "photo"){
var photo = input.files[0];
}
if(type == "video"){
var video = input.files[0];
}
var formdata = new FormData();
formdata.append("chatID", chatID);
if(type == "audio"){
formdata.append("audio", audio);
}
if(type == "photo"){
formdata.append("photo", photo);
}
if(type == "video"){
formdata.append("video", video);
}
formdata.append("isWebsite", 1);
var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", requestProgress, false);	
ajax.addEventListener("load", attachAjaxResponse, false);
if(type == "audio"){
ajax.open("POST", "../formhandlers/attachaudio.php");
}
if(type == "photo"){
ajax.open("POST", "../formhandlers/attachphoto.php");
}
if(type == "video"){
ajax.open("POST", "../formhandlers/attachvideo.php");
}
ajax.send(formdata);	
	
	
}
	
	

//ATTACHMENT SEND RESPONSE
function attachAjaxResponse(e){
clickDelay = 0;
console.log(e.target.responseText);
var element = document.getElementById("attachmentControl");
fadeElementOutAndRemove(element);
removeLayOver();
removeProgressBar();
if(e.target.responseText == "error"){
showAlert("Could not send attachment", "red");
return;
}
	
	
var message = JSON.parse(e.target.responseText)
message = message[0];

var display = "none";
var older = 0;
var container = document.getElementsByClassName("convoScroller");
constructEachMessage(container, "null", message, display, older);
	

}
	



	





//ATTACH
function loadAttachScreen(id){
	
var fileToAttachExt;	
var fileToAttach;
var type;
	
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough' style='width: 100%;' id='attachmentControl'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' data-time='"+time+"'></i>Attachment<div class='topTopConIcons'></div></div><div class='fourpixcenterscroll'><input type='file' id='fileToAttach"+time+"' name='fileToAttach' style='display:none;'><button id='attachFileTrigger"+time+"'>SELECT<br>FILE</button><div id='attachPrevHere'></div><div id='attachmentComment'><textarea id='attachmentCaption' placeholder='Comment'></textarea></div><div class='attachmentButtons'><button style='display: none;' id='confirmSendAttached"+time+"'>CONFIRM!</button><button id='sendAttached"+time+"'>Send</button><br><br><button style='background-color: transparent; color: red; border: none;' id='cancelattach"+time+"'>Nevermind</button><br><br><br></div></div></div>");
	
var input = document.getElementById("fileToAttach"+time);
	
//CONFIRM
$("#confirmSendAttached"+time).on("click", function(){
if(clickDelay == 0){
loadLayOver();
loadProgressBar();

attach(id, input, type);


}
});
	
	
//SUBMIT SEND
$("#sendAttached"+time).on("click", function(){
$(this).css("display", "none");
$("#confirmSendAttached"+time).slideDown(10);
setTimeout(function(){
$("#confirmSendAttached"+time).css("display", "none");
$("#sendAttached"+time).slideDown(10);
}, 3000);
});
	
	
	
//CANCEL
$("#cancelattach"+time).on("click", function(){
close(time);
});
	
	
//SELECT
$("#attachFileTrigger"+time).on("click", function(){
$("#fileToAttach"+time).trigger("click");
});
	
	
	
	
	
//CHANGE
$("#fileToAttach"+time).on("change", function(){
$("#attachPrevHere").empty();
$("#attachFileTrigger"+time).text("Change File");

var file = $(this).val();
var ext = file.split('.').pop();
ext = ext.toLowerCase();
var size = document.getElementById('fileToAttach'+time).files[0].size;
	
	
//CHECK SIZE
if(size > 26214400){
showAlert("File Exceeds 25MB", "red");
return;
}
	
	
//CHECK EXCEPTED
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif" || ext == "wav" || ext == "mp3" || ext =="m4a" || ext == "mp4" || ext == "webm" || ext =="ogg" || ext == "mov"){
}else{
showAlert("Unaccepted File Format", "red");
return;
}
	
	
	
//PHOTO
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){
type = "photo";
}
//AUDIO
if(ext == "wav" || ext == "mp3" || ext =="m4a"){
type = "audio";
}
//VIDEO
if(ext == "mp4" || ext == "webm" || ext =="ogg" || ext == "mov"){
type = "video";
}
	

fileToAttachExt = ext;
var fileToAttach = document.getElementById("fileToAttach"+time);
fileToAttach = URL.createObjectURL(fileToAttach.files[0]);

//PHOTO
if(type == "photo"){
$("#attachPrevHere").append("<img src='"+fileToAttach+"'>");
}
	

//VIDEO
if(type == "video"){
if(ext == "mov"){
ext = "mp4";
}
	
	
$("#attachPrevHere").append("<video class='selvidplayer' id='video"+time+"' playsinline controls><source src='"+fileToAttach+"' type='video/"+ext+"'>Your browser does not support the video tag.</video>");
	
	
}	
	

//Audio
if(type == "audio"){

	
$("#attachPrevHere").append("<audio controls><source src='"+fileToAttach+"' type='audio/"+ext+"'></audio>");
	
	
}	
	




$("#attachmentComment").slideDown(100);
$(".attachmentButtons").slideDown(100);
	


	
});

	
}


	

	







	

//GET LATEST MESSAGES FUNCTION
function getLatestMessages(id, lastMessageDate){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/getlatestmessages.php",
method: "POST",
data: {
id: id,
lastMessageDate: lastMessageDate,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});

});
}

	
	

//CONSTRUCT EACH MESSAGE
function constructEachMessage(container, chatWithName, message, display, older){

var id = message.id;
var file = message.file;
var filePreview = message.filePreview;
if($("#eachMessage"+id).length == 0){
if(message.userFrom == userLoggedIn){
var name = "You";
}else{
var name = chatWithName;
}
	
	if(message.isOlder == 1){
$(container).prepend("<div class='eachMessage' id='eachMessage"+id+"' style='display: "+display+"'></div>");	
	}else{
$(container).append("<div class='eachMessage' id='eachMessage"+id+"' style='display: "+display+"'></div>");	
	}
	

$("#eachMessage"+id).append("<div class='eachMessageBody'><span class='eachMessageName' id='eachMessageName"+id+"'>"+name+"</span><br><span class='bold' id='eachMessageBody"+id+"'>"+message.body+"</span><br><div class='eachMessageAttachment' id='eachMessageAttachment"+id+"'></div><span class='eachMessageDate'>"+message.dateTime+"</span></div>");
	
	
	
//ATTACHMENTS
if(message.type == "photo" || message.type == "video"){
$("#eachMessageAttachment"+id).append("<img class='hoverimage' id='showAttachment"+id+"' src='"+filePreview+"'>")
}
if(message.type == "audio"){
$("#eachMessageAttachment"+id).append("<audio src='"+file+"' controls controlsList='nodownload'></audio>")
}
	
	
//SHOW ATTACHMENT
$("#showAttachment"+id).on("click", function(){
let url = message.file;
let type = message.type;
loadAttachment(type, url);
});
	
	
	
if(message.unix !== "" && message.unix !== undefined){
lastMessageDate = message.unix;
}

	
//MOVE MESSAGE LEFT
if(message.userFrom == userLoggedIn){
}else{
$("#eachMessage"+id).css("margin-left", "2%");
$("#eachMessage"+id).css("background-color", "#dae8da");
$("#eachMessage"+id).css("color", "black");
}

	$("#eachMessage"+id).fadeIn(1500);
	if(message.isOlder == 0){
	container.scrollTop = container.scrollHeight;
	}
	

	
	}
	
}




//SHOW ATTACHMENT
function loadAttachment(type, url){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer' id='cancelProjectResponseCont' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closeAttachment"+time+"'></i></div><div class='postScroller attachmentScroll' id='attachmentScroll"+time+"'><br></div></div>");
	
	
var ext = url.split('.').pop();
if(ext == "mov"){
ext = "mp4";
}	
	
if(type=="photo"){
var elem = "<img src='"+url+"'>";
}	
if(type=="video"){
var elem = "<video id='postVideoContainer"+time+"' class='postVideoContainer postVideoContainer"+time+"' playsinline controls><source class='postVideoContainerSrc"+time+"' type='video/"+ext+"' src='"+url+"'/></video>";
}	
	
$("#attachmentScroll"+time).append(elem);
	

	
	
	
	
	
	
	//CLOSE
	$("#closeAttachment"+time).on("click", function(){
	close(time);
	});
	
}

	
//SEND CHAT MESSAGE
function sendChatMessage(id, message){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/sendchatmessage.php",
method: "POST",
data: {
id: id,
message: message,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});

});
}
	



//GET CHAT
function getChat(start, id){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/getchat.php",
method: "POST",
data: {
id: id,
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});

});
}




//CLOSE CURRENT CHAT
$("body").on("click", "#closechat", function(){
var element = document.getElementById("currentChatWrap");
fadeElementOutAndRemove(element);
clearInterval(convoRefreshTimer);
});
/*inbox*/
	
	

//ANIMATIONS
//ANIMATE WIDTH TO 100
function animateWidthToHund(elem){
$(elem).stop().animate({width: "100%"}, "fast", "linear");
}
//FADEOUT AND REMOVE
function fadeElementOutAndRemove(elem){
$(elem).fadeOut(100);
setTimeout(function(){
$(elem).remove();
}, 150);
}

//USER SEARCH
function constructUserSearch(container, klass, user){
var counter = Math.random();
counter = counter.toString();
counter = counter.replace(".", "");
	
	var talents = getTalentText(user.talentString);
	var profilePic = user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	$(container).append("<div class='generalUserContainer'><div class='generalUserConProfilePic'><img src='"+profilePic+"' class='hoverimage "+klass+"' id='startNewConvoWithUser"+counter+"'></div><div class='generalUserConInfo'><p style='font-weight: bold;'>"+user.name+"</p><p>"+talents+", "+user.state+"</p></div></div>");
	
//START NEW CONVO	
$("#startNewConvoWithUser"+counter).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var id = user.id;
var name = user.name;
var profilePic = user.profilePic;
newChatForm(id, name, profilePic);
}
});
	
}

	




function getUserSearch(user, start){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/usersearch.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});

});
}



//NOTIFICATION ICONS
$(document).on("click", ".notificationIcons", function(){
var loc = $(this).attr("value");
if(loc == "messages" || loc == "projectGoals" || loc == "sendMessage" || loc == "collabRequests" || loc == "Notifications"){

if(loc == "sendMessage"){
newMessageTo = $(this).attr("data-id");
var name = $(this).attr("data-name");
$(".sendingNewMessageToPic").empty();
$("#sendingMessageToName").html(name);
$("#sendMessageslider").slideDown(50);
}	
	

	
	
if(loc == "collabRequests"){
$("#projectGoalSlider").slideUp(100);
$("#troupeRequestsSlider").slideUp(100);
$("#inboxSlider").slideUp(100);
$("#collabRequestsSlider").slideDown(100);
}		
	
	
if(loc == "Notifications"){
loadNotifications();
}		
	
	

}else{
window.location = loc;
}
});
	

	

$("#openInbox").on("mousedown", function(){
$("#projectGoalSlider").slideUp(100);
$("#troupeRequestsSlider").slideUp(100);
$("#collabRequestsSlider").slideUp(100);
$("#inboxSlider").slideDown(100);
$("#inboxSlider").fadeTo("slow", 1);
});
	
$("body").on("click", "#youHaveNewMessage", function(){
$("#inboxSlider").fadeTo("slow", 1);
boxToLoad = "INBOX";
messagesStart: 15;
messagesLimit: 15;
$("#switchInboxInbox").trigger("mousedown");
});
//notification icons




	
	










//TROUPE REQUEST
	



	
	
	



	




//VIEW TROUPE OPTIONS
$("body").on("touchstart mouseover", ".viewTroupeOptions", function(){
$(this).slideUp(50);
var id = $(this).attr("value");
$("#troupeOptionsSlider"+id).animate({"left":"65%"}, "slow");
setTimeout(function(){
$("#troupeOptionsSlider"+id).animate({"left":"110%"}, "slow");
$("#viewTroupeOptions"+id).slideDown(1000);
}, 3000);
});
//

	
//troupe request






	







//TROUPE REQUESTS SLIDER
	

	



	
//search my troupes
	

$("#clearMyTroupeSearch").on("click", function(){
$("#showMyTroupes").trigger("click");
});


$("#myTroupeToSearch").on("keyup", function(){
$("#clearMyTroupeSearch").slideDown(300);
troupeSliderStart = 7;
troupeSliderLimit = 7;
troupeToSearch = $(this).val();
$.ajax({
url: "https://troupebase.com/searchtroupes.php",
method: "POST",
data: {
troupeSliderStart: 0,
troupeSliderLimit: 7,
troupeToSearch: troupeToSearch,
loadMyTroupes: 1
},
success: function(response){
constructTroupeSearch(response);
}
});	
});
//



	








//toggle search
$(".toggleMyTroupeSearch").on("mousedown", function(){
troupeSliderShowing = "search";
$("#troupeOrTroupeRequestHeading").html("SEARCH");
$(this).slideToggle(200);
$("#searchMyTroupesContainer").slideToggle(300);
});
//


	








$(".closeTroupeSlider").on("click", function(){
if($(".mtts").is(":visible")){
$(".cancelmts").trigger("mousedown");
return;
}
$(myTroupesScroller).fadeOut();
$("#troupeOrTroupeRequestHeading").html("TROUPE REQUESTS");
$(myTroupesScroller).empty();
$("#troupeRequestsSlider").fadeOut();
});

	
	




//TROUPES ICON HOMEBASE
	
$("body").on("click", "#troupesIcon", function(e){//
if(clickDelay == 0){
clickDelay = 1;
var user = $(this).attr("data-user");
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer' id='cancelProjectResponseCont' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closeTroupesCon"+time+"'></i>Troupes<div class='topTopConIcons'><img src='https://troupebase.com/assets/troupesicon.png' id='vtr"+time+"'><img src='https://troupebase.com/assets/outgoing.png' id='vstr"+time+"'></div></div><div class='postScroller' id='troupesScroller"+time+"' data-start = '0'></div></div>");
	
	if(user == userLoggedIn){
	}else{
	$("#vtr"+time).remove();
	$("#vstr"+time).remove();
	}

//LOAD SENT REQUESTS
$("#vstr"+time).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;

loadSentTroupeRequests();
	
}
});	
	
	
	
//SHOW TROUPE REQUESTS
$("#vtr"+time).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
loadTroupeRequests();
}
});	
	
	
	
//SCROLL
$("#troupesScroller"+time).on("scroll", function(){
var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+100){
console.log(time);
getTroupes(time, user, start);
	
}
}, 150);	
	
	

});
	
	
	
$("#closeTroupesCon"+time).on("click", function(){
close(time);
});	
	

getTroupes(time, user, 0);
}
});

	

	


//LOAD TROUPE REQUESTS
function loadTroupeRequests(){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer' id='cancelProjectResponseCont' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closeTroupesCon"+time+"'></i>Troupe Requests Received<div class='topTopConIcons'></div></div><div class='postScroller' id='troupeReqScroll"+time+"' data-start = '0'></div></div>");
	
var start = $("#troupeReqScroll"+time).attr("data-start");
getTroupeRequest(start, time);
	
	
$("#closeTroupesCon"+time).on("click", function(){
close(time);
});	
	
	clickDelay = 0;
}

	


	





//FUNCTION LOAD SEND TROUPE REQUESTS
function loadSentTroupeRequests(){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer' id='cancelProjectResponseCont' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closeTroupesCon"+time+"'></i>Troupe Requests Sent<div class='topTopConIcons'></div></div><div class='postScroller' id='sentTroupeReqScroll"+time+"' data-start = '0'></div></div>");	
	
	
	var start = $("#sentTroupeReqScroll"+time).attr("data-start");
	getSentTroupeRequests(time, start);
	
	
	//SCROLL
$("#sentTroupeReqScroll"+time).on("scroll", function(){
var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+100){
getSentTroupeRequests(time, start);
}
}, 150);	
});
	
	
	
	$("#closeTroupesCon"+time).on("click", function(){
	close(time);
	});
	
	clickDelay = 0;
}
	

	
	




//FUNCTION GET SENT TROUPE REQ
function getSentTroupeRequests(time, start){
$.ajax({
url: "https://troupebase.com/formhandlers/senttrouperequests.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){
constructSentTroupeRequests(response, start, time);
}
});	
}
	

function constructSentTroupeRequests(response, start, time){
if(response == "error" || response == "end"){
return;
}
var newStart = parseInt(start) + 10;
$("#sentTroupeReqScroll"+time).attr("data-start", newStart);	
var data = JSON.parse(response);
	
for(var i = 0; i < data.length; i++){
	
var troupe = data[i];
var user = troupe.user;
var talentString = 	troupe.talentString;
	

	var profilePic = user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
$("#sentTroupeReqScroll"+time).append("<div class='generalUserContainer'><div class='generalUserConProfilePic'><img class='viewProfile' data-id='"+user.id+"' src='"+profilePic+"'></div><div class='generalUserConInfo generalUserConInfo"+user.id+"' id='generalUserConInfo"+user.id+"'><p style='font-weight: bold;'>"+user.name+"</p><p>"+talentString+", "+user.state+"</p><button id='cancelTRButton"+user.id+"' class='troupeButtons"+user.id+" trButtons"+user.id+"' data-user='"+user.id+"' style='color: red; font-size: 15px;'>Cancel</button></div></div>");	
	

	
$("#cancelTRButton"+user.id).on("click", function(){
var user = $(this).attr("data-user");
cancelTroupeRequest(user).then(function(response){
clickDelay = 0;
if(response == "success"){
$(".trButtons"+user).remove();
$(".generalUserConInfo"+user).append("<p style='color: red'>Troupe Request Canceled</p>");
}
	
}).catch(function(response){
});	
});
	
}	
}




	

	
//FUNCTION LOAD TROUPE REQUESTS
function getTroupeRequest(start, time){
$.ajax({
url: "https://troupebase.com/formhandlers/trouperequests.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){
constructTroupeRequests(response, start, time);
}
});	
}
		
	
	
	





//CONSTRUCT TROUPE REQUESTS
function constructTroupeRequests(response, start, time){
if(response == "error" || response == "end"){
return;
}
var newStart = parseInt(start) + 10;
$("#troupeReqScroll"+time).attr("data-start", newStart);	
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
	
var troupe = data[i];

var user = troupe.user;
var talentString = 	troupe.talentString;

	var profilePic = user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
$("#troupeReqScroll"+time).append("<div class='generalUserContainer'><div class='generalUserConProfilePic'><img class='viewProfile' data-id='"+user.id+"' src='"+profilePic+"'></div><div class='generalUserConInfo generalUserConInfo"+user.id+"' id='generalUserConInfo"+user.id+"'><p style='font-weight: bold;'>"+user.name+"</p><p>"+talentString+", "+user.state+"</p><button id='declineTR"+user.id+"' class='troupeButtons"+user.id+" trButtons"+user.id+"' data-user='"+user.id+"' style='color: red; font-size: 15px;'>Decline</button><button id='acceptTR"+user.id+"' class='troupeButtons"+user.id+" trButtons"+user.id+"' data-user='"+user.id+"' style='color: red; font-size: 15px; color: green;'>Accept</button></div></div>");	

	
		$("#acceptTR"+user.id).on("click", function(){
			alert("now");
	var user = $(this).attr("data-user");
	acceptTroupeRequest(user).then(function(acceptResponse){
	
		if(acceptResponse == "success"){
			$(".generalUserConInfo"+user).append("<p style='color: green'>Troupe Request Accepted</p>");
		$(".trButtons"+user).remove();
		}
		
	}).catch(function(response){
	});
	});
	
	
	$("#declineTR"+user.id).on("click", function(){
	var user = $(this).attr("data-user");
	denyTroupeRequest(user).then(function(declineResponse){
	
		if(declineResponse == "success"){
		$(".generalUserConInfo"+user).append("<p style='color: red'>Troupe Request Declined</p>");
		$(".trButtons"+user).remove();
		}
		
	}).catch(function(response){
	});
	});
	
	
	
	
}
}




















	
//FUNCTION GET TROUPES
function getTroupes(time, user, start){
$.ajax({
url: "https://troupebase.com/formhandlers/gettroupes.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
constructTroupes(time, start, response);
}
});	
}

	

	
//CONSTRUCT TROUPES
function constructTroupes(time, start, response){

if(response == "error" || response == "end"){
return;
}
var newStart = parseInt(start) + 10;
$("#troupesScroller"+time).attr("data-start", newStart);	
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var troupe = data[i];

var user = troupe.user;
var talentString = 	getTalentText(user.talentString);


	var profilePic = user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
	
	
$("#troupesScroller"+time).append("<div class='generalUserContainer'><div class='generalUserConProfilePic'><img class='viewProfile' data-id='"+user.id+"' src='"+profilePic+"'></div><div class='generalUserConInfo' id='generalUserConInfo"+user.id+"'><img src='../assets/expanddown.png' class='showTroupeButtonsImg' id='showTroupeButtonsImg"+user.id+"' data-user='"+user.id+"'><p style='font-weight: bold;'>"+user.name+"</p><p>"+talentString+", "+user.state+"</p><button id='deleteTroupe"+user.id+"' class='troupeButtons troupeButtons"+user.id+" deleteTroupe' data-user='"+user.id+"' style='color: red; font-size: 11px;'>Remove</button></div></div>");
	
if(troupe.uli !== troupe.forUser){
$("#showTroupeButtonsImg"+user.id).remove();
}	
	
	
	
//REMOVE TROUPE
$("#deleteTroupe"+user.id).on("click", function(){
var user = $(this).attr("data-user");
deleteTroupe(user).then(function(response){
if(response == "success"){
$(".troupeButtons"+user).remove();
$("#generalUserConInfo"+user).append("<p style='color: red'>User removed from your Troupes</p>")
}else{

}
	
}).catch(function(response){
});
	
	
});
	
	
$("#showTroupeButtonsImg"+user.id).on("click", function(){
$(this).css("display", "none");
var user = $(this).attr("data-user");
$(".troupeButtons").slideUp(100);
$(".troupeButtons"+user).slideDown(100);
$(".troupeButtons"+user).slideDown(100);
});

	
	
}
	
}

	











	
































$("#showTroupeRequests").on("click", function(){
$(this).slideUp();
$("#showMyTroupes").slideDown("click");
$(myTroupesScroller).empty();
$(myTroupesScroller).fadeOut();
$(troupeAndRequestsScroller).fadeIn();
$("#troupeOrTroupeRequestHeading").html("TROUPE REQUESTS");
});	


	

	




	

//SHOW MY TROUPES
$("#showMyTroupes").on("mousedown", function(){
myTroupesStart = 0;
$(this).slideUp();
$("#showTroupeRequests").slideDown("fast");
$(".mtsbx").slideDown("fast");
$("#troupeAndRequestsScroller").fadeOut("fast");
$("#myTroupesScroller").fadeIn("fast");
$("#troupeOrTroupeRequestHeading").html("MY TROUPES");
	loadMyTroupes(myTroupesStart);
});
	




	

$("body").on("mousedown", ".cancelmts",function(){
resetMTS();
});

	
	


//SEARCH MY TROUPES
$("body").on("keyup", ".mtts", function(){
myTroupesStart = 0;
$(".mytsscroll").empty();
var user = $(this).val();
loadmts(myTroupesStart, user);
});


function loadmts(start, user){
$.ajax({
url: "https://troupebase.com/mts.php",
method: "POST",
data: {
start: start,
user: user,
mts: 1
},
success: function(response){
constructMTS(response, start);
}
});	
}
	

function resetMTS(){
$(".mtsinput").slideUp(10);
$(".showmts").slideDown(500);
$("#myTroupesScroller").slideDown(10);
$(".mytsscroll").slideUp(10);
$(".mtts").val("");
$("#troupeOrTroupeRequestHeading").html("TROUPE REQUESTS");
isSearchMT = 0;
myTroupesStart = 0;
loadMyTroupes(myTroupesStart);
}
//show my troupes


	
	
	

//FUNCTION LOAD MY TROUPES	
function loadMyTroupes(start){

$.ajax({
url: "https://troupebase.com/myTroupes.php",
method: "POST",
data: {
start: start,
troupeToSearch: troupeToSearch,
loadMyTroupes: 1
},
success: function(response){
constructMyTroupes(response);
}
});	

}
//function load my troupes




	
//FUNCTION CONSTRUCT MY TROUPE
	

function constructMTS(response, start){
if(response == "end"){
return;
}
	
myTroupesStart = myTroupesStart+7;	

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
	
var myTroupe = data[i];
	
if($(".eMTS"+myTroupe.troupeID).length === 0){

	
$(".whatevers").append("<div class='eachProjectGoal eMTS"+myTroupe.troupeID+"' style='background-color: transparent;'><div class='projectGoalContent myTroupeContent"+myTroupe.troupeID+"' style='color: white;'><img class='viewProfile filter"+myTroupe.photoFilter+"' data-id='"+myTroupe.troupeID+"' style='margin-top: 5px; background-color: transparent; border: none;' src='"+myTroupe.profilePic+"'><p>"+myTroupe.name+", "+myTroupe.state+"</p><p>"+myTroupe.talent+"</p><p style='margin-top: 10px;'>"+myTroupe.about+"</p><div style='margin-bottom: 5px;' class='projectGoalIcons mytsiIcons"+myTroupe.troupeID+"'></div></div></div>");
	
	
if(myTroupe.isTroupes === 1){
$(".mytsiIcons"+myTroupe.troupeID).append("<button class='untroupe' value='"+myTroupe.troupeID+"'>UNTROUPE</button><button class='block' value='"+myTroupe.troupeID+"'>BLOCK</button>");
}
	
	
}
}
}
	


	


function constructMyTroupes(response, isSearch){

if(response == "end"){
return;
}

	
myTroupesStart = myTroupesStart+7;
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
	
var myTroupe = data[i];
	
if($(".myTroupe"+myTroupe.troupeID).length === 0){
	
$(myTroupesScroller).append("<div class='eachProjectGoal myTroupe"+myTroupe.troupeID+"' style='background-color: transparent;'><div class='projectGoalContent myTroupeContent"+myTroupe.troupeID+"' style='color: white'><img class='viewProfile filter"+myTroupe.photoFilter+"' data-id='"+myTroupe.troupeID+"' style='margin-top: 5px; background-color: transparent; border: none;' src='"+myTroupe.profilePic+"'><p>"+myTroupe.name+", "+myTroupe.state+"</p><p>"+myTroupe.talent+"</p><p style='margin-top: 10px;'>"+myTroupe.about+"</p><div style='margin-bottom: 5px;' class='projectGoalIcons myTroupesIcon"+myTroupe.troupeID+"'><button class='untroupe' value='"+myTroupe.troupeID+"'>UNTROUPE</button><button class='block' value='"+myTroupe.troupeID+"'>BLOCK</button></div></div></div>");

	
	
	
	
}
	
}
}
//function construct my troupe

	
	
//SCROLL TOGGLES

//
	













$(".userLoggedInDash").on("click", function(){
$(".closeTroupeSlider").trigger("click");
});
	

$("#troupeRequestsSlider").on("click", function(e){
e.stopPropagation();
});
//troupe requests slider



	



//PROJECT GOALS

$("body").on("click", ".confirmDeleteSharedPg", function(){
var sharedID = $(this).attr("value");
$(".eachSharedProject"+sharedID).fadeOut("slow");
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
sharedID: sharedID,
deleteSharedPg: 1
},
success: function(response){
alert(response);
}
});	
});		
		
		
		
		
$("body").on("click", ".deleteSharedPg", function(){
var projectID = $(this).attr("value");
$(this).slideUp("fast");
$("#deleteSharedProjectGoalConfirm"+projectID).slideDown("fast");
setTimeout(function(){
$(".deleteSharedPg"+projectID).slideDown("fast");
$("#deleteSharedProjectGoalConfirm"+projectID).slideUp("fast");
}, 3000);
});



$(".appliedProjectsScroll").on("scroll", function(){
var start = $(".trackofuser"+userLoggedIn).attr("data-appliedpgstart");
var elmnt = document.getElementById("appliedProjectsScroll");
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+100){

loadAppliedProjectGoals(userLoggedIn, start);
	
}
}, 150);
});

	








	
	


//VIEWED SHARED PROJECTS WITH ME
$("body").on('mousedown', ".viewPgSharedWithMe", function(){
$(".applicantsContainer").slideUp("fast");
$(".appliedProjectsScroll").slideUp("fast");
$(".projectGoalsScroll"+userLoggedIn).slideUp("fast");	
$(".myprojectgoalbuttons").slideDown("fast");
$(this).slideUp("fast");
$(".openProjectGoalMenu").html("Shared Projects");
setTimeout(function(){
$(".sharedProjectGoalsScroll").slideDown("fast");
}, 300)
	
$(".trackofuser"+userLoggedIn).attr("data-sharedpgstart", 0);
var start = $(".trackofuser"+userLoggedIn).attr("data-sharedpgstart");	
$(".sharedProjectGoalsScroll").empty();
loadSharedProjects(start);	
	
});
//view shared projects with me

function loadSharedProjects(start){
$.ajax({
url: "https://troupebase.com/sharedprojects.php",
method: "POST",
data: {
timeZone: timeZone,
start: start,
limit: 10,
loadShared: 1
},
success: function(response){
constructSharedProjects(response);
}
});
}

	
	




//FUNCTION CONSTRUCT SHARED projects
function constructSharedProjects(response){
if(response == "end"){
if($(".endOfSharedProjects").length === 0){
$(".sharedProjectGoalsScroll").append("<div class='endOfSharedProjects' style='width: 100%; text-align: center'><br>End of Shared Projects<br><br></div>");
}
return;
}
	
var start = $(".trackofuser"+userLoggedIn).attr("data-sharedpgstart");
var newStart = parseInt(start) + 10;
$(".trackofuser"+userLoggedIn).attr("data-sharedpgstart", newStart);



var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var project = data[i];	
	
	
$(".sharedProjectGoalsScroll").append("<div class='eachProjectGoal eachSharedProject"+project.sharedID+"' style='color: white'></div>");		

$(".eachSharedProject"+project.sharedID).append("<div class='projectGoalContent SharedProjectContent"+project.sharedID+"' id='SharedProjectContent"+project.sharedID+"'>Shared by: <span class='viewProfile' data-id='"+project.sharedBy+"'>"+project.sharedByName+"</span><br><img style='margin-top: 5px;' id='projectGoalProfilePic"+project.projectID+"' class='viewProfile projectGoalProfilePic projectGoalProfilePic"+project.projectID+" filter"+project.photoFilter+"' data-id='"+project.user+"' src='"+project.profilePic+"'><p class='pgUserName"+project.sharedID+"'>"+project.username+", "+project.userState+"</p><p class='projectGoalSubject"+project.sharedID+"' id='projectGoalSubject"+project.sharedID+"'>"+project.subject+"</p><p class='requiredPgTalent"+project.sharedID+"' id='requiredTalentShared"+project.sharedID+"'>For: "+project.requiredTalent+"</p><p style='font-size: 9px;' class='pgDateTime"+project.sharedID+"'>"+project.dateTime+"</p><p id='projectGoalDet"+project.sharedID+"' class='projectGoalDet"+project.projectID+"' style='Margin-top: 5px; white-space: pre-line; font-size: 14px;'>"+project.details+"</p></div>");	
if(project.state !== ""){
$("#requiredTalentShared"+project.sharedID).append(" in "+project.state);
}	
	

	
//ICON
$(".eachSharedProject"+project.sharedID).append("<div style='margin-bottom: 5px;' class='projectGoalIcons sharedProjectIcons"+project.sharedID+"'>");
$(".sharedProjectIcons"+project.sharedID).append("<img class='deleteSharedPg deleteSharedPg"+project.sharedID+"' value='"+project.sharedID+"' src='https://troupebase.com/assets/delete.png'>");
$(".sharedProjectIcons"+project.sharedID).append("<img class='sharePg sharePg"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/shareone.png'>");
$(".sharedProjectIcons"+project.sharedID).append("<img class='interested' id='interested"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/messagetwo.png'>");
//icons		
	
	
//CONFIRM CONTAINERS
$(".eachSharedProject"+project.sharedID).append("<div class='deleteProjectGoalConfirm' id='deleteSharedProjectGoalConfirm"+project.sharedID+"'><span>CONFIRM DELETE?</span><button style='color: red' class='confirmDeleteSharedPg' value='"+project.sharedID+"'>YES</button></div>");
//confirm containers	
	
	
}	
}
	


$(".sharedProjectGoalsScroll").on("scroll", function(){
var start = $(".trackofuser"+userLoggedIn).attr("data-sharedpgstart");	
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+300){
	
loadSharedProjects(start);
	
}
}, 150);
});



//function shared projects


	










//VIEW APPLIED
$("body").on('mousedown', ".showAppliedProjects", function(){
if($(".sharedProjectGoalsScroll").is(":visible")){
$(".sharedProjectGoalsScroll").slideUp("fast");
$(".myprojectgoalbuttons").slideDown("fast");
}
if($(".appliedProjectsScroll").is(":visible")){
$(this).slideDown("fast");
$(".appliedProjectsScroll").slideUp("fast");
setTimeout(function(){
$(".projectGoalsScroll"+userLoggedIn).slideDown("fast");
$(".openProjectGoalMenu").html("My Projects");
}, 300);
}else{
$(this).slideUp("fast");
$(".projectGoalsScroll"+userLoggedIn).slideUp("fast");
setTimeout(function(){
$(".appliedProjectsScroll").slideDown("fast");
$(".openProjectGoalMenu").html("Applied Projects");
$(".trackofuser"+userLoggedIn).attr("data-appliedpgstart", 0);
var start = $(".trackofuser"+userLoggedIn).attr("data-appliedpgstart");
$(".appliedProjectsScroll").empty();
loadAppliedProjectGoals(userLoggedIn, start);
	
	
}, 300);
}
});
//view applied


	



//TALENTS ARRAY
const arrayOfTalents = "Actor,Artist,Comedian,Culinary Baking,Dancer,Fashion,Gamer,Graphic Design,Health Fitness,MUA,Model,Music Composer,Musician,Podcast,Photography Video,Programmer (Web/Mobile),Rapper,Singer,Vlogger,Writer,";
	




//LOAD STATES
function loadStatesInSelector(container)
{
$(container).append('<option value="AL">Alabama</option><option value="AK">Alaska</option><option value="AZ">Arizona</option><option value="AR">Arkansas</option><option value="CA">California</option><option value="CO">Colorado</option><option value="CT">Connecticut</option><option value="DE">Delaware</option><option value="DC">District Of Columbia</option><option value="FL">Florida</option><option value="GA">Georgia</option><option value="HI">Hawaii</option><option value="ID">Idaho</option><option value="IL">Illinois</option><option value="IN">Indiana</option><option value="IA">Iowa</option><option value="KS">Kansas</option><option value="KY">Kentucky</option><option value="LA">Louisiana</option><option value="ME">Maine</option><option value="MD">Maryland</option><option value="MA">Massachusetts</option><option value="MI">Michigan</option><option value="MN">Minnesota</option><option value="MS">Mississippi</option><option value="MO">Missouri</option><option value="MT">Montana</option><option value="NE">Nebraska</option><option value="NV">Nevada</option><option value="NH">New Hampshire</option><option value="NJ">New Jersey</option><option value="NM">New Mexico</option><option value="NY">New York</option><option value="NC">North Carolina</option><option value="ND">North Dakota</option><option value="OH">Ohio</option><option value="OK">Oklahoma</option><option value="OR">Oregon</option><option value="PA">Pennsylvania</option><option value="RI">Rhode Island</option><option value="SC">South Carolina</option><option value="SD">South Dakota</option><option value="TN">Tennessee</option><option value="TX">Texas</option><option value="UT">Utah</option><option value="VT">Vermont</option><option value="VA">Virginia</option><option value="WA">Washington</option><option value="WV">West Virginia</option><option value="WI">Wisconsin</option><option value="WY">Wyoming</option>');
}
//LOAD TALENTS
function loadTalentsInSelector(container){
	
	
$(container).append("<option value='Actor'>Actor</option><option value='Artist'>Artist</option><option value='Comedian'>Comedian</option><option value='Culinary Baking'>Culinary Baking</option><option value='Dancer'>Dancer</option><option value='Fashion'>Fashion</option><option value='Gamer'>Gamer</option><option value='Graphic Design'>Graphic Design</option><option value='Health Fitness'>Health Fitness</option><option value='MUA'>MUA</option><option value='Model'>Model</option><option value='Music Composer'>Music Composer</option><option value='Musician'>Musician</option><option value='Podcast'>Podcast</option><option value='Photography Video'>Photography Video</option><option value='Programmer'>Programmer (Web/Mobile)</option><option value='Rapper'>Rapper</option><option value='Singer'>Singer</option><option value='Vlogger'>Vlogger</option><option value='Writer'>Writer</option>");

}






function loadAppliedProjectGoals(userLoggedIn, start){
$.ajax({
url: "https://troupebase.com/appliedprojects.php",
method: "POST",
data: {
userLoggedIn: userLoggedIn,
timeZone: timeZone,
start: start,
limit: 10,
loadApplied: 1
},
success: function(response){
constructAppliedProjects(userLoggedIn, response);
}
});
}
	


//BLINK ELEMENT
function makeElementBlink(elm){
$(elm).fadeTo("fast", .3).fadeTo("fast", 1).fadeTo("fast", .3).fadeTo("fast", 1).fadeTo("fast", .3).fadeTo("fast", 1).fadeTo("fast", .3).fadeTo("fast", 1);
}


	
//LOAD NEW PROJECT GOAL FORM
var projectCity = "";
var projectState = "";
var projectCountry = "";
var selectedTalentsPG = ",";	
	
function loadNewProjectForm()
{
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" newProjectGoalForm' id='newProjectGoalForm"+time+"'><div class='profileContainerTopBar'><i class='fas fa-backspace backarrows' id='closeNewProjectGoal"+time+"'></i><div class='pgheading'></div></div><div class='newProjectForm'><p style='margin-top:0px; font-weight: bold;'><span style='font-size: 20px;'>NEW PROJECT GOAL</span><br>LET OTHERS KNOW ABOUT YOUR PROJECT</p><br><div class='projectInputFields'><button class='chooseLocationForShare selectfilterbuttons'>Location</button><br><select class='customselect-1 newProjectGoalTalent' style='margin-top: 15px;'><option value='' selected='selected'>SELECT A TALENT</option></select><div class='selectedtalentsforproject' id='selectedtalentsforproject"+time+"'>SELECTED TALENTS:<br></div><label class='cutominput-1-label'>SUBJECT 50</label><input type='text' placeholder='SUBJECT' class='custominput-1' id='newProjectSub"+time+"'/> <label class='cutomtextarea-1-label'>DETAILS 1500</label><textarea class='customtextarea-1' id='projectGoalDetails"+time+"' placeholder='DETAILS'></textarea><div class='publishProjectButton' id='publishProjectButton"+time+"'><button>PUBLISH</button></div><div class='confirmprojectgoalslidedown' id='confirmprojectgoalslidedown'>Share Project Goal? <button id='confirmPGPost"+time+"'>YES</button><br><span>You may NOT make changes to the details of this Project Goal after its been posted</span></div></div></div></div></div>");
var selectContainer = ".newProjectGoalLocation";
loadStatesInSelector(selectContainer);
var selectContainer = ".newProjectGoalTalent";
loadTalentsInSelector(selectContainer);

	
	
//CONFIRM 
$("#confirmPGPost"+time).on("click", function(){
var subject = $("#newProjectSub"+time).val();
var details = $("#projectGoalDetails"+time).val();
loadLayOver();
publishProjectGoal(subject, details).then(function(response){
removeLayOver();	
if(response !== "error"){
var data = JSON.parse(response);
var post = data[0];
$(".newProjectGoalForm").remove();
$("#locationSearchWrap").remove();
$("#backtomymainfeed").trigger("click");
$("#backtomymainfeed").trigger("mousedown");
var container = document.getElementById('newPostprependHere');
constructProjectGoal(post, container);
setTimeout(function(){
var elm = document.getElementById('eachFeedPostWrap'+post.id);
makeElementBlink(elm);
}, 150);
}else{

}
	
});
});
	
	
	
//SUBMIT
$("#publishProjectButton"+time).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var subject = $("#newProjectSub"+time).val();
if(subject.length > 50){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SUBJECT EXCEEDS 50 CHARACTERS</p>");
showSuccess();
clickDelay = 0;
return;
}
if(subject == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SUBJECT REQUIRED</p>");
showSuccess();
clickDelay = 0;
return;
}
var details = $("#projectGoalDetails"+time).val();
if(details.length > 1500){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>DETAILS EXCEEDS 50 CHARACTERS</p>");
showSuccess();
clickDelay = 0;
return;
}
if(details == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>DETAILS REQUIRED</p>");
clickDelay = 0;
showSuccess();
return;
}
if(selectedTalentsPG == ","){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>TALENT REQUIRED</p>");
clickDelay = 0;
showSuccess();
return;
}
$(this).slideUp(100);
$("#confirmprojectgoalslidedown").slideDown(100);
clickDelay = 0;
}
});
	
	
	




	

$(".newProjectGoalTalent").on("change", function(){
var selected = $(this).val();
if(selectedTalentsPG.includes(selected+",")){
}else{
	
var count = selectedTalentsPG.split(",").length-2;
if(count == 3){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>3 TALENTS MAX</p>");
showSuccess();
return;
}
selectedTalentsPG = selectedTalentsPG+selected+",";
$(".selectedtalentsforproject").append("<button class='removeSelectedProjectTalent' value='"+selected+"'>"+selected+"</button>");
	console.log(selectedTalentsPG);
}
$(this).val("");
});
	
	
	
//REMOVE TALENT
$("#selectedtalentsforproject"+time).on("click", ".removeSelectedProjectTalent",function(){
$(this).remove();
var value = $(this).attr("value");
selectedTalentsPG = selectedTalentsPG.replace(value+",", "");
console.log(selectedTalentsPG);
});	
	
	
//CHARACTER LIMITS	
$(".custominput-1").on("input", function(){
var length = $(this).val().length;
var remaining = 50-length;
$(".cutominput-1-label").text("SUBJECT "+remaining);
if(remaining  < 0){
$(".cutominput-1-label").css("color", "red");
}else{
$(".cutominput-1-label").css("color", "#214844");
}
});

$(".customtextarea-1").on("input", function(){
var length = $(this).val().length;
var remaining = 1500-length;
$(".cutomtextarea-1-label").text("DETAILS "+remaining);
if(remaining  < 0){
$(".cutomtextarea-1-label").css("color", "red");
}else{
$(".cutomtextarea-1-label").css("color", "#214844");
}
});
	
	
	
//ANIMATIONS
$(".custominput-1").on("focus", function(){
$(this).attr("placeholder", "");
$(".cutominput-1-label").fadeTo( "slow" , 1,);
});
$(".custominput-1").on("blur", function(){
if($(this).val() == ""){
$(this).attr("placeholder", "WHAT IS THIS PROJECT ABOUT");
$(".cutominput-1-label").fadeTo( "fast" , 0,);
}
});	
$(".customtextarea-1").on("focus", function(){
$(this).attr("placeholder", "");
$(".cutomtextarea-1-label").fadeTo( "slow" , 1,);
});	
$(".customtextarea-1").on("blur", function(){
if($(this).val() == ""){
$(this).attr("placeholder", "PROVIDE RELEVANT DETAILS");
$(".cutomtextarea-1-label").fadeTo( "fast" , 0,);
}
});		
	
	
$("#closeNewProjectGoal"+time).on("click", function(){
close(time);
resetProjectForm();
});
	
$(".universalcontainer"+time).stop().animate({width: "100%"}, "fast", "linear");	
setTimeout(function(){
clickDelay = 0;
}, 500);
	
}

	
//RESET PROJECT GOAL FORM
function resetProjectForm(){
projectCity = "";
projectState = "";
projectCountry = "";
selectedTalentsPG = ",";
}



	


//CONSTRUCT NEW PROJECT GOAL
function constructNewProjectGoal(response, location, subject, details, selectedTalentsPG)
{
	var time = Date.now();
	
	var projectGoal = JSON.parse(response);
	
	var talents = userLoggedInTalents.replace(/,\s*$/, "");
	var selectedtalents = selectedTalentsPG.replace(/,\s*$/, "");
	talents = talents.replace(/,/g, ' ');
	var body = details.replace(/(?:\r\n|\r|\n)/g, '<br>');
	var loc = "";
	if(location !== "NOT REQUIRED"){
	loc = "In "+ location;
	}
	

	$(".projectGoalScroll").prepend("<div class='eachProjectGoal eachProjectGoal"+projectGoal.id+" eachProjectGoal"+time+"' id='eachProjectGoal"+time+"' style='width: 0%;'><div class='postedBy postedBy"+time+"'><div class='postedByPhoto'><img src='"+userLoggedInProfilePic+"'></div><div class='postedByName'><span style='font-weight: bold;'>"+userLoggedInName+"</span><br>"+talents+", "+userLoggedInState+"</div></div><div class='pgbody'><span style='font-size: 11px;'>Posted: NOW</span><br>For: "+selectedtalents+" "+loc+"<br>"+subject+"<p>"+body+"</p></div><div class='projectgoalicons'><img class='deletePg deletePg"+projectGoal.id+"' value='"+projectGoal.id+"' src='https://troupebase.com/assets/delete.png'><img class='sharePg sharePg"+projectGoal.id+"' value='"+projectGoal.id+"' src='https://troupebase.com/assets/sharethree.png'><img class='viewInterested' value='"+projectGoal.id+"' data-subject='"+projectGoal.id+"' src='https://troupebase.com/assets/totalresponses.png'></div></div>");
	
	
	
setTimeout(function(){
$("#eachProjectGoal"+time).stop().animate({width: "100%"}, "slow", "linear");
}, 500);	

}





//PUBLISH PROJECT GOAL
function publishProjectGoal(subject, details)
{

 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/publishprojectgoal.php",
method: "POST",
data: {
city: projectCity,
state: projectState,
country: projectCountry,
subject: subject,
details: details,
selectedTalentsPG: selectedTalentsPG,
userLoggedInTalents: userLoggedInTalents,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
resolve(response);
}
});

});
	
	
	
}




//CLOSE CONTAINER
function close(time){
$(".universalcontainer"+time).stop().animate({width: "0%"}, "fast", "linear");
setTimeout(function(){
$(".universalcontainer"+time).remove();
}, 300);
}

	



//GET PROJECT GOALS
function getProjectGoals(user, start){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/projectgoals.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});
});
}

	


	




	





	
	







//RESPONSE TO PROJECT GOAL
var currentProjectResponseText = "";
$("body").on("click", ".interested",function(){
if(clickDelay == 0){
clickDelay = 1;
var time = Date.now();
var counter = $(this).attr("data-counter");
console.log(counter);
$(".interested").slideDown(100);
$(this).slideUp(50);
var projectID = $(this).attr("data-projectid");
$(".pgrespdiv").empty();
$("#pgrespdiv"+counter).append("<textarea placeholder ='Your Response' class='activeProjectResponse' id='activeProjectResponse"+time+"'>"+currentProjectResponseText+"</textarea><button id='submitPgResp"+time+"'>Submit</button><button id='confirmPgResp"+time+"' class='greenConfirmButton' style='display: none;'>CONFIRM!</button>");

	
	$("#activeProjectResponse"+time).on("keyup", function(){
	currentProjectResponseText = $(this).val();
	});
	
	

	//SUBMIT
	$("#submitPgResp"+time).on("click", function(){
	$(this).slideUp(50);
	$("#confirmPgResp"+time).slideDown(100);
	});
	
	
	//CONFIRM
	$("#confirmPgResp"+time).on("click", function(){	
		var response = $("#activeProjectResponse"+time).val();
		if(response == ""){
		showAlert("You have to type something first", "red");
		$(this).slideUp(50);
		$("#submitPgResp"+time).slideDown(100);
		}else{
		
			loadLayOver();
			$(this).html("...");
			sendProjectResponse(projectID, response).then(function(response){
			
				if(response == "already applied" || response == "success"){
				$("#pgrespdiv"+counter).empty();
				$("#pgrespstat"+counter).append("<span style='color: #214844; font-weight: bold;'>Your responded to this project</span> <img class='hoverimage delprojresp' data-id='"+projectID+"' data-counter = '"+counter+"' src='../assets/delete.png'>");
				$("#interested"+projectID).remove();
				}
				
				
				removeLayOver();
				
				
			});
			
		}
	});
	
	
	
clickDelay = 0;	
}
});
	
	

//SEND PROJECT RESPONSE
function sendProjectResponse(projectID, response){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/sendprojectresponse.php",
method: "POST",
data: {
projectID: projectID,
message: response,
isWebsite: 1
},
success: function(response){

resolve(response);

}
});

});
}












	
	

//SHARE PROJECT GOAL
	$("body").on("click", ".sharePg",function(){
	var postID = $(this).attr("value");
	
	loadPostShareContainer(postID);
	});

	




	

//CLOSE
$("body").on("click", ".closebuttonstopleft", function(){
var time = $(this).attr("data-time");
close(time);
});


	












//REMOVE MY PROJECT RESPONSE
$("body").on("click", ".removeMyProjectResponse", function(){
var projectID = $(this).attr("data-projectid");
loadConfirmRemProjResponse(projectID);
});
	
function loadConfirmRemProjResponse(projectID){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer' id='cancelProjectResponseCont' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='abortCancelProjectResponse' aria-hidden='true'></i></div><div class='postScroller' style='color: white; font-weight: bold;'><br><br><br>UNDO YOUR RESPONSE TO THIS PROJECT?<br><br><button style='color: red;' id='confirmUndoProjRes'>YES</button><button style='color: white;' id='abortCanProjRes'>NO</button></div></div>");
	

$(".eachProjectGoal"+projectID).css("background-color", "red");
$(".eachProjectGoal"+projectID).css("color", "white");
	
	
	
//CONFIRM
$("#confirmUndoProjRes").on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
removeProjRespose(projectID);
}
});

//ABORT
$("#abortCanProjRes").on("click", function(){
$("#abortCancelProjectResponse").trigger("click");
});
$("#abortCancelProjectResponse").on("click", function(){
$(".eachProjectGoal"+projectID).css("background-color", "#e7f3ff");
$(".eachProjectGoal"+projectID).css("color", "black");
close(time);
});	
	
}

//REMOVE PROJECT RESPONSE
function removeProjRespose(projectID){
alert("now");
clickDelay = 0;
}





	


	




	
//SHARE PG
function loadPostShareContainer(id)
{
	var time = Date.now();
	
	$(".eachProjectGoal"+id).css("background-color", "#bbd4ec");
	$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+"' id='sharePgContainer' style='width: 100%;'><div class='portfolioHeading'><input type='text' id='userToShareProjectWith'  placeholder = 'SHARE POST WITH'><button class='cancelbutton cancelpgsharebutton' id='cancelPgShare"+time+"' style='margin-left: 3px;'>X</button></div><div class='postScroller' id='sharePGScroller"+time+"' data-start='0'></div></div>");

	
	//KEYUP
	$("#userToShareProjectWith").on("input", function(){
	$("#sharePGScroller"+time).empty();
	$("#sharePGScroller"+time).attr("data-start", 0);
	var user = $(this).val();
	var start = $("#sharePGScroller"+time).attr("data-start");
	getusers(user, time, start).then(function(response){
		ConUsersToSharePG(response, time, start, id);
	}).catch(function(){
			somethingwentwrong();
	});
	});
	
	
	//CANCEL SHARE
	$("#cancelPgShare"+time).on("click", function(){
	$(".eachProjectGoal"+id).css("background-color", "#e7f3ff");
	$("#sharePgContainer").remove();
	});
	
	
	$("#sharePGScroller"+time).on("scroll", function(){
	
	});
	
	
	$("#userToShareProjectWith").focus();
	
}
	
	


//CONSTRUCT USERS TO SHARE PG WITH 
function ConUsersToSharePG(response, time, start, id){
if(response == "end"){
return;
}
var newStart = parseInt(start) + 10;
$("#sharePGScroller"+time).attr("data-start", newStart);

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){

var user = data[i]; 
	
var profilePic = user.profilePic;
if(profilePic == ""){
profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}

if($("#generalUserShareContainer"+user.id).length == 0){
$("#sharePGScroller"+time).append("<div class='generalUserContainer generalUserContainer"+user.id+" generalUserShareContainer' id='generalUserShareContainer"+user.id+"'><div class='generalUserConProfilePic'><img src='"+profilePic+"' id='spwtu"+user.id+"' value='"+user.id+"'></div><div class='generalUserConInfo'><p style='font-weight: bold;'>"+user.name+"</p><p>"+user.talentString+", "+user.state+"</p><div id='confirmProjectShareContainer"+user.id+"' class='confirmProjectShareContainer'>Share project with "+user.name+"?<br><button id='confirmProjectShare"+user.id+"' class='confirmProjectShare' data-user='"+user.id+"' data-name='"+user.name+"'>YES</button></div></div></div>");
	
	
	//CONFIRM SHARE
	$("#confirmProjectShare"+user.id).on("click", function(){
	showAlert("Sharing..", "black");
	if(clickDelay == 0){
	clickDelay = 1;
	var projectID = id;
	var user = $(this).attr("data-user");
	sharePostFunction(user, projectID).then(function(sharePGResponse){
		//ALREADY SHARED
		if(sharePGResponse == "alreadyshared"){
		showAlert("ALREADY SHARED", "red");
		}
		
		if(sharePGResponse == "success"){
		showAlert("POST HAS BEEN SHARED", "green");
		}
		
		
		
		setTimeout(function(){
		$(".generalUserShareContainer").css("background-color", "transparent");
		$(".confirmProjectShareContainer").slideUp("fast");
		$(".cancelpgsharebutton").trigger("click");
		removeAlert();
		}, 2000);
		
		
		
	}).catch(function(){
	});
	}
	});
	
	
	
	
	
	//SHARE
	$("#spwtu"+user.id).on("click", function(){
	var userID = $(this).attr("value");
	$(".confirmProjectShareContainer").slideUp("fast");
	$("#confirmProjectShareContainer"+userID).slideDown("fast");
	$(".generalUserShareContainer").css("background-color", "transparent");
	$("#generalUserShareContainer"+userID).css("background-color", "#6e9692");
	});
	
	
}
	
	
	

}
}

//SHOW ALERT
function showAlert(text, color)
{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: "+color+"'>"+text+"</p>");
$("#successResponseDropDown").slideDown("fast");
setTimeout(function(){
removeAlert();
}, 2000);
}
//REMOVE ALERT
function removeAlert()
{
$("#successResponseDropDown").slideUp("fast");
}


//SHARE PROJECT GOAL FUNCTION
function sharePostFunction(user, projectID){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/sharepost.php",
method: "POST",
data: {
user: user,
projectID: projectID,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
if (response !== "error")
resolve(response);
else
reject(response);
}
});

});
}


	
//GET USERS FUNCTION
function getusers(user, time, start)
{
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/getusers.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
if (response !== "error")
resolve(response);
else
reject(response);
}
});

});
}




//DELETE PROJECT GOAL
function loadDeleteProjectGoal(id)
{
var time = Date.now();
	$(".eachProjectGoal"+id).css("background-color", "red");
	$(".eachProjectGoal"+id).css("color", "white");
	
	$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" deleteProjectGoalContainer confirmcontainer' id='confirmcontainer' style='width: 100%;' id='deleteProjectGoalContainer'><div class='portfolioHeading'></div><div class='postScroller postScroller"+time+"' style='color: white; font-weight: bold;'> <br><br><br>YOU WILL LOSE ANY CURRENT APPLICANTS <br>DELETE THIS PROJECT GOAL?<br><br><button id='confirmDeletePg"+id+"' value='"+id+"' style='color: red;'>YES</button><button id='cancelDeleteProjectGoal"+time+"' style='color: white;'>NO</button></div></div>");
	
	$("#cancelDeleteProjectGoal"+time).on("click", function(){
		$(".eachProjectGoal"+id).css("background-color", "#e7f3ff");
		$(".eachProjectGoal"+id).css("color", "black");
	removeConfirmContainer();
	});
	
$("#confirmDeletePg"+id).on("click", function(e){
$("#cancelDeleteProjectGoal"+time).trigger("click");
var projectID = $(this).attr("value");
$.ajax({
url: "https://troupebase.com/formhandlers/deletepg.php",
method: "POST",
data: {
projectID: projectID,
isWebsite: 1
}
});
$(".eachProjectGoal"+projectID).fadeOut("slow");
});
	

}


	
function removeConfirmContainer()
{
	$("#confirmcontainer").remove();
}
	


$("body").on("click",  ".closePgMessage", function(){
$("#viewFullPgMessageSlider").slideUp(50);
});

	
$("body").on("click", ".toggleProjectsToLoad", function(){
projectGoalsToLoad = $(this).attr("value");
myProjectGoalStart = 7;
myProjectGoalLimit = 7;
$(".toggleProjectsToLoad").slideDown(50);
$(this).slideUp(50);
var buttonHead = $(this).attr("data-head");
	alert("now");
$("#openMyProjectGoalMenu").text(buttonHead);


if(projectGoalsToLoad == "myProjects"){
	
$(".myProjectGoalsScroll").load("https://troupebase.com/projectGoals.php",{
projectGoalsToLoad: projectGoalsToLoad,
troupeID: userLoggedIn,
timeZone: timeZone,
projectGoalStart: 0,
projectGoalLimit: 7
	
});
}else{
	
$(".myProjectGoalsScroll").load("https://troupebase.com/appliedprojects.php",{
projectGoalsToLoad: projectGoalsToLoad,
timeZone: timeZone,
projectGoalStart: 0,
projectGoalLimit: 7
});
	
}
	

	
});
	









$("body").on("mousedown mouseover", ".showProjectGoalMenuContainer", function(){
$(this).slideUp(50);
var id = $(this).attr("data-id");
$(".projectGoalSlideMenu"+id).animate({"left":"65%"}, "slow");
setTimeout(function(){
$(".projectGoalSlideMenu"+id).animate({"left":"110%"}, "slow");
$("#showProjectGoalMenuContainer"+id).slideDown(1000);
}, 3000);
});




	



	


	




	
$("#troupeOfTheDayContainer").on("click", ".cancelNewProjectGoal", function(e){
e.preventDefault();
$("#newProjectGoalContainer").slideUp(100);
$(".createNewProjectGoal").slideDown(100);
});
	







	

$("body").on("click", "#createProjectGoal", function(){
var subject = $("#projectSubject").val();
var requiredTalent = $("#requiredTalent").val();
var state = $("#projectGoalState").val();
var details = $("#projectDetails").val();
details = details.replace(/\n\s*\n/g, '\n');
if(subject == null || requiredTalent == "" || requiredTalent == null || details == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>ENTER ALL FIELDS</p>");
showSuccess();
return;
}
$(this).slideUp(10);
$(".confirmCreatePGSlider").slideDown("fast");
});



	



$("#troupeOfTheDayContainer").on("click", "#finalizePRojectGoal", function(){
var subject = $("#projectSubject").val();
var requiredTalent = $("#requiredTalent").val();
var state = $("#projectGoalState").val();
var details = $("#projectDetails").val();
details = details.replace(/\n\s*\n/g, '\n');
if(subject == null || requiredTalent == "" || requiredTalent == null || details == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>ENTER ALL FIELDS</p>");
showSuccess();
return;
}
var createProjectGoal = 1;
if(subject.length>40 || details.length>400){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMITS</p>");
showSuccess();
return;
}
$(".confirmCreatePGSlider").slideUp("fast");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>PLEASE WAIT..</p>");
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
subject: subject,
requiredTalent: requiredTalent,
state: state,
details: details,
createProjectGoal: createProjectGoal
},
success: function(response){
if(response !== "error"){
$("#subjectCount").text("0");
$("#projectSubject").val("");
$("#detailsCount").text("0");
$("#projectDetails").val("");
$("#createProjectGoal").slideDown(50);
$(".cancelNewProjectGoal").trigger("click");
$(".viewMyPG").trigger("click");
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>Something went wrong, please try again</p>");
showSuccess();
$("#createProjectGoal").slideDown(50);
}
}
});
});

	
	






	

//FUNCTION ADD PROJECT GOAL
function addProjectGoal(response){
var photo = $("#goToHomeIcon").attr("src");
var name = $("#myCurrentName").attr("value");
var state = $("#myCurrentState").attr("value");
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var project = data[i];
	
var details = project.details;

	
$(".projectGoalsScroll"+project.userLoggedIn).prepend("<div class='eachProjectGoal eachProjectGoal"+project.projectID+"'></div>");

//CONTENT
$(".eachProjectGoal"+project.projectID).append("<div class='projectGoalContent projectGoalContent"+project.projectID+"' id='projectGoalContent"+project.projectID+"'><img style='margin-top: 5px;' id='projectGoalProfilePic"+project.projectID+"' class='projectGoalProfilePic projectGoalProfilePic"+project.projectID+"' src='"+photo+"'><p class='pgUserName"+project.projectID+"'>"+name+", "+state+"</p><p class='projectGoalSubject"+project.projectID+"' id='projectGoalSubject"+project.projectID+"'>"+project.subject+"</p><p class='requiredPgTalent"+project.projectID+"' id='requiredTalent"+project.projectID+"'>For: "+project.requiredTalent+"</p><p style='font-size: 9px;' class='pgDateTime"+project.projectID+"'>"+project.dateTime+"</p><p id='projectGoalDet"+project.projectID+"' class='projectGoalDet"+project.projectID+"' style='Margin-top: 5px; white-space: pre-line; font-size: 14px;'>"+details+"</p></div>");
if(project.state !== ""){
$("#requiredTalent"+project.projectID).append(" in "+project.state);
}
$(".eachProjectGoal"+project.projectID).append("<button class='reportPG reportPG"+project.projectID+"' value='"+project.projectID+"' data-user = '"+project.userLoggedIn+"'>Report</button>");
//content
	

//ICON
$(".eachProjectGoal"+project.projectID).append("<div style='margin-bottom: 5px;' class='projectGoalIcons projectGoalIcons"+project.projectID+"'>");
if(project.userLoggedIn == project.user){
$(".projectGoalIcons"+project.projectID).append("<img class='deletePg deletePg"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/delete.png'>");
}
$(".projectGoalIcons"+project.projectID).append("<img class='sharePg sharePg"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/share.png'>");
if(project.userLoggedIn !== project.user){
$(".projectGoalIcons"+project.projectID).append("<img class='interested' id='interested"+project.projectID+"' value='"+project.projectID+"' src='https://troupebase.com/assets/applyone.png'>");
}
if(project.userLoggedIn == project.user){
$(".projectGoalIcons"+project.projectID).append("<img class='viewInterested' value='"+project.projectID+"' data-subject='"+project.subject+"' src='https://troupebase.com/assets/applicant.png'>");
}
//icons

	

//CONFIRM CONTAINERS
//CONFIRM DELETE
$(".eachProjectGoal"+project.projectID).append("<div class='deleteProjectGoalConfirm' id='deleteProjectGoalConfirm"+project.projectID+"'>CONFIRM DELETE?<button style='color: red' class='confirmDeletePg' value='"+project.projectID+"'>YES</button></div>");

//confirm delete
	

//REPORT SLIDEDOWN
$(".eachProjectGoal"+project.projectID).append("<div class='reportPgSlider reportPgSlider"+project.projectID+"'>REPORT THIS PROJECT?<button class='confirmProjectGoalReport' style='color' data-user='"+project.user+"' data-id='"+project.projectID+"'>YES</button></div>");	
//report slidedown

//confirm containers	
	
	


}
}
//function add project goal



	






	



$("#troupeOfTheDayContainer").on("mousedown", ".closeApplicantsSlider", function(e){
$("#applicants").slideUp(100);
});	
	




//DELETE PG
$("#troupeOfTheDayContainer").on("click", ".deletePg", function(e){
var projectID = $(this).attr("value");
$(this).slideUp("fast");
$(".projectGoalSlideMenu").animate({"left":"110%"}, "fast");
$(".showProjectGoalMenu").slideDown(50);
$("#deleteProjectGoalConfirm"+projectID).slideDown(100);
setTimeout(function(){
$("#deleteProjectGoalConfirm"+projectID).slideUp(100);
$(".deletePg"+projectID).slideDown("fast");
}, 3000)
});	
//delete pg
	




	







	









//VIEW PROJECT RESPONSES
$("body").on("click", ".viewInterested", function(e){
if(clickDelay == 0){
clickDelay = 1;
var projectID = $(this).attr("value");
loadProjectResponses(projectID);
}
});	

//LOAD PROJECT RESPONSE CONTAINER
function loadProjectResponses(projectID){
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" projectGoalResponses' style='width: 100%'><div class='portfolioHeading' style='color: black;'><i class='fas fa-backspace closebuttonstopleft closePost"+time+" backarrows'></i>Project Responses</div><div class='postScroller postScroller"+time+"' id='projectRespScroll"+time+"'><div id='projectResponseProject'></div><div class='projectRespScroll' id='projectRespScroller"+time+"' data-start='0'></div></div></div>");
	
//GET INITIAL RESPONSES
var start = 0;
getProjectResponses(projectID, start, 1).then(function(response){
var data = JSON.parse(response);
var post = data[0][0];
var responses = data[1];
var container = document.getElementById('projectResponseProject');
constructProjectGoal(post, container, "responses");
constructProjectResponses(time, start, responses);
});
	
	
//SCROLL
$("#projectRespScroller"+time).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
console.log(t);
if(t<300){
$("#projectResponseProject").slideDown(150);
}else{
$("#projectResponseProject").slideUp(150);
}
	
	
	
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t <= c+150){
var start = $("#projectRespScroller"+time).attr("data-start");
getProjectResponses(projectID, start, 0).then(function(response){
var data = JSON.parse(response);
var post = data[0][0];
var responses = data[1];
var container = document.getElementById('projectResponseProject');
constructProjectResponses(time, start, responses);
});
	
}
}, 150);	
	
	
	

});
	
	
	
	
	
//CLOSE
$(".closePost"+time).on("click", function(){
close(time);
});
	
	clickDelay = 0;
}
	
	

	
	
//CONSTRUCT PROJECT GOAL RESPONSES
function constructProjectResponses(time, start, responses){
if(responses == "end"){
return;
}
	
	
var newStart = parseInt(start) + 20;
$("#projectRespScroller"+time).attr("data-start", newStart);
	
for(var i = 0; i < responses.length; i++){
var response = responses[i];	
	
	var profilePic = response.userObj.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
var talentString = 	response.userObj.talentString;
var talentText = talentString.replace(',', ''); 
talentText = talentText.replace(/,\s*$/, "");
talentText = talentText.replace(/,/g, ', ');
	
var usersState = response.userObj.state;
	
	
	
$("#projectRespScroller"+time).append("<div class='eachFeedPostWrap eachProjectResponse eachFeedPostWrap"+response.id+"' id='eachProjectResponse"+response.id+"'><div class='responseTop'><div class='responseTopImg'><img src='"+profilePic+"' class='viewProfile' data-id='"+response.userObj.id+"'></div><div class='responseTopUserInfo'><span style='font-weight: bold;'>"+response.userObj.name+"</span><br><span>"+talentText+", "+usersState+"</span></div></div><div class='responseBottom'><span>@ "+response.dateTime+"</span><br><span>"+response.message+"</span><div class='eachFeedPostControls'><img class='hoverimage ignoreProjResp' id='ignoreProjResp"+response.id+"' value='"+response.id+"' src='../assets/delete.png'><img class='interested hoverimage' id='interested151621501755' data-postedby='15' data-projectid='151621501755' data-counter='06627488242263451' src='../assets/messagetwo.png' style='margin-right: 15px;'><button class='redTextOnlyButton reportpostbutton' id='reportpostbutton151621501755' value='151621501755'>Report</button></div><div class='confirmdeletediv' id='conIgnoreDiv"+response.id+"'>Ignore response?<button class='confirmDeleteButton conIgnoreResponse' id='conIgnoreResponse"+response.id+"' value='"+response.id+"' data-projectid='"+response.projectID+"'>YES</button></div></div></div>");
	
	
	
	
//CONFIRM IGNORE
$("#conIgnoreResponse"+response.id).on("click", function(){
var id = $(this).attr("value");
var projectID = $(this).attr("data-projectid");
loadLayOver();
ignoreProjectResp(id, projectID).then(function(ignoreResponse){
removeLayOver();
if(ignoreResponse == "success"){
$("#eachProjectResponse"+id).fadeOut("fast");
}else{

}
});
});
	
//IGNORE
$("#ignoreProjResp"+response.id).on("click", function(){
var id = $(this).attr("value");
$(this).slideUp(50);
$("#conIgnoreDiv"+id).slideDown(50);
setTimeout(function(){
$("#ignoreProjResp"+id).slideDown(50)
$("#conIgnoreDiv"+id).slideUp(50);
}, 2500);
});	
	
	

}
}



//IGNORE PROJECT RESPONSE
function ignoreProjectResp(id, projectID){
	alert(id + " " + projectID);
 return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/ignorprojresponse.php",
method: "POST",
data: {
id: id,
projectID: projectID,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});
});
}



//GET PROJECT GOAL RESPONSES
function getProjectResponses(projectID, start, getProjectAlso){
 return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/getprojectresponses.php",
method: "POST",
data: {
id: projectID,
start: start,
getProjectAlso: getProjectAlso,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});
});
}
	








//


	


	

$("body").on("mouseover touchstart", ".showPgApplicantmenu", function(){
$(this).slideUp(50);
var id = $(this).attr("value");
$("#projectGoalApplicantMenu"+id).animate({"left":"65%"}, "slow");
setTimeout(function(){
$("#projectGoalApplicantMenu"+id).css("left", "110%");
$("#showPgApplicantmenu"+id).slideDown(50);
},2500);
});


	




	




$("body").on("click", ".ignorePgApp", function(){
$(this).slideUp("fast");
var id = $(this).attr("value");
$(".confirmIgnorePgApp"+id).slideDown("fast");
setTimeout(function(){
$(".ignorePgApp"+id).slideDown("fast");
$(".confirmIgnorePgApp"+id).slideUp("fast");
}, 3000);
});


$("body").on("click", ".confirmIgnoreApplicant", function(){
var id = $(this).attr("value");
var user = $(this).attr("data-user");
$(".eachApplicant"+id).fadeOut();
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
id: id,
user: user,
ignoreApplicant: 1
}
});
});





$("body").on("mousedown touchstart", ".closepgSlider", function(){
var user = $(this).attr("data-user");
if(user == userLoggedIn){
if($(".sharedProjectGoalsScroll").is(":visible")){
$(".sharedProjectGoalsScroll").slideUp("fast");
setTimeout(function(){
$(".projectGoalsScroll"+userLoggedIn).slideDown("fast");
$(".myprojectgoalbuttons").slideDown("fast");
$(".openProjectGoalMenu").text("My Projects");
}, 300);
return;
}
if($(".applicantsContainer").is(":visible")){
$(".applicantsContainer").slideUp("fast");
setTimeout(function(){
$(".projectGoalsScroll"+userLoggedIn).slideDown("fast");
$(".openProjectGoalMenu").text("My Projects");
}, 500);
return;
}
if($(".appliedProjectsScroll").is(":visible")){
$(".showAppliedProjects").trigger("mousedown");
$(".appliedProjectsScroll").empty();
return;
}
}
$(".projectGoalSlider"+user).animate({width: "0%"});
});



	








	






/*project goals*/


	
	






















	
	

//MY TROUPE MENU
	


$("body").on("mousedown", ".openTroupeMenuIcon", function(){
$(".openTroupeMenuIcon").slideDown(100);
$(this).slideUp(100);
$(".myTroupesMenuButtons").slideUp(100);
var troupeID = $(this).attr("value");
$("#myTroupesMenuButtons"+troupeID).slideDown(100);

});



	
$("body").on("mousedown", ".reportUser", function(){
$(".profileDropDown").slideUp(50);
var troupeID = $(this).attr("value");
var openReportForm = 1;
$.ajax({
url: "https://troupebase.com/formHandlers/report.php",
method: "POST",
data: {
troupeID: troupeID,
openReportForm: openReportForm
},
success: function(response){
$("#formHandlerDiv").append(response);
}
});
});
//my troupe menu
	
	
	
	
	
//REPORT
	


$("body").on("click", ".confirmPostReport", function(){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>THANK YOU FOR REPORTING THIS POST</p>");
$("#postReportSlider").slideUp();
$("#reportPostInputs").empty();
showSuccess();
if(reportType=="pg"){
$(".eachProjectGoal"+postToReport).fadeOut(3500);
}
if(reportType=="collab"){
$("#eachCollabOptionsContainer"+postToReport).remove();
$("#eachCollabContainer"+postToReport).fadeOut(3500);
}
$.ajax({
url: "https://troupebase.com/formHandlers/reportpost.php",
method: "POST",
data: {
postToReport: postToReport,
troupeID: postedByID,
reportType: reportType
},
success: function(response){

}
});
});
	

	
$("body").on("click", ".reportCollab", function(){
postToReport = $(this).attr("data-id");
reportType = "collab";
postedByID = $(this).attr("data-troupeid");
openPostReport();
});


	

	

//REPORT PG



$("body").on("click", ".reportPG", function(){
postToReport = $(this).attr("value");
reportType = "pg";
postedByID = $(this).attr("data-user");
$(".reportPG"+postToReport).slideUp("fast");
$(".reportPgSlider"+postToReport).slideDown("fast");
setTimeout(function(){
$(".reportPG"+postToReport).slideDown("fast");
$(".reportPgSlider"+postToReport).slideUp("fast");
}, 2500);
});
	

$("body").on("click", ".confirmProjectGoalReport", function(){
var user = $(this).attr("data-user");
var projectID = $(this).attr("data-id");
$(".eachProjectGoal"+projectID).fadeOut("fast");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>Thank You for Your Report</p>");
showSuccess();
$.ajax({
url: "https://troupebase.com/formHandlers/projectGoal.php",
method: "POST",
data: {
projectID: projectID,
user: user,
reportPg: 1
}
});
});

//report pg
	

$("body").on("click", "#submitPostToReport", function(){
$(this).slideUp(50);
$("#confirmPostToReportContainer").slideDown(50);
setTimeout(function(){
$("#confirmPostToReportContainer").slideUp(50);
$("#submitPostToReport").slideDown(50);
}, 3000);
});
$("body").on("click", '#cancelPostToReport', function(){
$("#reportPostInputs").empty();
$("#postReportSlider").slideUp(50);
});





$("#abandonReport").on("mousedown", function(){
$("#reportSlider").slideUp(100);
});
	

$("body").on("click", "#submitReport",function(){
var troupeID = $(this).attr("value");
var reason = $("#reportReason").val();
var details = $("#reportDetails").val();
var submitReport = 1;
if(reason == "null" || reason=="" || details ==""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>ALL FIELDS REQUIRED</p>");
showSuccess();
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green;'>USER HAS BEEN REPORTED</p>");
showSuccess();
$("#reportSlider").slideUp(100);
$(".openTroupeMenuIcon").slideDown(100);
$(".myTroupesMenuButtons").slideUp(100);
$.ajax({
url: "https://troupebase.com/formHandlers/report.php",
method: "POST",
data: {
troupeID: troupeID,
reason: reason,
details: details,
submitReport: submitReport
}
});
}
});


//report
	
	
	
//UNTROUPE
$("body").on("mousedown", "#confirmUntroupe", function(){	
var id = $(this).attr("value");
$(".myTroupe"+id).fadeOut();
$("#reportSlider").slideUp(100);
$.ajax({
url: "https://troupebase.com/formHandlers/report.php",
method: "POST",
data: {
troupeID: id,
confirmUntroupe: 1
}
});
});

$("body").on("mousedown", ".untroupe", function(){	
var id = $(this).attr("value");
$.ajax({
url: "https://troupebase.com/formHandlers/report.php",
method: "POST",
data: {
troupeID: id,
openUntroupeForm: 1
},
success: function(response){
$("#formHandlerDiv").append(response);
}
});
});
//untroupe
	

	










//COLLAB REQUESTS
	

$("body").on("click", ".viewCollabResponse", function(){
$(this).slideUp(50);
var id = $(this).attr("data-id");
$("#collabResponseContainer"+id).slideDown(50);
});

$("body").on("click", ".hideCollabResponse", function(){
var id = $(this).attr("data-id");
$("#collabResponseContainer"+id).slideUp(50);
$("#viewCollabResponse"+id).slideDown(50);
});
	
$("body").on("click", ".deleteCollabRequest", function(){	
var id = $(this).attr("data-id");
$.ajax({
url: "https://troupebase.com/formHandlers/collabRequest.php",
method: "POST",
data: {
id: id,
deleteCollabRequest: 1
},
success: function(response){
if(response == "success"){
$("#eachCollabContainer"+id).fadeOut(100);
setTimeout(function(){
$("#eachCollabContainer"+id).remove();
},500);
}
}
});	
});

	
	



$("body").on("click", ".clearCollabResponse", function(){
var id = $(this).attr("data-id");
$.ajax({
url: "https://troupebase.com/formHandlers/collabRequest.php",
method: "POST",
data: {
id: id,
clear: 1
},
success: function(response){
if(response == "success"){
$("#eachCollabContainer"+id).fadeOut(100);
setTimeout(function(){
$("#eachCollabContainer"+id).remove();
},500);
}
}
});
});

	



$("body").on("click", ".confirmCollabResponse", function(){
var id = $(this).attr("value");
var subject = $("#collabResponseSubject").text();
var body = $("#collabResponseBody").val();
var troupeID = $(this).attr("data-userto");
var collabResponseDetails = $("#collabResponseDetails").text();
$("#collabResponseBody").val("");
if(body == ""){
alert("WRITE A MESSAGE");
return;
}
$.ajax({
url: "https://troupebase.com/formHandlers/messages.php",
method: "POST",
data: {
sendCollabResponse: 1,
id: id,
subject: subject,
body: body,
troupeID: troupeID,
collabResponseDetails: collabResponseDetails
},
success: function(response){
if(response == "success"){
$("#eachCollabContainer"+id).fadeOut(4000);
$("#confirmSendCollabResponse").slideUp(100);
$(".sendCollabResponse").slideDown(100);
$("#collabResponseSlider").slideUp(100);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: #009688'>COLLAB RESPONSE SENT</p>");
showSuccess();
}
}
});
});

	
$("body").on("click", ".sendCollabResponse", function(){
$(this).slideUp(100);
$("#confirmSendCollabResponse").slideDown(50);
});
	

$("body").on("click", ".abandonCollabResponse", function(){
$("#collabResponseSlider").slideUp(50);
$(".sendCollabResponse").slideDown(50);
$("#confirmSendCollabResponse").slideUp(50);
});


	
$("body").on("touchstart mouseover", ".showCollabOptions", function(){
$(this).slideUp(50);
var id = $(this).attr("data-id");
$(".eachCollabOptionsContainer").css("left", "110%");
$("#eachCollabOptionsContainer"+id).animate({"left":"65%"}, "slow");
setTimeout(function(){
$("#eachCollabOptionsContainer"+id).css("left", "110%");
$("#showCollabOptions"+id).slideDown(50);
}, 3000);
});	
	


$("body").on("click", "#confirmSendCollab", function(){
var subject = $("#collabSubject").val();
var details = $("#collabDetails").val();
if(subject.length>50 || details.length>400){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='color: red; font-weight: bold;'>SUBJECT OR DETAILS TOO LONG</p>");
showSuccess();
return;
}
$("#confirmCollabSlider").slideUp(100);
$(".abandonCollabRequest").slideUp(100);
sendCollabRequest();
});


$("body").on("click", "#sendCollabRequest", function(){
$(this).slideUp(100);
$("#confirmCollabSlider").slideDown(100);
});

	
//LOAD FORM
$(document).on("click", ".sendCollab", function(){
var troupeID = $(this).attr("value");
collabTo = troupeID;
$("#collabRequestFormSlider").slideDown(100);
$.ajax({
url: "https://troupebase.com/formHandlers/collabRequest.php",
method: "POST",
data: {
loadForm: 1,
troupeID: troupeID
},
success: function(response){
$("#formHandlerDiv").append(response);
}
});
});
//

	

$("#collabRequestMenuButton").on("mousedown", function(){
$("#collabRequestMenuSlider").slideToggle(100);
});	
	
	

$("#myCollabRequests").on("click", function(){
$("#toggleCollabsReceived").trigger("click");
});
	
$(".toggleCollabs").on("click", function(){
collabsStart = 7;
collabsLimit =  7;
collabsToLoad = $(this).attr("value");
$("#collabsScroller").empty();
var collabsToLoadCaps = collabsToLoad.toUpperCase();
$("#collabsScroller").empty();
$("#collabRequestMenuSlider").slideUp(200);
$(".toggleCollabs").slideDown(100);
$(this).slideUp(100);
$("#currentCollabList").text(collabsToLoadCaps);
$("#collabsScroller").load("https://troupebase.com/collabs.php",{
collabsStart: 0,
collabsLimit: 7,
timeZone: timeZone,
collabsToLoad: collabsToLoad
});
});
	



$("#collabsScroller").on("scroll", function(){
var elmnt = document.getElementById("collabsScroller");
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){
if(y - t === c){
	
loadMoreCollabs();	
	
}
}, 150);
});




$(".closeCollabs").on("click", function(){
$("#collabRequestMenuSlider").slideUp(100);
$("#collabRequestsSlider").slideUp(100);
});
	
$("body").on("click", ".abandonCollabRequest", function(){
$("#collabRequestFormSlider").slideUp(100);
$("#confirmCollabSlider").slideUp(100);
$("#sendCollabRequest").slideDown(100);
});
	
	



	

$("body").on("click", ".ignoreCollab", function(){
var id = $(this).attr("data-id");
$("#showCollabOptions"+id).slideUp(100);
$("#ignoreCollabConfirmContainer"+id).slideDown(100);	
$(".eachCollabOptionsContainer").css("left", "110%");
setTimeout(function(){
$("#ignoreCollabConfirmContainer"+id).slideUp(100);	
}, 4000);
});
	
$("body").on("click", ".confirmDeleteCollabRequest", function(){
var id = $(this).attr("data-id");
$.ajax({
url: "https://troupebase.com/formHandlers/collabRequest.php",
method: "POST",
data: {
ignore: 1,
id: id
},
success: function(response){
if(response == "success"){
$("#eachCollabContainer"+id).fadeOut(100);
setTimeout(function(){
$("#eachCollabContainer"+id).remove();
},500);
}
}
});
});
	



$("body").on("click", ".respondToCollab", function(){
var id = $(this).attr("data-id");
var userFrom = $(this).attr("data-userfrom");
var profilePic = $("#collabProfilePic"+id).attr("value");
var collabFrom = $("#collabFrom"+id).text();
var collabFromTalentState = $("#collabFromTalentState"+id).text();
var collabDetails = $("#collabDetails"+id).text();
var collabSubject = $("#collabSubject"+id).text();
$("#collabResponseProfilePic").empty();
$("#collabResponseProfilePic").append("<img src='"+profilePic+"'>");
$("#collabResponseName").text(collabFrom);
$("#collabResponseFromTalentState").html(collabFromTalentState);
$("#collabResponseDetails").text(collabDetails);
$(".collabResponseSubject").text(collabSubject);
$("#collabResponseSlider").slideDown(100);
$(".confirmCollabResponse").attr("value", id);
$(".confirmCollabResponse").attr("data-userto", userFrom);
});



$("body").on("touchstart mousedown", "#collabsScroller", function(){
$("#collabRequestMenuSlider").slideUp(100);
});
//collab requests






	
	



//AUDIO PLAYER
var audio = new Audio();
audio.src = '';	
var audioTrackBar = document.getElementById('audioTracker');
var audioIsSeeking = 0;
window.addEventListener("load", function(){
	
	

$("body").on("click", ".play", function(){
$(this).css("display", "none");
$(".pause").css("display", "initial");
if(audio.pause){
audio.play();
}
});	

$("body").on("click", ".pause", function(){
$(this).css("display", "none");
$(".play").css("display", "initial");
if(audio.play){
audio.pause();
}
});		
	
	
	
audio.addEventListener('timeupdate', function(){
var currentProgress = (audio.currentTime / audio.duration) * 100;	
if(audioIsSeeking == 0){
mediaSeeker.value= currentProgress;
}

});
	

	
	
audio.addEventListener('ended', function(){
audio.pause();
audio.currentTime = 0;
$(".play").css("display", "initial");
$(".pause").css("display", "none");
});	
	
	
	

$("#audioTracker").on("mousedown touchstart", function(){
audioIsSeeking = 1;
});

$("#audioTracker").on("mouseup touchend", function(){
audioIsSeeking = 0;
});	
	
$("#audioTracker").on("change", function(){
var newSeekPosition = $("#audioTracker").val();
audio.currentTime = (newSeekPosition/100) * audio.duration;
});	
	
});
//audio player










//OPEN FILES
$("body").on("click", ".file", function(){
var collabID = $(this).attr("data-id");
var type = $(this).attr("data-type");
var file = $(this).attr("data-loc");
var fileOriginalName = $(this).attr("data-originalname");
if(type == "An audio"){
audio.src = file;
}
$(".loadedFile").remove();
$("#fileViewerSlider").slideDown(100);
$.ajax({
url: "https://troupebase.com/openFile.php",
method: "POST",
data: {
collabID: collabID,
type: type,
file: file,
fileOriginalName: fileOriginalName
},
success: function(response){
$("#formHandlerDiv").append(response);
}
});
});

	




$("#closeFileViewer").on("click", function(){
$("#fileViewerSlider").slideUp(100);
audio.pause();
$(".play").css("display", "initial");
$(".pause").css("display", "none");
});
//open files
	
	





	

	







	
/*USER PROFILES*/
	


$("body").on("mousedown", ".showTroupeProfileMenu", function(){
var id = $(this).attr("data-id");
$(".profileDropDown"+id).slideToggle(50);
});
$("body").on("mousedown", ".userProfileUserInfoContainer", function(){
if($(".profileDropDown").is(":visible")){
$(".profileDropDown").slideUp(50);
}
});


	
	






	//VIEW PROFILE

$("body").on("mousedown", ".postCommentPic", function(){
var user = $(this).attr("data-user");
if(currentPostViewType == "video" || currentPostViewType=="audio"){
$(".pausePost"+user).trigger("click");
}
if($(".discoverPausePost").is(":visible")){
$(".discoverPausePost").trigger("click");
}
});
	






	




$("body").on("touchstart mousedown", ".closeThisProfile", function(){
var user = $(this).attr("value");
$(".profileContainer"+user).animate({width: "0%"}, "500");
setTimeout(function(){
$(".profileContainer"+user).remove();
closeDivLoader();
},500);

});


function closeDivLoader(){
if($(".profileContainer").length == 0 && $(".likedContainer").length == 0 && $(".colabcon").length == 0 && $(".postViewerContainer").length == 0 && $(".collabreqreccon").length == 0 && $(".newConvoFormCon").length == 0 && $(".conversationContainer").length == 0 && $(".sfpcon").length == 0 && $(".crprevcon").length == 0 && $(".tutorialContainer").length == 0){
$("#profileLoaderContainerSlider").slideUp(50);
}
}






/*user profiles*/






	








	



	








	
//FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS

	






	

	







	


//SEND COLLAB REQUEST FUNCTION

$("body").on("click", ".scr", function(){
var troupeID = $(this).attr("data-id");
var name = $(this).attr("data-name");
var profilePic = $(this).attr("data-pic");
var talent = $(this).attr("data-talent");
var state = $(this).attr("data-state");
var troupeStatus = $(this).attr("data-troupestatus");
var privacyCR = $(this).attr("data-privacycr");
if(privacyCR == "noOne"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>User Is Not Accepting Collab Requests</p>");
showSuccess();	
return;	
}
if(privacyCR == "troupesOnly"){
if(troupeStatus !== "troupes"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>User Only Accepts Collab Requests From His/Her Troupes</p>");
showSuccess();		
return;
}
}
loadCollabForm(troupeID, name, profilePic, talent, state);
});


	

function loadCollabForm(troupeID, name, profilePic, talent, state){
$("#profileLoaderContainer").append("<div class='collabreqform'><div class='collFormCon'><div class='crf'><img src='"+profilePic+"'><br><p>Send <span style='font-weight: bold;'>"+name+"</span> A Collab Request</p><input type='text' class='crsubject' placeholder='Subject'><span class='crsublim' style='font-size: 12px;'>400</span><br><textarea placeholder='Tell "+name+" what you want to collaborate on' class='crd'></textarea><span class='crlim' style='font-size: 12px;'>400</span><div class='crbuttons'><button class='sendcr' data-id='"+troupeID+"' style='font-size: 15px; font-weight: bold;'>SEND</button><div class='confirmsendcr'>Send Collab Request? <button class='yscr' data-id='"+troupeID+"'>Yes</button></div><br><br><button class='ccr' style='color: red;'>Nevermind</button></div></div></div></div>");
	
$(".collabreqform").fadeIn("slow");
}
	
	
	


$("body").on("keyup", ".crd", function(){
var details = $(this).val();
var length = details.length;
var remaining = 400 - length;
$(".crlim").text(remaining);
if(remaining < 0){
$(".crlim").css("color", "#d42f2f");
}else{
$(".crlim").css("color", "white");
}
});
	
$("body").on("keyup", ".crsubject", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 50 - length;
	
$(".crsublim").text(remaining);
if(remaining < 0){
$(".crsublim").css("color", "#d42f2f");
}else{
$(".crsublim").css("color", "white");
}
});
	


$("body").on("click", ".sendcr", function(){
var troupeID = $(this).attr("data-id");
var details = $(".crd").val();
var length = details.length;
var remaining = 400 - length;
$(".crlim").text(remaining);
if(remaining < 0){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMIT</p>");
showSuccess();	
}else{
if(details == ""){
return;
}else{
$(".sendcr").slideUp("fast");
$(".confirmsendcr").slideDown("fast");
setTimeout(function(){
$(".sendcr").slideDown("fast");
$(".confirmsendcr").slideUp("fast");
}, 3000);
}
}
});
	


$("body").on("click", ".yscr", function(){
var troupeID = $(this).attr("data-id");
var details = $(".crd").val();
var subject = $(".crsubject").val();
var lengthSub = subject.length;
var length = details.length;
var remaining = 400 - length;
if(remaining < 0 || lengthSub < 0){
return;
}else{
sendCR(subject, details, troupeID);
}
});


function sendCR(subject, details, troupeID){
$(".crbuttons").slideUp(50);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>SENDING</p>");
showSuccess();	
$.ajax({
url: "https://troupebase.com/formHandlers/sendcollab.php",
method: "POST",
data: {
subject: subject,
details: details,
userTo: troupeID
},
success: function(response){
if(response == "success"){
$(".ccr").trigger("click");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>COLLAB REQUEST SENT!</p>");
showSuccess();
}
if(response !== "success"){
if(response == "prevnotchecked"){
$(".ccr").trigger("click");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>USER HAS NOT VIEWED YOUR PREVIOUS REQUEST YET</p>");
showSuccess();
}
else{
$(".crbuttons").slideDown(50);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SOMETHING WENT WRONG, TRY AGAIN</p>");
showSuccess();	
}
}
}
});
}


$("body").on("click", ".ccr", function(){
$(".collabreqform").fadeOut("fast");
setTimeout(function(){
$(".collabreqform").remove();
}, 300);
});
	

//send collab request function




	











//LOAD MORE COLLABS FUNCTION
function loadMoreCollabs(){
if($("#endOfCollabs").length){
}else{
$.ajax({
url: "https://troupebase.com/collabs.php",
method: "POST",
data: {
timeZone: timeZone,
collabsStart: collabsStart,
collabsLimit: collabsLimit,
collabsToLoad: collabsToLoad
},
success: function(response){
$(collabsScroller).append(response);
collabsStart += collabsLimit;
}
});
}
}
//load more collabs function
	





// LOAD MORE ACIVE MESSAGES
function loadMoreMessages(){
$.ajax({
url: "https://troupebase.com/messages.php",
method: "POST",
data: {
timeZone: timeZone,
loadMessages: 1,
boxToLoad: boxToLoad,
messagesStart: messagesStart,
messagesLimit: messagesLimit
},
success: function(response){
constructActiveMessages(response);
}
});
}
//load more active messages




//SUCCESS DROP DOWN
function showSuccess(){
$("#successResponseDropDown").slideDown(100);
setTimeout(function(){
$("#successResponseDropDown").slideUp(100);
$("#successResponseDropDown").empty();
}, 3000)
}
//success drop down


	

//LOAD MORE CONVO FUNCTION




//load more convo function





	






//REPLY TO APPLICANT
$("body").on("click", ".replyToApplicant", function(){
newMessageTo = $(this).attr("data-id");
var projectID = $(this).attr("data-projectid");
var subject = $("#projectGoalSubject"+projectID).text();
var name = $(this).attr("data-name");
$("#newMessageSubject").val(subject);
$("#sendingMessageToName").text(name);
$("#sendMessageslider").slideDown(50);
});
//

	
	



	




//GET USERS WORKED WITH


	

$("body").on("click", ".cwwt",function(){
$(".wwCon").remove();
});
	
	


$("body").on("keyup", ".searchworkedwithUser", function(){
$(".workedwithscroller").attr("data-start", "0");
$(".workedwithscroller").empty();
var user = $(this).val().replace("@", "");
var start = $(".workedwithscroller").attr("data-start");
if(user !== ""){
loadSearchWorkedWith(user,start);
}
});
	
	

	



function loadWWSC(){
var time = Date.now();
$("#profileLoaderContainerSlider").slideDown(50);
$("#profileLoaderContainer").append("<div class='wwCon'><div class='portfolioHeading' style='height: 60px; position: initial'><p style='color: white; margin:0px;'>Tag Someone You Collaborated With</p><input type='text' class='searchworkedwithUser' placeholder='Search'><button class='cwwt'>x</button></div><div class='workedwithscroller workedwithscroller"+time+"' data-start='0'></div></div>");
	
setTimeout(function(){
$(".searchworkedwithUser").focus();
}, 150);

$(".workedwithscroller"+time).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
var user = $(".searchworkedwithUser").val().replace("@", "");
var start = $(".workedwithscroller").attr("data-start");
loadSearchWorkedWith(user,start);
}
}, 150);
});
	
}
	

	





function loadSearchWorkedWith(user, start){

$.ajax({
url: "https://troupebase.com/formhandlers/workedwithsearch.php",
method: "POST",
data: {
user: user,
start: start,
isWebsite: 1
},
success: function(response){
conWorkWithSrch(response, start);
}
});	
}

	

	
	
//PROCESS TALENT TEXT
function getTalentText(talentString){
var talentText = talentString.replace(',', ''); 
talentText = talentText.replace(/,\s*$/, "");
talentText = talentText.replace(/,/g, ', ');
return talentText;
}
	

//CONSTRUCT SEARCH RESULTS
function conWorkWithSrch(response, start){
if(response == ""){
return;
}
	
var newStart = parseInt(start) + 7;
$(".workedwithscroller").attr("data-start", newStart);
			
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var user = data[i];

var talentString = getTalentText(user.talent);	
	
if($(".eachWorkedWithUsersearch"+user.troupeID).length === 0){
$(".workedwithscroller").append("<div class='troupeBox eachWorkedWithUsersearch"+user.troupeID+"'><div class='troupeBoxContent'><div class='troupePhoto addToWorkedWith' data-user='"+user.troupeID+"' data-talent='"+user.talent+"' data-name='"+user.name+"'><img style='cursor: pointer;' src='"+user.profilePic+"' id='eachWorkedWithUserSearchPhoto"+user.troupeID+"'></div><div class='troupeDetails' style='color: white; text-align: initial'><p style='margin-top: 20px; font-weight: bold;'>"+user.name+" <span class='troupeUsername"+user.troupeID+"'></span></p><p>"+talentString+", "+user.state+"</p></div></div></div>");
}	
	
	
}
}
	
	

//CLEAN TALENT STRING
function removeCommaFromTalents(string){
var talentText = "";
let talents = string;
talents = talents.split(',');
for(var t = 0; t<talents.length; t++){
var thisTalent = talents[t];
if(thisTalent !==""){
talentText = talentText+thisTalent+", ";
}
}
	talentText = talentText.replace(/,(\s+)?$/, ''); 
	return talentText;
}



//ADD COLLABED WITHED
$("body").on("click", ".addToWorkedWith",function(){
var user = $(this).attr("data-user");
var name = $(this).attr("data-name");
var talent = $(this).attr("data-talent");
var photo = document.getElementById("eachWorkedWithUserSearchPhoto"+user);
var clonePhoto = photo.cloneNode(true);
if(workedWithString.includes(user+",")){
}else{
var commas = workedWithString.split(',');
if(commas.length < 31){
workedWithString = workedWithString + user+",";
	
talent = removeCommaFromTalents(talent);
	
$(".selectedworkedwith").append("<div class='selworkedwith selworkedwith"+user+"' value='"+user+"'><div class='selworkedwithcontent'><div class='selworkwithimage selworkwithimage"+user+"'></div><div class='selworkwithdet'><span style='font-weight: bold;'>"+name+"<button class='delselworkedwith' value='"+user+"'>x</button></span><br>"+talent+"</div></div></div>");
$(".selworkwithimage"+user).append(clonePhoto);
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>30 Collabs Max</p>");
showSuccess();
}
}

$(".workedwithscroll").slideUp("fast");
$(".searchworkedwith").val("");
	
	$(".cwwt").trigger("click");
	console.log(workedWithString);
});

	


$("body").on("click", ".delselworkedwith", function(){
var user = $(this).attr("value");
var userToRemove = user+",";
workedWithString = workedWithString.replace(userToRemove, "");
$(".selworkedwith"+user).fadeOut("fast");
console.log(workedWithString);
});
	
	

//get users worked with





	








//GET USERS TO TAG

												
$("body").on("click", ".tagThisUser", function(){//SELECT USER TO TAG
var userToTag = $(this).attr("data-alias");
var troupeID = $(this).attr("data-id");
var postVCnt = $(this).attr("data-time");
//IF CREATING POST
if(postVCnt == "not"){
var postCaption = $(editablePostShare).html();
let re = new RegExp(`\\B${previousWord}\\b`, 'g');
var newCaption = postCaption.replace(re,"@"+userToTag+" ");
if(taggedString.includes(userToTag+",")){
}else{
taggedString = taggedString + userToTag+",";
$(editablePostShare).html(newCaption);
}
resetUserToTagInShare();

	
	
	
	
	
}else{
var postCaption = $(editablePostComment).text();
let re = new RegExp(`\\B${previousWord}\\b`, 'g');
var newCaption = postCaption.replace(re, "@"+userToTag+" ");	
if(postCommentTagString.includes(userToTag+",")){
}else{
postCommentTagString = postCommentTagString + userToTag+",";
$(editablePostComment).text(newCaption);
}

$(".userTagInCom").slideUp(10);

}

	
});
//


	
	

$("body").on("keyup", ".searchUserToAt", function(){
var search = $(this).val();
$(".userToAtScroller").attr("data-start", "0") 
	
$(".userToAtScroller").empty();
	
getUsersToTag(search, 0);
	
	
});

	



//CREATING POST TAGGING
function getUsersToTag(search, start){
$.ajax({
url: "https://troupebase.com/formhandlers/getuserstotag.php",
method: "POST",
data: {
user: search,
start: start,
isWebsite: 1
},
success: function(response){
constructUser("not", start, response);
}
});	

}
	
	
//COMMENT TAGGING
function getUsersToTagComment(time, search, start){
$.ajax({
url: "https://troupebase.com/formhandlers/getuserstotagcomment.php",
method: "POST",
data: {
user: search,
start: start,
isWebsite: 1
},
success: function(response){
constructUser(time, start, response);
}
});	
	
	
}

	


function constructUser(time, start, response){
if(response =="" || response == undefined){
return;
}	

var newStart = parseInt(start) + 7;	
if(time == "not"){
var container = "userToTagInShare";
}else{
var container = "userTagInCom"+time;
}
$("."+container).attr("data-start", newStart);
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var user = data[i];		
if($(".userToTag"+user.troupeID).length == 0){


$("."+container).append("<div class='troupeBox userToTag"+user.troupeID+"'><div class='troupeBoxContent'><div class='troupePhoto'><img class='tagThisUser hoverimage' src='"+user.profilePic+"' data-id='"+user.troupeID+"' data-alias='"+user.alias+"' data-time='"+time+"'></div><div class='troupeDetails userToTagDetails"+user.troupeID+"' style='text-align: initial; color: white;'><br><p>"+user.name+", "+user.state+"</p><span id='utttalent"+user.troupeID+"'>"+user.talent+"</span> </div></div></div>");

	

	
}	
}	
}

	
	







$("body").on("mousedown", ".uploadSlider", function(e){
$(".userToTagContainer ").slideUp("fast");
$(".workedwithscroll").slideUp("fast");
});

$("body").on("mousedown", ".userToTagScroll", function(e){
e.stopPropagation();
});
$("body").on("mousedown", ".workedwithscroll", function(e){
e.stopPropagation();
});



//get users to tag




//RESET POST VIEWER INPUTS	
function resetPostViewInputs(){
$(".addCommentBox").text("");
$(".submitComment").slideDown();
$(".postCommentLimit").text("Limit: 3000");
$(".userToTagContainer").slideUp();
$(".userToTagScroll").empty();
$(".userTagInCom").slideUp("fast");
postCommentTagString = ",";

}
//rest post viewer inputs





//TEXT LIMITING

	
	






//POST COMMENT




//post comment



	
//ERROR REPORT
$(".errorReportDetails").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 200 - length;
$(".errorDetailsCount").text(remaining);
if(key!== 8 && length >= 200){
$(this).blur();
}
});
//




	

//COLLAB REQUESTS AND PROJECT GOALS
$("#applyToPgMessage").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 400 - length;
$("#applyToPgMessageCounter").text(remaining);
if(key!== 8 && length >= 400){
$(this).blur();
}
});	
//






//PASSWORD RESET

$("#confirmNewPassword").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#confirmNewPasswordCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});	

$("#newPassword").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#newPasswordCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});	



$("#paswordResetEmail").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#paswordResetEmailCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});	
//




//SIGNUP AND LOGIN
	
$("body").on("keyup", ".loginPassword", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$(".loginPassCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});
	

$("body").on("keyup", ".loginEmail", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$(".loginEmailCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});


$(".signupPassword").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#signupPasswordCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});
$(".signupEmail").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#signupEmailCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});
$(".signupEmail").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#signupEmailCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});
$(".signupName").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#signupNameCount").text(remaining);
if(key!== 8 && length >= 100){
$(this).blur();
}
});
//
	
	
	

//NEW MESSAGE
$("body").on("keyup", "#newMessageSubject", function(e){
var value = $(this).val();
var length = value.length;
var remaining = 50 - length;
$("#newMessageSubjectCount").text(remaining);
if(remaining < 0){
$("#newMessageSubjectCount").css("color", "red");
}else{
$("#newMessageSubjectCount").css("color", "white");
}
});
	

$("body").on("keyup", "#newMessageBody", function(e){
var value = $(this).val();
var length = value.length;
var remaining = 400 - length;
$("#newMessageBodyCount").text(remaining);
if(remaining < 0){
$("#newMessageBodyCount").css("color", "red");
}else{
$("#newMessageBodyCount").css("color", "white");
}
});


//



	
//SETTINGS
	
	

	
$("body").on("keyup", "#desiredAlias",function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 30 - length;
$("#desiredAliasCount").text(remaining);
if(key!== 8 && length >= 30){
$(this).blur();
return;
}
$("#myLinkIs").html("troupebase.com/"+value);
if(value == ""){
$("#myAliasContainer").slideUp(50);
}else{
$("#myAliasContainer").slideDown(50);
}
});	

	


$("body").on("keyup", "#newName", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 50 - length;
$("#newNameCount").text(remaining);
if(key!== 8 && length >= 50){
$(this).blur();
}
});	



$("body").on("keyup", "#newProfileMessage", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 100 - length;
$("#aboutMeCount").text("("+remaining+")");
if(key!== 8 && length >= 100){
$(this).blur();
}
});
//





//PG FORM
$("#projectSubject").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 40 - length;
$("#subjectCount").text(remaining);
if(key!== 8 && length >= 40){
$(this).blur();
}
});
	
$("#projectDetails").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 400 - length;
$("#detailsCount").text(remaining);
if(key!== 8 && length >= 400){
$(this).blur();
}
});
//

	

	

//COLLAB
	
$("#collabDetails").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 400 - length;
$("#collabDetailsCount").text(remaining);
if(key!== 8 && length >= 400){
$(this).blur();
}
});


$("#collabSubject").on("keyup", function(e){
var key = e.keyCode;
var value = $(this).val();
var length = value.length;
var remaining = 50 - length;
$("#collabSubjectCount").text(remaining);
if(key!== 8 && length >= 50){
$(this).blur();
}
});
//

//text limiting




	










//PROCESS AUDIO function
function processAudio(){
var file = document.getElementById("fileToAddToPortfolio").files[0];
if(file == undefined){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SELECT A FILE</p>");
showSuccess();	
return;
}
	
$(".selectFileIcon").slideUp(50);
$("#progressBarStatus").text("PROCESSING AUDIO..");
$("#progressBarSlider").slideDown(50);	
$(".submitPostToPortfolio").slideUp(50);	
	
	
var formdata= new FormData();
formdata.append("audioFile", file);
formdata.append("processAudio", 1);

var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", audioProcessProgress, false);
ajax.addEventListener("load", audioUploadComplete, false);
ajax.addEventListener("error", audioProcessErrorHandler, false);
ajax.addEventListener("abort", audioProcessAbortHandler, false);
ajax.open("POST", "https://troupebase.com/userUploads/posts/upload.php");
ajax.send(formdata);	
	
	
	
}

function audioProcessProgress(e){
$("#troupebaseLogo").html(e.loaded+"/"+e.total);
var total = (e.loaded/e.total) * 100;
$("#progressBarMessageFill").css("width", total+"%");
}
function audioUploadComplete(e){
if(e.target.responseText == "success"){

	
}else{

	
}
	
	
	
setTimeout(function(){
$("#progressBarSlider").slideUp(100);	
$("#progressBarMessageFill").css("width", 0+"%");
$("#troupebaseLogo").text("troupebase");
$("#progressBarStatus").css("color", "black");
$(".selectFileIcon").slideDown(50);
},2500);
	

}
	



function audioProcessErrorHandler(e){
$("#troupebaseLogo").html("FAILED");
setTimeout(function(){
$("#progressBarSlider").slideUp(100);	
$("#progressBarMessageFill").css("width", 0+"%");
$("#troupebaseLogo").text("troupebase");
$(".selectFileIcon").slideDown(50);
},2500);
}
function audioProcessAbortHandler(e){
$("#troupebaseLogo").html("ABORTED");
setTimeout(function(){
$("#progressBarSlider").slideUp(100);	
$("#progressBarMessageFill").css("width", 0+"%");
$("#troupebaseLogo").text("troupebase");
$(".selectFileIcon").slideDown(50);
},2500);
}

//process audio function
	
	





	





//FUNCTION ADD TO PORTFOLIO
function addToPortfolio(){
var file = document.getElementById("fileToAddToPortfolio").files[0];
var details = $("#fileToAddToPortfolioDetails").val();
if(file == undefined){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SELECT A FILE</p>");
showSuccess();	
return;
}
if(details == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>COMMENTS REQUIRED</p>");
showSuccess();	
return;
}
$("#progressBarStatus").text("UPLOADING..");
$("#progressBarSlider").slideDown(50);	
$(".submitPostToPortfolio").slideUp(50);	
	
	
	
var formdata= new FormData();
formdata.append("details", details);
formdata.append("fileToAddToPortfolio", file);
formdata.append("addToPortfolio", 1);

	
var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", progressHandler, false);
ajax.addEventListener("load", completeHandler, false);
ajax.addEventListener("error", errorHandler, false);
ajax.addEventListener("abort", abortHandler, false);
ajax.open("POST", "https://troupebase.com/formHandlers/addtoportfolio.php");
ajax.send(formdata);	
	
function progressHandler(e){
$("#troupebaseLogo").text(e.loaded+"/"+e.total);
var total = (e.loaded/e.total) * 100;
$("#progressBarMessageFill").css("width", total+"%");
}
	
	
	
function completeHandler(e){
	
if(e.target.responseText == "success"){
$("#troupebaseLogo").text("troupebase");
$("#progressBarStatus").text("SUCCESS");
$(".submitPostToPortfolio").slideDown(50);
$("#fileToAddToPortfolioDetails").val("");
$("#fileToAddToPortfolio").val("");	
$(".cancelPostToPortfolio").trigger("click");
$(".viewPortfolio").trigger("click");
}else{
$("#progressBarStatus").css("color", "red")
if(e.target.responseText == "FILES CANNOT EXCEED 100MB"){
$("#progressBarStatus").text("UPLOAD EXCEEDS 100MB");
}
if(e.target.responseText == "UPLOAD FAILED PLEASE TRY AGAIN"){
$("#progressBarStatus").text("ERROR OCCURRED PLEASE TRY AGAIN");
}
if(e.target.responseText == "UPLOAD FAILED PLEASE TRY AGAIN"){
$("#progressBarStatus").text("ERROR OCCURRED PLEASE TRY AGAIN");
}
if(e.target.responseText == "FILE MAY BE CORRUPTED"){
$("#progressBarStatus").text("ERROR OCCURRED FILE MAY BE CORRUPTED");
}
if(e.target.responseText == "UNSUPPORTED FILE TYPE"){
$("#progressBarStatus").text("UNSUPPORTED FILE TYPE");
}	
	
$("#progressBarMessageFill").css("width", 0+"%");	
$(".submitPostToPortfolio").slideDown(50);
}
	
setTimeout(function(){
$("#progressBarSlider").slideUp(100);	
$("#progressBarMessageFill").css("width", 0+"%");
$("#troupebaseLogo").text("troupebase");
$("#sendCollabRequest").slideDown(100);
$("#progressBarStatus").css("color", "black")
},2500);
	
	

}
	
	


function errorHandler(e){
$("#troupebaseLogo").text("FAILED");
setTimeout(function(){
$("#progressBarSlider").slideUp(100);	
$("#progressBarMessageFill").css("width", 0+"%");
$("#troupebaseLogo").text("troupebase");
},2500);
}
function abortHandler(e){
$("#troupebaseLogo").text("ABORTED");
setTimeout(function(){
$("#progressBarSlider").slideUp(100);	
$("#progressBarMessageFill").css("width", 0+"%");
$("#troupebaseLogo").text("troupebase");
},2500);
}




	
	
	
}
//function add to portfolio

	


$("body").on("mousedown", ".noDontSendFile", function(){
if($(".pauseFileToSend").is(":visible")){
$(".pauseFileToSend").trigger("click");
}
$(".fileToSendPhotoContainer").empty();
$(".fileToSendPhotoContainer").slideUp();
$(".fileSendConfirmContainer").fadeOut();
$(".fileToSendVideoContainer").fadeOut();
$(".playFileToSend").fadeIn();
$(".pauseFileToSend").fadeOut();
$(".playPauseFileToSend").fadeOut();
$(".messageFile").val("");
$(".fileToSendAudioPreview").text("");
});
	


$("body").on("mousedown", ".sendFile", function(){
$(".messageFile").trigger("click");
});
	
	
$("body").on("change", ".messageFile", function(){
var file = $(this).val();
var ext = file.split('.').pop();
ext = ext.toLowerCase();
var size = event.target.files[0].size;
var messageFileInput = document.getElementById('messageFile');
messageFileURL = URL.createObjectURL(messageFile.files[0]);

if(size > 100000000){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>FILE CAN'T EXCEED 100 MB</p>");
showSuccess();	
}else{
	

loadFileSendPreview(file, ext, messageFileURL);
	
}
	
});
	




$("body").on("click", ".playFileToSend", function(){
$(this).slideUp(10);
$(".pauseFileToSend").slideDown(10);
if(currentFileSendType == "video"){
video.play();
}
if(currentFileSendType == "audio"){
audio.play();
}
});
$("body").on("click", ".pauseFileToSend", function(){
$(this).slideUp(10);
$(".playFileToSend").slideDown(10);
if(currentFileSendType == "video"){
video.pause();
}
if(currentFileSendType == "audio"){
audio.pause();
}
});	

	



$("body").on("click", ".yesSendThisFile", function(){
sendFileToShare();
});



//FUNCTION LOAD FILE TO SEND

function loadFileSendPreview(file, ext, messageFileURL){
	
if(ext == "jpg" || ext == "jpeg" || ext =="png" || ext =="gif"){
currentFileSendType = "photo";
$(".fileToSendPhotoContainer").append("<img src='"+messageFileURL+"'>");
$(".fileToSendPhotoContainer").fadeIn();
$(".fileSendConfirmContainer").fadeIn(200);
return;
}
	
	
if(ext == "mp4" || ext == "webm" || ext =="ogg" || ext == "mov"){
currentFileSendType = "video";
if(ext == "mov"){
ext = "mp4";
}	
$("#sendFileVideoPlayerSrc").attr("type", "video/"+ext);
$("#sendFileVideoPlayerSrc").attr("src", file);
	
video = document.getElementById("sendFileVideoPlayer");
video.src = messageFileURL;
	
$(".playPauseFileToSend").fadeIn();
$(".fileToSendVideoContainer").fadeIn();
$(".fileSendConfirmContainer").fadeIn(200);
return;
}
	
	
if(ext == "wav" || ext == "mp3" || ext =="m4a"){
currentFileSendType = "audio";
var filename = file.split(/[\\\/]/).pop();
$(".fileToSendAudioPreview").text(filename);
$(".playPauseFileToSend").fadeIn();
audio.src = messageFileURL;
$(".fileSendConfirmContainer").fadeIn(200);
return;
}
	
	
currentFileSendType = "other";
var filename = file.split(/[\\\/]/).pop();
$(".fileToSendAudioPreview").text(filename);
$(".fileSendConfirmContainer").fadeIn(200);

} 
//function load file to send





$("body").on("mousedown", ".closepgpreview",function(){
$(".pgPreview").fadeOut(500);
$(".pgPreviewHere").empty();
});
	


//COLLAB REQ PREV
$("body").on("mousedown", ".scprev",function(){
var time = Date.now();
var collabID = $(this).attr("data-collabid");
$("#profileLoaderContainerSlider").slideDown("fast");
$("#profileLoaderContainer").append("<div class='crprevcon'><div class='crPreviewHere'></div><button class='closeColabPrev'>CLOSE PREVIEW</button></div></div>");
$(".crprevcon").fadeIn();
	
$.ajax({
url: "https://troupebase.com/getcollabreqprev.php",
method: "POST",
data: {
collabID: collabID
},
success: function(response){
generateCrPreview(response);
}
});	

	
});	
	


function generateCrPreview(response){
if(response == "not found"){
return;
}
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var collab = data[i];	

	
$(".crPreviewHere").append("<div class='eachcolabcontainer eachcolabcontainer"+collab.id+"' style='text-align: initial;'><div class='crprevcontent'><img src='"+collab.profilePic+"'><p style='font-weight: bold; font-size: 11px;'><span style='font-weight: initial;'>From: </span>"+collab.name+"</p><p style='font-size: 10px;'>"+collab.talent+" "+collab.state+"</p><p style='font-size: 12px; margin-top: 5px;'>Subject: "+collab.subject+"<br>"+collab.details+"</p></div>")
	
	
}	
}
	

$("body").on("click", ".closeColabPrev", function(){
$(".crprevcon").fadeOut(300);
setTimeout(function(){
$(".crprevcon").remove();
closeDivLoader();
}, 300);
});
//collab req prev	


function generateProjectPreview(response){
$(".pgPreviewHere").empty();
$(".pgPreview").fadeIn(500);
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var project = data[i];
	

$(".pgPreviewHere").append("<div class='eachProjectGoal eachProjectGoal"+project.projectID+"'><div class='projectGoalContent projectGoalContent"+project.projectID+"' id='projectGoalContent"+project.projectID+"'><img style='margin-top: 5px;' id='projectGoalProfilePic"+project.projectID+"' class='projectGoalProfilePic projectGoalProfilePic"+project.projectID+"' src='"+project.profilePic+"'><p class='pgUserName"+project.projectID+"'>"+project.username+", "+project.userState+"</p><p class='projectGoalSubject"+project.projectID+"' id='projectGoalSubject"+project.projectID+"'>"+project.subject+"</p><p class='requiredPgTalent"+project.projectID+"' id='requiredTalent"+project.projectID+"'>For: "+project.requiredTalent+"</p><p style='font-size: 9px;' class='pgDateTime"+project.projectID+"'>"+project.dateTime+"</p><p id='projectGoalDet"+project.projectID+"' class='projectGoalDet"+project.projectID+"' style='Margin-top: 5px; white-space: pre-line; font-size: 14px;'>"+project.details+"</p></div></div>");	
	
	
	
	
}
	
	
}








$("body").on("mousedown", ".messageProjectSubject",function(){
$(".pgPreviewHere").empty();
var projectID = $(this).attr("data-projectid");
$.ajax({
url: "https://troupebase.com/getprojectpreview.php",
method: "POST",
data: {
projectID: projectID
},
success: function(response){
if(response !=="not found"){
generateProjectPreview(response);
}else{
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>PROJECT COULD NOT BE FOUND!</p>");
showSuccess();	
}
}
});	
});


//construct active messages function





	
	







	
	















	

















//CONSTRUCT TROUPE SEARCH FUNCTION
	
function constructTroupeSearch(response){
if(response == "end"){
if($("#endOfMyTroupeSearch").length == 0){
}
return;	
}

var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var troupe = data[i];
	
	
$(troupeAndRequestsScroller).append("<div class='troupeBox myTroupe"+troupe.troupeID+"' id='myTroupe"+troupe.troupeID+"'></div>");
$(".myTroupe"+troupe.troupeID).append("<div class='troupeBoxContent troupeBoxContent"+troupe.troupeID+"'></div>");
$(".troupeBoxContent"+troupe.troupeID).append("<div class='troupePhoto'><img class='viewProfile' src='"+troupe.profilePic+"' data-id='"+troupe.troupeID+"'></div>");	
$(".troupeBoxContent"+troupe.troupeID).append("<div class='troupeDetails troupeDetails"+troupe.troupeID+"'></div>");	
$(".troupeDetails"+troupe.troupeID).append("<p style='margin-top: 20px; font-weight: bold;'>"+troupe.name+" <span class='troupeUsername"+troupe.troupeID+"'></span></p>");
$(".troupeDetails"+troupe.troupeID).append("<p>"+troupe.talent+", "+troupe.state+"</p>");	
$(".troupeDetails"+troupe.troupeID).append("<p>"+troupe.about+"</p>");	
$(".troupeDetails"+troupe.troupeID).append("<a href='"+troupe.website+"' style='color: #b0c7b0; font-weight: bold;' class='websiteRedirect' style='display: none;'>"+troupe.cleanLink+"</a>");	
	
	
if(troupe.alias !== ""){
$(".troupeUsername"+troupe.troupeID).text(" ("+troupe.alias+")");
}	
	
	
}	
}

// construct troupe search function







	
	
























//COPY FUNCTION
$(".userLoggedInLink, #myLinkIs").on("mousedown", function(){
var text = $("#myLinkIs").text();
copyToClipboard(text);
});
$("#profileLoaderContainerSlider").on("mousedown", ".troupesLink", function(){
var text = $(this).attr("value");
copyToClipboard(text);
});

function copyToClipboard(text) {
	if(text == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>USER HAS NOT CHOOSEN A USERNAME</p>");
showSuccess();	
	return;
	}
    var dummy = document.createElement("textarea");
    // to avoid breaking orgain page when copying more words
    // cant copy when adding below this code
    // dummy.style.display = 'none'
    document.body.appendChild(dummy);
    //Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea"
    dummy.value = text;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
	$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>LINK COPIED!</p>");
showSuccess();	
}
//






	
	






	







	










	







	
























//TIMERS


	
	
	

	
	

	
//FUNCTION RESET POST EDITOR
function resetPostEditor(abandoned){
if(abandoned !== 1){
$("#feedHandleImg"+userLoggedIn).trigger("mousedown");
}
$("#confirmShareButton").css("background-color", "#718785");
$("#confirmShareButton").text("SHARE!");
$("#confirmShareButton").slideUp(100);
$("#fileBeingShared").empty();
$(".fileToShareCreator").remove();
$("#fileToShare").val('');
$("#selectedCoverForAudio").val('');
$("#locationSearchWrap").remove();
postUrl = "";	
postUrlAudioCover="";
postUrlVideoCover="";
videoCoverCroppieResult="";
selectedVideoFit = "cover";
postType = "";	
selectedFilter = "0";
currentPostID = "";
taggedString = ",";
workedWithString = ",";
uploadType = "";
fileToShareURL;
shareFromCroppieOrOriginal = "croppie";
shareCroppieURL = "";
partOfPortfolio = 0;
optionalLink = "";
fileToShareExt = "";
selectedCoverForAudioURL = "";
selectedCoverForAudioExt = "";
isScrollingSelectedAudio = 0;
thumbTime = 0;
shareCity = "";
shareState = "";
shareCountry = "";
audio.pause();
audio.src="";
}
// function reset post editor



	


	






//FUNCTION VIEW POST
function viewPost(response, dateTime){
var time = Date.now();	
var postArray = JSON.parse(response);	
var post = postArray[0];
var user = postArray[1];
var collabs = postArray[2];
var totalCollabs = postArray[3];
var thisVideo;
var thisAudio;
var isSeekingThis = 0;
var postDetails = post.details;	
var taggedArray = post.taggedString.split(',');

for(var t = 0; t < taggedArray.length; t++) {
var currentTag = taggedArray[t];
if(currentTag !== ""){
postDetails = postDetails.replace("@"+currentTag, "<span class='viewProfile' data-id='"+currentTag+"'>@"+currentTag+"</span>");
}
}

$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" thisPostContainer'><div class='portfolioHeading'><i class='fas fa-backspace closebuttonstopleft closePost"+time+" backarrows'></i></div><div class='postScroller postScroller"+time+"'>  </div></div>");

	

//CONTROLLS
//V	
if(post.type == "v"){
$(".postScroller"+time).append("<div class='postViewerControls postViewerControls"+time+"'><input class='videopostrange' id='videopostrange"+time+"' type='range' min='0' max='100' value='0'><img src='./assets/play.png' class='playvideopost hoverimage' id='playvideopost"+time+"' style='display: none;'><img class='pausevideopost hoverimage'  id='pausevideopost"+time+"' src='./assets/pause.png'></div>");		
}
//A
if(post.type == "a"){
$(".postScroller"+time).append("<div class='postViewerControls postViewerControls"+time+"'><input class='audiopostrange' id='audiopostrange"+time+"' type='range' min='0' max='100' value='0'><img src='./assets/play.png' class='playaudiopost hoverimage' id='playaudiopost"+time+"' style='display: none;'><img class='pauseaudiopost hoverimage'  id='pauseaudiopost"+time+"' src='./assets/pause.png'></div>");		
}
	
	
	
//PHOTO OR AUDIO
if(post.type == "p" || post.type == "a"){
$(".postScroller"+time).prepend("<img src='"+post.coverPhoto+"' class='postP filter"+post.filter+"'>");
}	
if(post.type == "p"){
$(".postViewerControls"+time).css("display", "none");
}
	

//AUDIO
if(post.type == "a"){
thisAudio = new Audio();
thisAudio.src = post.file;
thisAudio.play();

thisAudio.addEventListener('timeupdate', function(){
var currentProgress = (thisAudio.currentTime / thisAudio.duration) * 100;
if(isSeekingThis == 0){
$("#audiopostrange"+time).val(currentProgress);
}	
});
	
$("#pauseaudiopost"+time).on("click", function(){
$(this).css("display", "none");
$("#playaudiopost"+time).css("display", "initial");
thisAudio.pause();
});
$("#playaudiopost"+time).on("click", function(){
$(this).css("display", "none");
$("#pauseaudiopost"+time).css("display", "initial");
thisAudio.play();
});

}
//
	
	
//VIDEO
if(post.type == "v"){
$(".postScroller"+time).prepend("<video id='postVideoContainer"+time+"' class='postVideoContainer postVideoContainer"+time+" filter"+post.filter+"' style='object-fit: "+post.videoFit+"' playsinline><source class='postVideoContainerSrc"+time+"' type='' src=''/></video>");
	
var ext = post.file.split('.').pop();
ext = ext.toLowerCase();
if(ext == "mov"){
ext = "mp4";
}
$(".postVideoContainerSrc"+time).attr("type", "video/"+ext);
$(".postVideoContainerSrc"+time).attr("src", post.file);		
thisVideo = document.getElementById("postVideoContainer"+time);
thisVideo.addEventListener('timeupdate', function(){
var currentProgress = (thisVideo.currentTime / thisVideo.duration) * 100;
if(isSeekingThis == 0){
$("#videopostrange"+time).val(currentProgress);
}
});

thisVideo.play();
}
	
	
	
//ICONS AND DETAILS
$(".postScroller"+time).append("<div class='thispostDetails' id='thispostDetails"+time+"'></div>");
$("#thispostDetails"+time).append("<div class='thisPostIcons' id='thisPostIcons"+time+"'><img src='../assets/notliked.png' class='likepost likepost"+time+" hoverimage' id='likepost"+time+"' style='display: none;'><img src='../assets/liked.png' style='display: none;' class='unlikepost unlikepost"+time+" hoverimage ' id='unlikepost"+time+"'></div>");
$("#thispostDetails"+time).append("<div class='thisPostTotLikes' id='thisPostTotLikes"+time+"'><span style='margin-left: 75%; font-size: 14px; color: #a7c6c2; font-weight: bold; cursor: pointer;' id='viewUsersWhoLiked"+time+"'>Likes: "+post.stars+"</span></div>");
$("#thispostDetails"+time).append("<div class='thispostcaption' id='thispostcaption"+time+"' style='color: white;'><span class='viewProfile' data-id='"+user.id+"'>"+user.name+"</span> - "+postDetails+"<br><span style='font-size: 10px;'>"+dateTime+"</span></div>");
	
//COLLABORATIONS POST VIEW
$("#thispostDetails"+time).append("<div class='postCollaborators' id='postCollaborators"+time+"'>Collabed With:<div class='postCollaboratorsList' id='postCollaboratorsList"+time+"' data-start='0'></div></div>");	
	
for(var c = 0; c < collabs.length; c++) {
var collabedUser = collabs[c];
$("#postCollaboratorsList"+time).append('<div class="selworkedwith"><div class="selworkedwithcontent"><div class="selworkwithimage"><img class= "viewProfile" data-id="'+collabedUser.id+'" style="cursor: pointer;" src="'+collabedUser.profilePic+'"></div><div class="selworkwithdet"><span style="font-weight: bold;">'+collabedUser.name+', '+collabedUser.state+'</span><br>'+collabedUser.talentString+'</div></div></div>');	
}
if(totalCollabs > 0){
$("#postCollaboratorsList"+time).append("<br><button class='vAllC' id='vAllC"+time+"'>View All Collabs</button>")
}
 
	
//VIEW ALL COLLABS
$("#vAllC"+time).on("click", function(){	
var postID = post.id;
loadAllCollaborators(postID);
});



//COMMENT
$("#thispostDetails"+time).append("<br><div class='postCommentContainer postCommentContainer"+time+"'><div placeholder= 'COMMENT' class='addCommentBox addCommentBox"+time+"' id='addCommentBox"+time+"' data-time='"+time+"' data-postid='"+post.id+"' data-placeholder='COMMENT' contenteditable='true'></div></div>");
	
$("#thispostDetails"+time).append("<div class='userTagInCom userTagInCom"+time+"' data-time = '"+time+"' data-start='0'></div><button class='submitCommentButton' id='submitCommentButton"+time+"'>SUBMIT</button>");
	
//CONFIRM COMMENT SLIDE DOWN
$("#thispostDetails"+time).append("<div class='confirmCommentContainer' id='confirmCommentContainer"+time+"'><span style='margin-left: 30px; font-size: 18px;'>CONFIRM COMMENT?</span> <button class='confirmComment' id='confirmComment"+time+"' style='color: #214844;'>YES</button></div>");	


//COMMENT SCROLLER 
$("#thispostDetails"+time).append("<div class='commentsScroll' id='commentsScroll"+time+"' data-start = '0'></div>");
loadComments(time, post.id, 0);
	
$("#commentsScroll"+time).on("scroll", function(){
var commentStart = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
loadComments(time, post.id, commentStart);
}
}, 150);
});



document.getElementById("addCommentBox"+time).addEventListener("focus", function() {
var time = $(this).attr("data-time");
getEditablePostComment(time);
});

	
//CONFIRM THE COMMENT POST
document.getElementById("confirmComment"+time).addEventListener("click", function() {
$("#confirmCommentContainer"+time).slideUp(10);
if(clickDelay == 0){
clickDelay = 1;
var postID = post.id;
var postComment = $("#addCommentBox"+time).text();
var type = post.type;
var postBy = post.user;
postComment = postComment.replace(/<div>/gm,"<br>");
postComment = postComment.replace(/<\/div>/gm,"");
if(postComment.length > 3000){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>CHECK CHARACTER LIMIT</p>");
showSuccess();
	return;
}
if(postComment == ""){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>WRITE A COMMENT</p>");
showSuccess();
clickDelay = 0;
return;
}
var postComment = addNewComment(postID, postComment, postCommentTagString, type, postBy, time).then(function(addcommentresponse){
resetPostViewInputs(); 
if(addcommentresponse == "error"){
	alert("error");
clickDelay = 0;
somethingwentwrong();
return;
}

var commentObj = JSON.parse(addcommentresponse);	
$("#commentsScroll"+time).prepend('<div class="eachComment" id="eachComment'+commentObj.date+'"><div class="eachCommentUserInfo"><img src="'+userLoggedInProfilePic+'"> <span style="font-weight: bold; font-size: 13px;">'+userLoggedInName+',  '+userLoggedInTalents+'</span></div><div class="eachCommentBody"><span>'+commentObj.comment+'</span><br><span style="font-size: 11px;">'+commentObj.dateTime+'</span><div class="commentButtons"><button style="color: red;" class="undoComment" id="deleteComment'+commentObj.date+'" data-datetime="'+commentObj.date+'">UNDO COMMENT</button></div></div> </div>');
	
	

	
	
}).catch(function(addcommentresponse){

});
}
});



//SHOW THE COMMENT CONFIRM
document.getElementById("submitCommentButton"+time).addEventListener("click", function() {
$(this).slideUp(10);
$("#confirmCommentContainer"+time).slideDown(10);
setTimeout(function(){
$("#submitCommentButton"+time).slideDown(10);
$("#confirmCommentContainer"+time).slideUp(10);
}, 3000);
});


//VIEW LIKED USER
document.getElementById("viewUsersWhoLiked"+time).addEventListener("mousedown", function() {
if(clickDelay == 0){
clickDelay = 1;
$("#profileLoaderContainer").append("<div class='likedContainer likedContainer"+time+"'><div class='likedConHead'><div class='closelikedcon' value='"+time+"'><i class='fas fa-backspace backarrows'></i></div>LIKED BY</div><div class='likedscroll likedscroll"+time+"' id='likedscroll"+time+"' data-postid='"+post.id+"' data-start='0' data-scrollnumber='"+time+"'></div></div>");
$(".likedContainer"+time).animate({width: "100%"});

$("#likedscroll"+time).on("scroll", function(){
alert("now");
});
	
getlikedusers(post.id, time, 0);
}
});



//LIKE UNLINE
$("#unlikepost"+time).on("click", function(){
$(this).css("display", "none");
$("#likepost"+time).css("display", "initial");
addRemoveLike(post.id, "unlike");
});
$("#likepost"+time).on("click", function(){
$(this).css("display", "none");
$("#unlikepost"+time).css("display", "initial");
addRemoveLike(post.id, "like");
});


////SEEK
$("#videopostrange"+time).on("input", function(){
isSeekingThis = 1;
var value = $(this).val();
value = Math.round(value);
thisVideo.currentTime = thisVideo.duration * (value/100);
});
$("#videopostrange"+time).on("mouseup touchend", function(){
isSeekingThis = 0;
});
$("#audiopostrange"+time).on("input", function(){
isSeekingThis = 1;
var value = $(this).val();
value = Math.round(value);
thisAudio.currentTime = thisAudio.duration * (value/100);
});
$("#audiopostrange"+time).on("mouseup touchend", function(){
isSeekingThis = 0;
});
	
//PLAY PAUSE VIDEO
$("#pausevideopost"+time).on("click", function(){
$(this).css("display", "none");
$("#playvideopost"+time).css("display", "initial");
thisVideo.pause();
});
$("#playvideopost"+time).on("click", function(){
$(this).css("display", "none");
$("#pausevideopost"+time).css("display", "initial");
thisVideo.play();
});
	
	
//CLOSE POST
$(".closePost"+time).on("click", function(){
resetPostViewInputs();
$(".universalcontainer"+time).stop().animate({width: "0%"}, "fast", "linear");
setTimeout(function(){
$(".universalcontainer"+time).remove();
}, 300);
if(thisAudio.play){
thisAudio.src = "";
}
});
	
$(".universalcontainer"+time).stop().animate({width: "100%"}, "fast", "linear");
clickDelay = 0;
	
checklike(post.user, post.id, time);

//GET USER
var getPostedBy = getUser(post.user).then(function(postedByResponse){
var postedByJson = JSON.parse(postedByResponse);
var postedBy = postedByJson[0];
$("#thispostcaption"+time).prepend("<img src='"+postedBy.profilePic+"'> <span style='font-weight: bold; margin-bottom: 4px;'>"+postedBy.name+"</span> -");
}).catch(function(){

});



}
	
// function view post
	
	


	


//FUNCTION GET ALL COLLABORATORS
function loadAllCollaborators(postID)
{
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" allCollaboratorsContainer' id='allCollaboratorsContainer' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' id='closeCollaborations"+time+"'></i><span class='cps'>Collaborations</span></div><div class='scrollingContainer' id='collaborationsScroller"+time+"' data-start = '0'></div></div>");	
var start = $("#collaborationsScroller"+time).attr("data-start");
	
	

	
	
//GET COLLABORATORS
getAllCollaborators(postID, time, start).then(function(response){
if(response == "end"){
return;
}
	
var newStart = parseInt(start) + 10;
$("#collaborationsScroller"+time).attr("data-start", newStart);	
	
var container = document.getElementById("collaborationsScroller"+time);
constructUserGeneral(container, response);
	
	
}).catch(function(response){
});
$("#closeCollaborations"+time).on("click", function(){
close(time);
});
}
	

	
//THIS IS THE GENERAL USER CONTAINER
function constructUserGeneral(container, response)
{

var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){	
var user = data[i];	
var talentString = user[1];

if(user.user.profilePic == ""){
user.user.profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}	
	
$(container).append("<div class='generalUserContainer'><div class='generalUserConProfilePic'><img src='"+user.user.profilePic+"'></div><div class='generalUserConInfo'><p style='font-weight: bold;'>"+user.user.name+"</p><p>"+user.talentString+", "+user.user.state+"</p></div></div>");
	
}
	
	

}




function getAllCollaborators(postID, time, start){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/getcollaborations.php",
method: "POST",
data: {
postID: postID,
start: start,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
if (response !== "error")
resolve(response);
else
reject(response);
}
});

});
}



//







	
//FUNCTION ADD COMMENT
function addNewComment(postID, postComment, postCommentTagString, type, postBy, time){
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/addcomment.php",
method: "POST",
data: {
postID: postID,
postComment: postComment,
postCommentTagString: postCommentTagString,
type: type,
postBy: postBy,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
if (response !== "error")
resolve(response);
else
reject(response);
}
});

});

}



	

//GET USERS WHO LIKED POST
function getlikedusers(postID, time, start){
$.ajax({
url: "https://troupebase.com/formhandlers/getlikedusers.php",
method: "POST",
data: {
postID: postID,
start: start,
isWebsite: 1
},
success: function(response){
conLikedUsers(response, postID, start, time);
}
});
}





	
//GET USER FUNCTION
function getUser(user) {
 return new Promise(function (resolve,reject) { 
 $.ajax({
url: "https://troupebase.com/formhandlers/getuser.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
if (response !== "error")
resolve(response);
else
reject("It is a failure.");
}
});

});
}

	


function checklike(user, postID, time){
var liked = 0;
$.ajax({
url: "https://troupebase.com/formhandlers/checklike.php",
method: "POST",
data: {
like: 1,
postID: postID,
user: user,
isWebsite: 1
},
success: function(response){
if(response == 0){
$(".likepost"+time).css("display", "initial");
}else{
$(".unlikepost"+time).css("display", "initial");
}
}
});

}




//ADD LIKE
function addRemoveLike(postID, likeOrUnlike)
{
$.ajax({
url: "https://troupebase.com/formhandlers/like.php",
method: "POST",
data: {
like: 1,
postID: postID,
likeOrUnlike: likeOrUnlike,
isWebsite: 1
}
});	
}





	
//FUNCTION LOAD AUDIO
function loadAudio(postVCnt, file){

mediaSeeker = document.getElementsByClassName('mediaProgressContainer'+postVCnt);
audio.addEventListener('timeupdate', function(){
var currentProgress = (audio.currentTime / audio.duration) * 100;
mediaSeeker.value = currentProgress;
if(isSeeking == 0){
$(".mediaSeeker").val(currentProgress);
}
});

audio.src = file;
audio.play();
}
//function load audio

	


//FUNCTION LOAD VIDEO

function loadVideo(time, file){
video = document.getElementById("postVideoContainer"+time);
video.addEventListener('timeupdate', function(){
var currentProgress = (video.currentTime / video.duration) * 100;
});

video.play();
	
}
//
	

	
	












	






//SHARE FILE FUNCTION
function sendFileToShare(){
$("#progressBarStatus").text("Please wait..");
$("#progressBarSlider").slideDown(50);	
$(".postCreatorNext").slideUp(50);	
$(".postCaptionContainer").slideUp(50);

var file = document.getElementById("messageFile").files[0];
var formdata = new FormData();	
var currentConvo = $(".conversationContainer").attr("data-currentconvo");
	
	
formdata.append("file", file);
formdata.append("currentConvo", currentConvo);
formdata.append("share", 1);	

	
$(".noDontSendFile").trigger("mousedown");		
	
var ajax = new XMLHttpRequest();
	
ajax.upload.addEventListener("progress", fileShareProgress, false);
ajax.addEventListener("load", fileShareComplete, false);

ajax.open("POST", "https://troupebase.com/shared/share.php");
ajax.send(formdata);	
	
}

	
function fileShareProgress(e){
$("#troupebaseLogo").text(e.loaded+"/"+e.total);
var total = (e.loaded/e.total) * 100;
$("#progressBarMessageFill").css("width", total+"%");
}	

function fileShareComplete(e){
console.log(e.target.responseText); 
$("#progressBarSlider").slideUp(50);
$("#troupebaseLogo").text("Homebase");
if(e.target.responseText == "error"){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green'>SOMETHING WENT WRONG, TRY AGAIN</p>");
showSuccess();	
}
}
//share file function
	
	





//UPLOAD VIDEO FUNCTION
function uploadVideo(selectedVideoFit, postComment, videoCoverCroppieResult){

	
var tagsCheck =taggedString.split(',');
for(i=0; i<tagsCheck.length - 1; i++){
var currentTag = tagsCheck[i];
if(postComment.includes("@"+currentTag)){
}else{
taggedString = taggedString.replace(currentTag+",", "");
}
}
	
	

	
	
$("#progressBarStatus").text("Please wait..");
$("#progressBarSlider").slideDown(50);	
$(".postCreatorNext").slideUp(50);	
$(".postCaptionContainer").slideUp(50);
	
var videoFile = document.getElementById("fileToAddToPortfolio").files[0];
var formdata = new FormData();
	
formdata.append("videoFile", videoFile);
formdata.append("videoFit", selectedVideoFit);	
formdata.append("videoCover", videoCoverCroppieResult);
formdata.append("caption", postComment);
formdata.append("filter", selectedFilter);
formdata.append("selectedVideoFit", selectedVideoFit);
formdata.append("insertVideoPost", 1);	
formdata.append("taggedString", taggedString);		
formdata.append("insertTagNote", 1);
	
	
var ajax = new XMLHttpRequest();
ajax.upload.addEventListener("progress", selVidProgress, false);
ajax.addEventListener("load", selvidComplete, false);

ajax.open("POST", "https://troupebase.com/userUploads/posts/upload.php");
ajax.send(formdata);		
	
	
}

function selVidProgress(e){
$("#troupebaseLogo").text(e.loaded+"/"+e.total);
var total = (e.loaded/e.total) * 100;
$("#progressBarMessageFill").css("width", total+"%");
}
	


function selvidComplete(e){
alert(e.target.responseText);
if(e.target.responseText == "error"){
$("#progressBarSlider").slideUp(50);	
$(".postCreatorNext").slideDown(50);	
$(".postCaptionContainer").slideDown(50);
}

if(e.target.responseText == "success"){
$("#progressBarSlider").slideUp(50);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green;'>POST COMPLETE</p>");
showSuccess();
$(".uploadSlider").slideUp(50);
resetPostEditor();
}	
	
	
}
//upload video funtion

	











//ADD AUDIO
function selAudioProg(e){
var total = (e.loaded/e.total) * 100;
$("#troupebaseLogo").text(total);
$("#progressBarMessageFill").css("width", total+"%");
}
	
function selAudioComplete(e){
if(e.target.responseText == "success"){	
$("#progressBarSlider").slideUp(50);
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: green;'>POST COMPLETE</p>");
showSuccess();
$(".uploadSlider").slideUp(50);
resetPostEditor();
}
	
	
	
	
	
	
}
//add audio to server
	




	


//FUNCTION DOUBLE CHECK TAGS
function doubleTagCheck(){
return;
}
//function double check tags



	







	
	

	



	





//GET COMMENTS
function loadComments(time, postID, start){

$.ajax({
url: "https://troupebase.com/formhandlers/loadpostcomments.php",
method: "POST",
data: {
postID: postID,
start: start,
isWebsite: 1
},
success: function(response){
constructComments(response, start, time);
}
});		
}







//CONSTRUCT COMMENTS FUNCTION
function constructComments(response, start, time){
if(response == "end"){
if($(".endOfPostComments"+time).length == 0){
$("#commentsScroll"+time).append("<div class='endOfPostComments"+time+"' style='width: 100%; text-align: center;'>End of Comments</div>");
}
return;
}

var newStart = parseInt(start) + 10;
$("#commentsScroll"+time).attr("data-start", newStart);
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var comment = data[i];	

var commentBody = comment.comment;
var taggedString = comment.tagged;

if(taggedString !== ""){	
var tagsCheck = taggedString.split(',');
for(var x = 0; x < tagsCheck.length - 1; x++){
var currentTag = tagsCheck[x];
if(currentTag !== ""){
if(commentBody.includes("@"+currentTag)){
commentBody = commentBody.replace("@"+currentTag, "<span class='viewProfile' data-id='"+currentTag+"' style='background-color: transparent; color: #abccc9; border: none;'>@"+currentTag+"</span>");
}
}
}
}

	
$("#commentsScroll"+time).append("<div class='eachComment' id='eachComment"+comment.id+"'><div class='eachCommentUserInfo'><img src='"+comment.profilePic+"' class='viewProfile' data-id='"+comment.user+"'> <span style='font-weight: bold; font-size: 13px;'>"+comment.name+", "+comment.talents+"</span></div><div class='eachCommentBody'><span>"+commentBody+"</span><br><img src='../assets/reply.png' class='replyToComment' id='replyToComment"+comment.id+"' data-id='"+comment.id+"' data-postid='"+comment.postID+"' data-profilepic='"+comment.profilePic+"' data-user='"+comment.user+"' data-talentstring='"+comment.talents+"'><br><span style='font-size: 11px;'>"+comment.dateTime+"</span><div class='commentButtons'><button style='color: red;' id='deleteComment"+comment.id+"' data-id='"+comment.id+"'>Delete</button><button style='color: red;' id='reportComment"+comment.id+"' data-id='"+comment.id+"'>Report</button></div></div> </div>");
	



if(userLoggedIn !== comment.user){
$("#deleteComment"+comment.id).remove();
}
	
//SUBMIT DELETE
$("#deleteComment"+comment.id).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var commentID = $(this).attr("data-id");
$("#eachComment"+commentID).css("background-color","#214844");
loadDelCommCont(commentID);
}
});	
	
	
//SUBMIT REPORT
$("#reportComment"+comment.id).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var commentID = $(this).attr("data-id");
$("#eachComment"+commentID).css("background-color","#214844");
loadRepCommCont(commentID);
}
});		
	

	
	
	
}
}
//construct comments function

	
	

//LOAD COMMENT REPLY CONTAINER
$("body").on("click", ".replyToComment",function(){
var commentID = $(this).attr("data-id");
var postID = $(this).attr("data-postid");
var user = $(this).attr("data-user");
var talentString = $(this).attr("data-talentstring");
loadCommentReplies(commentID, talentString, postID, user);
});
	

	
//VIEW PROFILE FUNCTION
$("body").on("click", ".viewProfile", function(){
var user = $(this).attr("data-id");
let TroupeBaseID = localStorage.getItem('TroupeBaseID');
if(user !== TroupeBaseID){
getProfile(user);
}
});

function getProfile(user){
if(user == userLoggedIn || userLoggedInAlias == user){
return;
}
$.ajax({
url: "https://troupebase.com/formhandlers/getprofile.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
constructProfile(response);
}
});
}

	



//LOAD APPROPRIATE TROUPE REQUEST OPTIONS
function loadAppropriateTRoptions(status, user){
$("#troupeRequestOptionsDiv"+user).empty();
if(status == "none"){
$("#troupeStatusSelector"+user).val("");
$("#troupeStatusSelector"+user).css("border", "none");
$("#troupeStatusSelector"+user).css("color", "black");
$("#troupeRequestOptionsDiv"+user).append("<div class='trSelOptions' id='sendtrouperequest"+user+"' data-user='"+user+"' data-action = 'sendtrouperequest' style='color: #214844; font-weight: bold; background-color: #427570; color: white; height: 35px;'>SEND TROUPE REQUEST</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #d3a7a7; color: white;' data-user='"+user+"' data-action = 'block'>BLOCK</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #da9999; color: white;' data-action='report'>REPORT</div>");
}
if(status == "sent"){

$("#troupeStatusSelector"+user).val("troupeReqSent");
$("#troupeStatusSelector"+user).css("border", "2px solid #c06767");
$("#troupeStatusSelector"+user).css("color", "#c06767");
$("#troupeRequestOptionsDiv"+user).append("<div class='trSelOptions' data-user='"+user+"' data-action = 'cancelTroupeRequest' style='color: #214844; font-weight: bold; background-color: white; color: red; height: 35px;'>CANCEL TROUPE REQUEST</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #d3a7a7; color: white;' data-user='"+user+"' data-action = 'block'>BLOCK</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #da9999; color: white;' data-action='report'>REPORT</div>");
}	
if(status == "received"){
$("#troupeStatusSelector"+user).val("troupeReqRec");
$("#troupeStatusSelector"+user).css("border", "2px solid #c06767");
$("#troupeStatusSelector"+user).css("color", "#c06767");
$("#troupeRequestOptionsDiv"+user).append("<div class='trSelOptions' data-user='"+user+"' data-action='accepttrouperequest' style='color: #214844; font-weight: bold; background-color: #427570; color: white; height: 35px;'>ACCEPT TROUPE REQUEST</div><div class='trSelOptions' data-user='"+user+"' data-action = 'denyTroupeRequest' style='color: #214844; font-weight: bold; background-color: white; color: red; height: 32px;' data-user='"+user+"'>DENY TROUPE REQUEST</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #d3a7a7; color: white;' data-user='"+user+"' data-action = 'block'>BLOCK</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #da9999; color: white;' data-action='report'>REPORT</div>");
}
if(status == "troupes"){
$("#troupeStatusSelector"+user).val("troupes");
$("#troupeStatusSelector"+user).css("border", "2px solid #6c8c89");
$("#troupeStatusSelector"+user).css("color", "#6c8c89");
$("#troupeRequestOptionsDiv"+user).append("<div class='trSelOptions' data-user='"+user+"' data-action='deleteThisTroupe' style='color: red; font-weight: bold; background-color: white; height: 35px;'>REMOVE TROUPE</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #d3a7a7; color: white;' data-user='"+user+"' data-action = 'block'>BLOCK</div><div class='trSelOptions' style='color: #214844; font-weight: bold; background-color: #da9999; color: white;' data-action='report'>REPORT</div>");
}	

	
}
	
	


//TROUPE REQUEST BUTTONS
$("body").on("click", ".trSelOptions", function(){
if(clickDelay == 0){
clickDelay = 1;
$(".troupeRequestOptionsDiv").slideUp("fast");
var action = $(this).attr("data-action");
var user = $(this).attr("data-user");
var element = document.getElementById("#troupeStatusSelector"+user);	
var elementToRemove = this;
//SEND TROUPE REQUEST
if(action == "sendtrouperequest"){
$("#troupeStatusSelector"+user).val("sendingTroupeRequest");
sendTroupeRequest(user).then(function(response){
clickDelay = 0;
if(response == "sent"){
$("#troupeStatusSelector"+user).val("troupeReqSent");
loadAppropriateTRoptions("sent", user);
}
	
}).catch(function(response){
});
}
//
//CANCEL TROUPE REQUEST
if(action == "cancelTroupeRequest"){
$("#troupeStatusSelector"+user).val("cancelingTroupeRequest");
cancelTroupeRequest(user).then(function(response){
clickDelay = 0;

if(response == "success"){
loadAppropriateTRoptions("none", user);
}
	
}).catch(function(response){
});
}
//		
	

//DENY
if(action == "denyTroupeRequest"){
$("#troupeStatusSelector"+user).val("denyingTroupeRequest");
denyTroupeRequest(user).then(function(response){
clickDelay = 0;
if(response == "success"){
loadAppropriateTRoptions("none", user);
}
	
}).catch(function(response){
});
}	
	
	

//ACCEPT
if(action == "accepttrouperequest"){
$("#troupeStatusSelector"+user).val("denyingTroupeRequest");
acceptTroupeRequest(user).then(function(response){
clickDelay = 0;
if(response == "success"){
loadAppropriateTRoptions("troupes", user);
}
	
}).catch(function(response){
});
}
	


//DELETE TROUPE
if(action == "deleteThisTroupe"){
$("#troupeStatusSelector"+user).val("denyingTroupeRequest");
deleteTroupe(user).then(function(response){
clickDelay = 0;
	alert(response);
if(response == "success"){
loadAppropriateTRoptions("none", user);
}
	
}).catch(function(response){
});
}



//BLOCK
if(action == "block"){
blockTroupe(user);
}


	
}
});

	
	

	

//BLOCK TROUPE
function blockTroupe(user){
$.ajax({
url: "https://troupebase.com/formhandlers/getuserwithtalent.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
loadusertoblock(response);
}
});
}

	
function loadusertoblock(response)
{
var data = JSON.parse(response);
var user = data[0];
var talentString = data[1];
var time = Date.now();
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough confirmcontainer' style='width: 100%;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' data-time='"+time+"'></i></div><div class='postScroller' id='postScroller"+time+"' style='color: white; text-align: initial;'><br><div class='generalUserContainer'><div class='generalUserConProfilePic'><img src='"+user.profilePic+"'></div><div class='generalUserConInfo'><p style='font-weight: bold;'>"+user.name+"</p><p>"+talentString+", "+user.state+"</p><span style='font-weight: bold;'>CONFIRM BLOCK?</span><br><button id='confirmBlock' style='color: green;' data-user='"+user.id+"'>YES</button><button id='abandonBlock' style='color: red;'>NO</button></div></div></div></div>");

//CONFIRM BLOCK
$("#confirmBlock").on("click", function(){
clickDelay = 1;
var user = $(this).attr("data-user");
confirmBlock(user).then(function(response){

if(response == "success"){
close(time);
showAlert("USER BLOCKED", "green");
if($("#profile"+user).length > 0){
setTimeout(function(){
$("#profile"+user).stop().animate({width: "0%"}, "fast", "linear");
removeAlert();
}, 2000);
setTimeout(function(){
$("#profile"+user).remove();
}, 4000);
}
}
	
}).catch(function(response){
});
});
//ABANDON BLOCK
$("#abandonBlock").on("click", function(){
close(time);
});

	
}
	

function confirmBlock(user){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/blocktroupe.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
resolve(response);	
}
});
	
	

});

}





////DELETE TROUPE 
function deleteTroupe(user){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/deletetroupe.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
resolve(response);	
}
});
	
	

});
}
	




//ACCEPT TROUPE REQUEST
function acceptTroupeRequest(user){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/accepttrouperequest.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
resolve(response);	
}
});
	
	

});
}
	
	

//DENT TROUPE REQUEST
function denyTroupeRequest(user){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/denytrouperequest.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
resolve(response);	
}
});
	
	

});
}
	
	



//CANCEL TROUPE REQUEST
function cancelTroupeRequest(user)
{
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/canceltrouperequest.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
resolve(response);	
}
});
	
	

});
}


//SEND TROUPE REQUEST
function sendTroupeRequest(user){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/sendtrouperequest.php",
method: "POST",
data: {
user: user,
isWebsite: 1
},
success: function(response){
resolve(response);	
}
});
	
	

});
}


	



//CONSTRUCT PROFILE
function constructProfile(response)
{
console.log(response);
var time = Date.now();
if(response == "end"){
return;
}	
	
var data = JSON.parse(response);
var user = data[0];
var talentString = data[1];
var ib = data[3];
if(ib == 1){
showAlert("UNBLOCK THIS USER FIRST", "red");
return;
}
var db = data[4];
if(db == 1){
showAlert("USER NOT FOUND", "red");
return;
}
var profilePic = user.profilePic;
if(profilePic == ""){
profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}
	
var name = user.name;
	if(user.alias !== ""){
	name = user.name + " @"+user.alias;
	}

$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+"' id='profile"+user.id+"' style='background-color: black;'><div class='profileContainer'><div class='profileContainerTopBar'><i class='fas fa-backspace backarrows' id='closeProfile"+time+"'></i></div><div class='profileScroll' id='profileScroll"+time+"'></div></div></div>");
	
//ICONS
$("#profileScroll"+time).append("<div class='feedUpperX' id='feedUpperX"+user.id+"'></div><div id='notificationContainer' style='margin-top: 3px;'><img src='https://troupebase.com/assets/troupesicon.png' id = 'troupesIcon' style='background-color: White;' data-user='"+user.id+"'><img src='https://troupebase.com/assets/collabsicon.png' class='vcr ncricon'><img src='https://troupebase.com/assets/newMessageIcon.png' value='messages'></div>");
	
	




//PROFILE PIC
$("#profileScroll"+time).append("<div id='profileProfilePic"+user.id+"' style='width: 100%; text-align: center;'><img src='"+profilePic+"' id='featuredTroupePhoto' class='userLoggedInPhoto userLoggedInLink thisUsersPic"+user.id+" filter"+user.photoFilter+"'></div>");
	
	






//TROUPE STATUS SELECTOR
$("#profileScroll"+time).append("<div class='troupeStatusSelectorCon' id='troupeStatusSelectorCon"+user.id+"' style='width: 100%; text-align: center;'><select class='troupeStatusSelector' id='troupeStatusSelector"+user.id+"'><option value=''>Troupe Request</option><option value='cancelingTroupeRequest'>Canceling..</option><option value='denyingTroupeRequest'>Please wait..</option><option value='sendingTroupeRequest'>Sending Request..</option><option value='troupeReqSent'>Troupe Request Sent</option><option value='troupeReqRec'>Troupe Request Received</option><option value='troupes'>You Are Troupes</option></select><div class='troupeRequestOptionsDiv' id='troupeRequestOptionsDiv"+user.id+"'></div></div>");
var element = document.getElementById("troupeRequestOptionsDiv"+user.id)
loadAppropriateTRoptions(data[2], user.id);
if(user.privacyTR == "noOne"){
$("#sendtrouperequest"+user.id).remove();
}
$("#troupeStatusSelector"+user.id).on("mousedown", function(e){
e.preventDefault();
this.blur();
window.focus();
if($("#troupeRequestOptionsDiv"+user.id).is(":visible")){
$("#troupeRequestOptionsDiv"+user.id).slideUp("fast");
}else{
$("#troupeRequestOptionsDiv"+user.id).slideDown("fast");
}
});







	
	
	
	//PROFILE DETAILS
$("#profileScroll"+time).append("<div id='profileDetails' style='width: 100%; text-align: center;'><p id='currentName'><span class='thisusersname"+user.id+"'>"+name+"</span></p><p style='font-size: 17px;' id='userLoggedInTalents'></p><p id='currentProfileMessage'>"+user.projectGoal+"</p><a href='"+user.website+"' style='color: #b0c7b0; font-weight: bold;' class='websiteRedirect' id='currentWebsite'>"+user.website+"</a></div>");	

//SM LINKS
$("#profileScroll"+time).append("<div id='smLinks'><img src='assets/smIcons/facebook.png' id='facebookIcon"+user.id+"' class='myfblink smRedirect' value=''><img src='assets/smIcons/ig.png' id='instagramIcon"+user.id+"' class='myiglink smRedirect' value=''><img src='assets/smIcons/appleMusic.png' id='applemusicIcon"+user.id+"' class='myapplemusiclink smRedirect' value=''><img src='assets/smIcons/amazon.png' id='amazonIcon"+user.id+"' class='myamazonlink smRedirect' value=''><img src='assets/smIcons/spotify.png' id='spotifyIcon"+user.id+"' class='myspotifylink smRedirect' value=''><img src='assets/smIcons/youtube.png' id='youtubeIcon"+user.id+"' class='myyoutubelink smRedirect' value=''><img src='assets/smIcons/tidal.png' id='tidalIcon"+user.id+"' class='mytidallink smRedirect' value=''><img src='assets/smIcons/twitch.png' id='twitchIcon"+user.id+"' class='mytwitchlink smRedirect' value=''><img src='assets/smIcons/tiktok.png' id='tiktokIcon"+user.id+"' class='mytiktoklink smRedirect' value=''><img src='assets/smIcons/soundcloud.png' id='soundcloudIcon"+user.id+"' class='mysoundcloudlink smRedirect' value=''></div>");	
	
var smLinks = user.smLinks.split(',');
for(var i = 0; i < smLinks.length; i++) {
var thisLink = smLinks[i];		
	
if(thisLink.includes("facebook=")){//fb
var link = thisLink.replace("facebook=", "");
$("#facebookIcon"+user.id).attr("value", link);
$("#facebookIcon"+user.id).css('display', 'initial');
}
	
if(thisLink.includes("instagram=")){//ig
var link = thisLink.replace("instagram=", "");
$("#instagramIcon"+user.id).attr("value", link);
$("#instagramIcon"+user.id).css('display', 'initial');
}	
	
	
if(thisLink.includes("applemusic=")){//applemusic
var link = thisLink.replace("applemusic=", "");
$("#applemusicIcon"+user.id).attr("value", link);
$("#applemusicIcon"+user.id).css('display', 'initial');
}	
	
	
if(thisLink.includes("amazon=")){//amazon
var link = thisLink.replace("amazon=", "");
$("#amazonIcon"+user.id).attr("value", link);
$("#amazonIcon"+user.id).css('display', 'initial');
}
	
	
if(thisLink.includes("spotify=")){//spotify
var link = thisLink.replace("spotify=", "");
$("#spotifyIcon"+user.id).attr("value", link);
$("#spotifyIcon"+user.id).css('display', 'initial');
}
	
	

if(thisLink.includes("youtube=")){//youtube
var link = thisLink.replace("youtube=", "");
$("#youtubeIcon"+user.id).attr("value", link);
$("#youtubeIcon"+user.id).css('display', 'initial');
}

	

if(thisLink.includes("tidal=")){//tidal
var link = thisLink.replace("tidal=", "");
$("#tidalIcon"+user.id).attr("value", link);
$("#tidalIcon"+user.id).css('display', 'initial');
}

	
if(thisLink.includes("twitch=")){//twitch
var link = thisLink.replace("twitch=", "");
$("#twitchIcon"+user.id).attr("value", link);
$("#twitchIcon"+user.id).css('display', 'initial');
}


	
if(thisLink.includes("tiktok=")){//tiktok
var link = thisLink.replace("tiktok=", "");
$("#tiktokIcon"+user.id).attr("value", link);
$("#tiktokIcon"+user.id).css('display', 'initial');
}


if(thisLink.includes("soundcloud=")){//soundcloud
var link = thisLink.replace("soundcloud=", "");
$("#soundcloudIcon"+user.id).attr("value", link);
$("#soundcloudIcon"+user.id).css('display', 'initial');
}

	
}








	
//FEED
$("#profileScroll"+time).append("<div class='feedLowerX' id='feedLowerX"+user.id+"'></div>");
$("#profileScroll"+time).append("<div class='feed feedProfile' id='feed"+user.id+"'><div class='feedHandle' id='feedHandle"+user.id+"' data-position = 'up' data-user='"+user.id+"'><div class='feedHandleIcons'><img src='../assets/menu.png' class='toggleFeed hoverimage toggleFeed"+user.id+"' data-user='"+user.id+"' value='all' style='opacity: 1;'><img src='../assets/media.png' class='toggleFeed hoverimage toggleFeed"+user.id+"' data-user='"+user.id+"' value='media'><img src='../assets/projectsfour.png' class='toggleFeed hoverimage toggleFeed"+user.id+"' data-user='"+user.id+"' value='pg'></div><div class='feedProfileImage'><div id='feedProfImage"+user.id+"' class='feedProfImage' data-user='"+user.id+"'><img src='"+profilePic+"'></div></div><img class='feedHandleToggleImage' id = 'feedHandleImg"+user.id+"' src='../assets/expandup.png' data-user='"+user.id+"' data-position = 'up'></div><div class='feedScroll' id='feedScroll"+user.id+"' data-start = '0'><div class='nothingSharedYet' id='nothingSharedYet"+user.id+"'><br>NOTHING SHARED YET</div></div></div>");
getFeedPosts(user.id, 0);

	

$("#feedScroll"+user.id).on("scroll", function(){
var start = $("#feedScroll"+user.id).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
getFeedPosts(user.id, start);
}
}, 150);
});



//CLOSE
$("#closeProfile"+time).on("click", function(){
$(".universalcontainer"+time).stop().animate({width: "0%"}, "fast", "linear");
setTimeout(function(){
$(".universalcontainer"+time).remove();
}, 300);
});
	
	
$("#profile"+user.id).stop().animate({width: "100%"}, "fast", "linear");
pauseAllAudioVideo = 0;
	




}
//
	


	


	

//LOAD COMMENT REPLIES
function loadCommentReplies(commentID, talentString, postID, user){
clickDelay = 0;
var time = Date.now();
var lastScrollTop = 0;
//GET THE COMMENT
getComment(commentID).then(function(response){
if(response == "error"){
return;
}	

var data = JSON.parse(response);
var postedBy = data[0];
var commentObj = data[1];
var commentBody = commentObj.details;

if(commentObj == false){
showAlert("COMMENT NOT FOUND", "red");
setTimeout(function(){
removeAlert();
},2000);
return;
}
	
$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" commentRepliesCon' id='commentRepliesContainer"+time+"' style='width: 100%; text-align: initial;'><div class='profileContainerTopBar'><i class='fas fa-backspace backarrows' id='closeCommentReplies"+time+"' aria-hidden='true'></i><div class='pgheading'></div></div><div class='commentReplyPreviewContianer'><div class='topSlideUpBox' id='topSlideUpBox"+time+"'> </div><div class='commentReplyTextAreaCon'><textarea id='commentReplyText"+time+"' placeholder='YOUR REPLY TO THIS COMMENT'></textarea></div><button class='postCommentReply' id='postCommentReply"+time+"' data-postid='"+postID+"' data-user='"+user+"'>POST REPLY</button><div class='commentRepliesScroll' id='commentRepliesScroll"+time+"' data-lastscrolltop='0' data-start='0'></div> </div></div>");		
	
	
$("#topSlideUpBox"+time).append("<div class='eachComment' id='eachComment"+commentObj.id+"'><div class='eachCommentUserInfo'><img src='"+postedBy.profilePic+"' class='viewProfile' data-id='"+commentObj.user+"'> <span style='font-weight: bold; font-size: 13px;'>"+postedBy.name+", "+talentString+"</span></div><div class='eachCommentBody'><span>"+commentBody+"</span><br><span style='font-size: 11px;'>"+data[2]+"</span></div></div>");
	

	
	//SUBMIT REPLY
	$("#postCommentReply"+time).on("click", function(){
	if(clickDelay == 0){
		clickDelay = 1;
		var body = $("#commentReplyText"+time).val();
		postCommentReply(commentID, postID, time, body, user);
	}
	});
	
	//SCROLL
$("#commentRepliesScroll"+time).on("scroll", function(){
		var lastScrollTop = $(this).attr("data-lastscrolltop");
		var elmnt = this;
		var y = elmnt.scrollHeight;
		var t = elmnt.scrollTop;
		var c = elmnt.clientHeight;
		
if(t > lastScrollTop){
if(t>50){
$("#topSlideUpBox"+time).slideUp("fast");
}
}else{
if(y - t > c+150){
$("#topSlideUpBox"+time).slideDown("fast");
}
}
	
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
var start = $("#commentRepliesScroll"+time).attr("data-start");
getCommentReplies(time, commentID, postID, start);		
}
}, 150);	
$("#commentRepliesScroll"+time).attr("data-lastscrolltop", t);
});
	
	
//CLOSE
$("#closeCommentReplies"+time).on("click", function(){
close(time);
});	
	
	



}).catch(function(respone){
});
	
	
	
//GET COMMENT REPLIES
var start = $("#commentRepliesScroll"+time).attr("data-start");
getCommentReplies(time, commentID, postID, start);


}
	
	
	






//POST COMMENT REPLY
function postCommentReply(commentID, postID, time, body, user)
{
if(body == "" || body == undefined){
clickDelay = 0;
return;
}
	
$.ajax({
url: "https://troupebase.com/formhandlers/postcommentreply.php",
method: "POST",
data: {
commentID: commentID,
postID: postID,
user: user,
body: body,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
prependCommentReply(response, time);
}
});
	
	
	
}
	


	

//PREPEND THE COMMENT REPLY FUNCTION
function prependCommentReply(response, time){
	var comment = JSON.parse(response);
	$("#commentReplyText"+time).val("");
	$("#commentRepliesScroll"+time).prepend("<div class='eachComment' id='eachComment"+comment.date+"'><div class='eachCommentUserInfo'><img src='"+userLoggedInProfilePic+"'><span style='font-weight: bold; font-size: 13px;'>"+userLoggedInName+", "+userLoggedInTalents+"</span></div><div class='eachCommentBody'><span>"+comment.body+"</span><br><span style='font-size: 11px;'>"+comment.dateTime+"</span><div class='commentButtons'><button style='color: red;' class='undoComment' id='undoComment"+comment.date+"' data-datetime='"+comment.date+"'>UNDO COMMENT</button></div></div></div> </div>");
	

	
	
}
	

	//UNDO COMMENT REPLY
	$("body").on("click", ".undoComment", function(){
	if(clickDelay == 0){
	clickDelay = 1;
	var dateTime = $(this).attr("data-datetime");
		undoCommentReply(dateTime).then(function(response){
			if(response == "success"){
				$("#eachComment"+dateTime).fadeOut("slow");
				setTimeout(function(){
				$("#eachComment"+dateTime).remove();
				}, 2000);
			}else{
		
			}
		}).catch(function(response){
		
		});
	}
	});


	
	
//UNDO COMMENT REPLY
function undoCommentReply(dateTime)
{
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/undocommentreply.php",
method: "POST",
data: {
dateTime: dateTime,
isWebsite: 1
},
success: function(response){
clickDelay = 0;
if (response !== "error")
resolve(response);
else
reject("Something Went Wrong Please Try Again");
	
}
});
	
	

});
}
	




//GET THE COMMENT
function getComment(commentID){
return new Promise(function (resolve,reject) { 
$.ajax({
url: "https://troupebase.com/formhandlers/getcomment.php",
method: "POST",
data: {
commentID: commentID,
isWebsite: 1
},
success: function(response){
if (response !== "error")
resolve(response);
else
reject("Something Went Wrong Please Try Again");
	
}
});
	
	

});
}
	




//GET COMMENT REPLIES
function getCommentReplies(time, commentID, postID, start){
$.ajax({
url: "https://troupebase.com/formhandlers/getcommentreplies.php",
method: "POST",
data: {
commentID: commentID,
postID: postID,
start: start,
isWebsite: 1
},
success: function(response){
constructCommentReplies(time, postID, response, start)
}
});

}


	
//CONSTRUCT COMMENT REPLIES
function constructCommentReplies(time, postID, response, start){
if(response == "error"){
return;
}
var newStart = parseInt(start) + 10;
$("#commentRepliesScroll"+time).attr("data-start", newStart);	
	
var data = JSON.parse(response);
for(var i = 0; i < data.length; i++){
var comment = data[i];		
var commentBody = comment.comment;
$("#commentRepliesScroll"+time).append("<div class='eachComment' id='eachComment"+comment.id+"'><div class='eachCommentUserInfo'><img src='"+comment.profilePic+"' class='viewProfile' data-id='"+comment.user+"'> <span style='font-weight: bold; font-size: 13px;'>"+comment.name+", "+comment.talents+"</span></div><div class='eachCommentBody'><span>"+commentBody+"</span><br><img src='../assets/reply.png' class='replyToComment' id='replyToComment"+comment.id+"' data-user='"+comment.user+"' data-id='"+comment.id+"' data-postid='"+postID+"' data-profilepic='"+comment.profilePic+"' data-user='"+comment.user+"' data-talentstring='"+comment.talents+"'><br><span style='font-size: 11px;'>"+comment.dateTime+"</span><div class='commentButtons'><button style='color: red;' id='deleteComment"+comment.id+"' data-id='"+comment.id+"'>Delete</button><button style='color: red;' id='reportComment"+comment.id+"' data-id='"+comment.id+"'>Report</button></div></div> </div>");
	
	
	
	
//SUBMIT DELETE
$("#deleteComment"+comment.id).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var commentID = $(this).attr("data-id");
$("#eachComment"+commentID).css("background-color","#214844");
loadDelCommCont(commentID);
}
});		
	
	
	
	//REPORT
$("#reportComment"+comment.id).on("click", function(){
if(clickDelay == 0){
clickDelay = 1;
var commentID = $(this).attr("data-id");
$("#eachComment"+commentID).css("background-color","#214844");
loadRepCommCont(commentID);
}
});	
	
	

	//BUTTONS CHECKS
	if(comment.userLoggedIn == comment.user){
	}else{
	$("#deleteComment"+comment.id).remove();
	}
	
}	
}	



	
//CONFIRM REPORT COMMENT CONTAINER
function reportComment(commentID){
$("#eachComment"+commentID).fadeOut("slow");
$.ajax({
url: "https://troupebase.com/formhandlers/reportcomment.php",
method: "POST",
data: {
commentID: commentID,
isWebsite: 1
},
success: function(response){

}
});
}


function loadRepCommCont(commentID){
var time = Date.now();

	$("#profileLoaderContainer").append("<div class='universalcontainer confirmDReportCommentCont' style='width: 100%;'><div class='confirmComDelForm'><span style='color: red;'>REPORT</span> THIS COMMENT?<br><button class='confirmRepComment"+time+"' style='color: green;'>YES</button><button class='cancelRepComment"+time+"' style='color: white;'>NO</button></div></div>");

	$(".confirmRepComment"+time).on("click", function(){
		$(".confirmDReportCommentCont").remove();
	reportComment(commentID);
	});
	$(".cancelRepComment"+time).on("click", function(){
	$(".confirmDReportCommentCont").remove();
		$("#eachComment"+commentID).css("background-color","#141414");
	});

	clickDelay = 0;
	
}


//CONFIRM DELETE COMMENT CONTAINER
function loadDelCommCont(commentID){
var time = Date.now();

	$("#profileLoaderContainer").append("<div class='universalcontainer confirmDeleteCommentCont' style='width: 100%;'><div class='confirmComDelForm'>DELETE THIS COMMENT?<br><button class='confirmDeleteComment"+time+"' style='color: green;'>YES</button><button class='cancelDeleteComment"+time+"' style='color: white;'>NO</button></div></div>");

	$(".confirmDeleteComment"+time).on("click", function(){
		$(".confirmDeleteCommentCont").remove();
	deleteComment(commentID);
	});
	$(".cancelDeleteComment"+time).on("click", function(){
	$(".confirmDeleteCommentCont").remove();
		$("#eachComment"+commentID).css("background-color","#141414");
	});

	clickDelay = 0;
	
}


function deleteComment(commentID){
$("#eachComment"+commentID).fadeOut("slow");
$.ajax({
url: "https://troupebase.com/formhandlers/deletecomment.php",
method: "POST",
data: {
commentID: commentID,
isWebsite: 1
},
success: function(response){

}
});
}




//GET EDITABLE DIV

	
//FOR COMMENT BACK HERE
function getEditablePostComment(time){
editablePostComment = "";
editablePostComment = document.getElementById('addCommentBox'+time);

editablePostComment.addEventListener('keyup', function(e){

var key = e.keyCode;
var value = $(this).text();
var length = value.length;
var remaining = 3000 - length;

if(key!== 8 && length >= 3000){
$(this).blur();
}		
	
keepTrackOfCommentAts();
getWord();

if(previousWord.charAt(0) == "@" && previousWord.length>2){
if(key !== 32 && key !== 8){
	
$(".userTagInCom"+time).empty();
$(".userTagInCom"+time).attr("data-start", "0");
$(".userTagInCom"+time).slideDown("fast");
	
var search = previousWord.replace("@", "");
var start = $(".userTagInCom"+time).attr("data-start");
getUsersToTagComment(time, search, start);
	
}else{
$(".userTagInCom"+time).slideUp("fast")
}
}else{
$(".userTagInCom"+time).slideUp("fast");
}
	
	
});
}

	



///////////////


var userToTagStart = 0;
var userToTagSearch = "";
//POST SHARE EDITABLE 
function getEditablePostShare(){
editablePostShare = "";
editablePostShare = document.getElementById('shareSomethingDesc');
editablePostShare.addEventListener('input', function(e){
var key = e.keyCode;
var value = $(this).text();
var length = value.length;
var remaining = 3000 - length;
$("#shareSomethingLim").text(remaining);
keepTrackOfPostAts();
getWord();
if(previousWord.charAt(0) == "@" && previousWord.length>1){
if (/\s/.test(previousWord)) {
resetUserToTagInShare();
return;
}

userToTagStart = 0;
$(".feed").css("opacity", .2);	
$(".userToTagInShare").empty();
$(".userToTagInShare").slideDown(100);
var search = previousWord.replace("@", "");
userToTagSearch = search;
getUsersToTag(userToTagSearch, userToTagStart);
userToTagStart = userToTagStart + 7;
	
	
}else{
resetUserToTagInShare();
}
	
	
	
});
}
function resetUserToTagInShare(){
$(".userToTagInShare").slideUp(100);
$(".feed").css("opacity", 1);
}



	


	

//FOR POST CREATOR
function getEditable(user){
editable = "";
if(user == "postcreator"){
editable = document.getElementById('postCaption');
}
editable.addEventListener('keyup', function(e){
var key = e.keyCode;
var value = $(this).html();
var length = value.length;
var remaining = 3000 - length;
$(".postCaptionLimit").text("CAPTION "+remaining);
if(key!== 8 && length >= 3000){
$(this).blur();
}
if(length >= 3000){
$(".postCaptionLimit").css("color", "red");
}else{
$(".postCaptionLimit").css("color", "black");
}


	

getWord();
if(previousWord.charAt(0) == "@" && previousWord.length>1){
if(key !== 32 && key !== 8){
var time = Date.now();
$(".userToTagContainer").empty();
$(".userToTagContainer").attr("data-start", "0");
$(".userToTagContainer").slideDown("fast");
var search = previousWord.replace("@", "");
var start = $(".userToTagContainer").attr("data-start");

	getUsersToTag(search, start);
	
	
}
}else{
resetUserToTag();
}
	
});



$(".userToTagContainer").on("scroll", function(){
var search = previousWord.replace("@", "");
var start = $(".userToTagContainer").attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
getUsersToTag(search, start);
}
}, 150);
});


}
	



	
function resetUserToTag(){
$(".userToTagContainer").empty();
$(".userToTagContainer").slideUp("fast");
$(".userToTagContainer").attr("data-start", "0");
}

	
	





function getWord(){
   var range = window.getSelection().getRangeAt(0);
    if (range.collapsed) {
        text = range.startContainer.textContent.substring(0, range.startOffset+1);
		previousWord = text.split(" ").pop();
    }
    return '';
}
	


//get editable div
















	
	





//NOTIFICATIONS	
var blinkInbox;
var blinkMyPG;
var newTrBlink;
var newcrblink;
var hasNewNotes = 0;
	
//NOTIFICATIONS
function loadNotifications(){
if(clickDelay == 0){
clickDelay = 1;
var time = Date.now();

$("#profileLoaderContainer").append("<div class='universalcontainer universalcontainer"+time+" universalSeeThrough notificationsContainer' id='notificationsContainer' style='width: 0%; background-color: black;'><div class='portfolioHeading'><i class='fas fa-backspace backarrows closebuttonstopleft' data-time='"+time+"'></i>Notifications<div class='topTopConIcons'></div></div><div class='postScroller' id='notificationsScroller"+time+"' style='text-align: initial;' data-start = '0'></div></div>");	
	
//GET INITIAL NOTIFICATIONS	
var start = 0;
var container = document.getElementById("notificationsScroller"+time);
getnotifications(start).then(function(response){
if(response == "end"){
return;
}
var newStart = parseInt(start) + 20;
$(container).attr("data-start", newStart);
var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){	
var notification = data[i];
constructNotification(container, notification);
}
});	
	
	
	
	
//SCROLL
$("#notificationsScroller"+time).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
var start = $("#notificationsScroller"+time).attr("data-start");
getnotifications(start).then(function(response){
if(response == "end"){
return;
}
var newStart = parseInt(start) + 20;
$(container).attr("data-start", newStart);
var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){	
var notification = data[i];
constructNotification(container, notification);
}
});		
	
}
}, 150);
});
	
	

	
$("#notificationsContainer").stop().animate({width: "100%"}, "fast", "linear");	
setTimeout(function(){
clickDelay = 0;
}, 500);
}
}
	


//CONSTRUCT A NOTIFICATION
function constructNotification(container, note){

var profilePic = note.profilePic;
if(profilePic == ""){
profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
}	

	
var detailString = "";	
var acceptButtonText = "";
var IgnoreButtonText = "";
//IF COLLAB
if(note.type=="ww"){
var detailString = note.userFromName + " says you collaborated on this post:";
acceptButtonText = "CONFIRM";
IgnoreButtonText = "Ignore";
}
//IF POST COMMENT 
if(note.type=="postcomment"){
var detailString = note.userFromName + " commented on your post:";
IgnoreButtonText = "Delete Comment";
}	
//IF POST COMMENT 
if(note.type=="troupeRequest"){
var detailString = note.userFromName + " sent you a Troupe Request:";
acceptButtonText = "Accept";
IgnoreButtonText = "Ignore";
}	
//IF CAPTION TAG 
if(note.type=="captag"){
var detailString = note.userFromName + " tagged in a post";
IgnoreButtonText = "Delete Tag";
acceptButtonText = "CONFIRM";
}	
	



$(container).append("<div class='eachNotification eachNotificationContainer"+note.id+"' data-id='"+note.id+"'><div class='eachNotePhoto'><img src='"+profilePic+"' class='viewProfile' data-id='"+note.userFrom+"'></div><div class='noteBody'><span style='font-size: 14px;'>@"+note.dateTime+"</span><br>"+detailString+"<div id='notificationComment"+note.id+"'>'"+note.comment+"'</div><div class='notificationButtons notificationButtons"+note.id+" notificationButtons"+note.postID+"' id='notificationButtons"+note.id+"'><button class='ignoreNotification confirmDeleteButton' data-type = '"+note.type+"' data-id='"+note.id+"' data-postid='"+note.postID+"' data-postdate = '"+note.unix+"' data-userfrom = '"+note.userFrom+"'>"+IgnoreButtonText+"</button><button class='confirmNotification confirmButton' data-type = '"+note.type+"' data-id='"+note.id+"' data-postid='"+note.postID+"' data-postdate = '"+note.unix+"' data-userfrom = '"+note.userFrom+"'>"+acceptButtonText+"</button></div></div><div class='eachNotePostPhoto' id='eachNotePostPhoto"+note.id+"'><img src='"+note.smallImage+"' class='viewPost hoverimage' data-id='"+note.postID+"'></div></div><br>");

	//REMOVE POST PHOTO WHERE NOT NEEDED
	if(note.type == "troupeRequest"){
	$("#eachNotePostPhoto"+note.id).empty();
	}
	//REMOVE COMMENT WHERE NOT NEED
	if(note.type == "troupeRequest" || note.type=="ww" || note.type == "captag"){
	$("#notificationComment"+note.id).empty();
	}


	
}
	
	
	


//ACCEPT NOTIFICATION
$("body").on("click", ".confirmNotification", function(){
if(clickDelay == 0){
loadLayOver();
clickDelay = 1;
var noteID = $(this).attr("data-id");
var postID = $(this).attr("data-postid");
var userFrom = $(this).attr("data-userfrom");
var type = $(this).attr("data-type");
var postDate = $(this).attr("data-postdate");
	
//IF COLLAB WITH
if(type == "ww"){
acceptCollabWith(noteID, postID, userFrom).then(function(response){
if(response == "success"){
$("#notificationButtons"+noteID).empty();
$("#notificationButtons"+noteID).append("<span style='color: green; font-weight: Bold;'>Collab Confirmed</span>");
}else{

}
clickDelay = 0;
removeLayOver();
});
}

	
	
//IF TROUPE REQUEST	
if(type == "troupeRequest"){
acceptTroupeRequest(user).then(function(r){

});
}

	
}
});



//IGNORE NOTIFICATION
$("body").on("click", ".ignoreNotification",function(){
if(clickDelay == 0){
loadLayOver();
clickDelay = 1;
var noteID = $(this).attr("data-id");
var postID = $(this).attr("data-postid");
var userFrom = $(this).attr("data-userfrom");
var type = $(this).attr("data-type");
var postDate = $(this).attr("data-postdate");
	
	
//if caption tag
if(type == "captag"){
deleteCaptionTag(noteID, postID, userFrom, postDate).then(function(response){
if(response == "success"){
$("#notificationButtons"+noteID).empty();
$("#notificationButtons"+noteID).append("<span style='color: red;'>Caption tag has been removed</span>");
}else{

}
clickDelay = 0;
removeLayOver();		
});
}	
	

//if post comment
if(type == "postcomment"){
ignorePostComment(noteID, postID, userFrom, postDate).then(function(response){
	alert(response);
if(response == "success"){
$("#notificationButtons"+noteID).empty();
$("#notificationButtons"+noteID).append("<span style='color: red;'>Comment has been removed</span>");
}else{

}
clickDelay = 0;
removeLayOver();		
});
}
	
	
//if troupe request
if(type == "troupeRequest"){
ignoreTroupeRequest(noteID, postID, userFrom, postDate).then(function(response){
if(response == "success"){
$("#notificationButtons"+noteID).empty();
$("#notificationButtons"+noteID).append("<span style='color: red;'>Request ignored</span>");
}else{

}
clickDelay = 0;
removeLayOver();		
});
}	
	
//if post collab
if(type == "ww"){
ignorePostCollab(noteID, postID, userFrom, postDate).then(function(response){
if(response == "success"){
$("#notificationButtons"+noteID).empty();
$("#notificationButtons"+noteID).append("<span style='color: red;'>collaboration ignored</span>");
}else{

}
clickDelay = 0;
removeLayOver();		
});
}	
	
	
}
});
	
	
	



	
//IGNORE CAPTION TAG
function deleteCaptionTag(noteID, postID, userFrom, postDate){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/deleteCaptionTag.php",
method: "POST",
data: {
noteID: noteID,
postID: postID,
userFrom: userFrom,
postDate: postDate,
username: userLoggedInAlias,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}






//IGNORE POST COLLABORATION
function ignorePostCollab(noteID, postID, userFrom, postDate){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/ignorePostCollab.php",
method: "POST",
data: {
noteID: noteID,
postID: postID,
userFrom: userFrom,
postDate: postDate,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}



//IGNORE TROUPE REQUEST
function ignoreTroupeRequest(noteID, postID, userFrom, postDate){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/ignoreTroupeRequest.php",
method: "POST",
data: {
noteID: noteID,
postID: postID,
userFrom: userFrom,
postDate: postDate,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}


//IGNORE POST COMMENT
function ignorePostComment(noteID, postID, userFrom, postDate){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/ignorePostComment.php",
method: "POST",
data: {
noteID: noteID,
postID: postID,
userFrom: userFrom,
postDate: postDate,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}



//GET NOTIFICATIONS
function getnotifications(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/getnotifications.php",
method: "POST",
data: {
username: userLoggedInAlias,
start: start,
isWebsite: 1
},
success: function(response){

	resolve(response);

}
});		
}, 500);
});
}
	
	







//SEND MESSAGE
$("body").on("click", ".startNewConvo", function(){
var troupeID = $(this).attr("data-id");
var name = $(this).attr("data-name");
var pic = $(this).attr("data-pic");
isCollabId = $(this).attr("data-collabid");
console.log(isCollabId);
newConvoForm(troupeID, name, pic);
});
	


	

	
//SEND NEW MESSAGE
function sendNewMessage(id, message){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/sendNewMessage.php",
method: "POST",
data: {
id: id,
message: message,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}

//send

	
$("body").on("click", ".closesncform", function(){
isCollabId = "undefined";
projectToApply = 0;
$(".newConvoFormCon").fadeOut();
setTimeout(function(){
$(".newConvoFormCon").remove();
closeDivLoader();
}, 300);
});
	
	
$("body").on("click", ".sendNewMessage", function(){
$(this).slideUp(50);
$(".csnmcon").slideDown(50);
setTimeout(function(){
$(".sendNewMessage").slideDown(50);
$(".csnmcon").slideUp(50);
}, 3000)
});



//send message


	







	
//VIEW COLLAB REQ
$("body").on("click", ".vcr", function(){
loadcr();
});
	

function loadcr(){
var time = Date.now();
$("#profileLoaderContainerSlider").slideDown("fast");
$("#profileLoaderContainer").append("<div class='collabreqreccon'><div class='collabreqhead'><i class='fas fa-backspace backarrows closecr'></i>Collab Requests<img class='vscr' src='https://troupebase.com/assets/sent.png'></div><div class='collabReqScroll collabReqScroll"+time+"' data-start='0'></div></div>");
$('.collabreqreccon').animate({marginLeft: 0}, {duration: 300});
	
	
$(".collabReqScroll"+time).on("scroll", function(){
var start = $(".collabReqScroll"+time).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
getcr(start, time);
}
}, 150);
});		
	
var start = $(".collabReqScroll"+time).attr("data-start");
getcr(start, time);
}
	
function getcr(start, time){
$.ajax({
url: "https://troupebase.com/getcollabreq.php",
method: "POST",
data: {
getcr: 1,
start: start,
timeZone: timeZone
},
success: function(response){
concr(start, response, time);
}
});	
}
	

// CON COLLAB MESSAGES
function concr(start, response, time){
if(response == "end"){
if($(".endofcr"+time).length === 0){
$(".collabReqScroll"+time).append("<br><div class='endofcr"+time+"' style='width: 100%; text-align: center'>End of Collab Requests</div><br><br>")
}
return;
}
var newStart = parseInt(start) + 14;
$(".collabReqScroll"+time).attr("data-start", newStart);

var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){	
var collab = data[i];

var photoFilter = collab.photoFilter;

$(".collabReqScroll"+time).append("<div class='eachcolabcontainer eachcolabcontainer"+collab.id+"'><div class='eachcoltop'><div class='eacoltopleft'><img src='"+collab.profilePic+"' class='filter"+photoFilter+"'></div><div class='eacoltopright'><p style='font-weight: bold;'>"+collab.name+"</p><p>"+collab.talent+" "+collab.state+"</p><img class='startNewConvo' src='https://troupebase.com/assets/newMessageIcon.png' data-collabid='"+collab.id+"' data-id='"+collab.userfrom+"' data-pic='"+collab.profilePic+"' data-name='"+collab.name+"'><img class='delcr delcr"+collab.id+"' data-id='"+collab.id+"' src='https://troupebase.com/assets/deny.png'></div></div><div class='eachcolbot'><div class='dcrcon dcrcon"+collab.id+"'>IGNORE REQUEST? <button class='confirmignorecr' value='ignore' data-id='"+collab.id+"'>YES</button> <button class='confirmignorecr' value='report' data-id='"+collab.id+"'>REPORT</button></div><p style='font-size: 11px;'>"+collab.dateTime+"</p><p>Subject: "+collab.subject+"</p><p>"+collab.details+"</p></div></div>");
	



}	
}
	


$("body").on("click", ".vscr", function(){
loadScr();
});
	

function loadScr(){
var start = 0;
var time = Date.now();
$("#profileLoaderContainerSlider").slideDown("fast");
$("#profileLoaderContainer").append("<div class='collabreqreccon collabreqrecconsent' style='background-color: red;'><div class='collabreqhead'><i class='fas fa-backspace backarrows closescr'></i>Sent Collabs</div><div class='collabReqSentScroll sentCollabReqScroll"+time+"' data-start='0'></div></div>");
$('.collabreqreccon').animate({marginLeft: 0}, {duration: 300});
	
$(".sentCollabReqScroll"+time).on("scroll", function(){
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+150){
var start = $(".sentCollabReqScroll"+time).attr("data-start");
getScr(start, time);
}
}, 150);
});		
	
	

getScr(start, time);
}
	

function getScr(start, time){
$.ajax({
url: "https://troupebase.com/getsentcollabreq.php",
method: "POST",
data: {
start: start,
getSentCollabs: 1
},
success: function(response){
conSENTcollabs(response, time, start);
}
});	
}
	

//SENT
function conSENTcollabs(response, time, start){	
if(response == "end"){
if($(".endofscr").length === 0){
$(".collabReqSentScroll").append("<br><div class='endofscr' style='width: 100%; text-align: center; color: black;'>End of Sent Collabs</div><br><br>")
}
return;
}
	
	
var newStart = parseInt(start) + 14;
$(".sentCollabReqScroll"+time).attr("data-start", newStart);
	
	
var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){	
var collab = data[i];
	
$(".sentCollabReqScroll"+time).append("<div class='eachcolabcontainer eachsentcolabcontainer"+collab.id+"'><div class='eachcoltop'><div class='eacoltopleft'><img src='"+collab.profilePic+"'></div><div class='eacoltopright'><p style='font-weight: bold;'>Sent To: "+collab.name+"</p><p>"+collab.talent+" "+collab.state+"</p><img class='delscr delcsr"+collab.id+"' data-id='"+collab.id+"' src='https://troupebase.com/assets/deny.png'></div></div><div class='eachcolbot'><div class='dcrcon dscrcon"+collab.id+"'>CANCEL REQUEST? <button class='confmdelsentcr' value='cancel' data-id='"+collab.id+"'>YES</button></div><p style='font-size: 11px;'>"+collab.dateTime+"</p><p>Subject: "+collab.subject+"</p><p>"+collab.details+"</p></div></div>");
	
}

	
	
	
}
//sent

// con collab messages
	
$("body").on("click", ".closescr", function(){
$('.collabreqrecconsent').animate({marginLeft: 6000}, {duration: 300});
	
setTimeout(function(){
$(".collabreqrecconsent").remove();
}, 300);
	
});

$("body").on("click", ".closecr", function(){
$('.collabreqreccon').animate({marginLeft: 6000}, {duration: 300});
setTimeout(function(){
$(".collabreqreccon").remove();
closeDivLoader();
}, 300);
});
	
	
$("body").on("click", ".delscr", function(){
$(this).slideUp();
var id = $(this).attr("data-id");
$(".dscrcon"+id).slideDown("fast");
setTimeout(function(){
$(".delcsr"+id).slideDown();
$(".dscrcon"+id).slideUp("fast");
}, 2500);
});


$("body").on("click", ".delcr", function(){
$(this).slideUp();
var id = $(this).attr("data-id");
$(".dcrcon"+id).slideDown();
setTimeout(function(){
$(".delcr"+id).slideDown();
$(".dcrcon"+id).slideUp();
}, 3000)
});
	
	
//DELETE SENT CR
$("body").on("click", ".confmdelsentcr", function(){
var value = $(this).attr("value");
var id = $(this).attr("data-id");
$(".eachsentcolabcontainer"+id).fadeOut();
$.ajax({
url: "https://troupebase.com/formHandlers/deletereportcr.php",
method: "POST",
data: {
id: id,
value: value
},
success: function(response){

}
});	
});


//IGNORE CR
$("body").on("click", ".confirmignorecr", function(){
var value = $(this).attr("value");
var id = $(this).attr("data-id");
$(".eachcolabcontainer"+id).fadeOut();
$(".eachNotificationContainer"+id).fadeOut();
$.ajax({
url: "https://troupebase.com/formHandlers/deletereportcr.php",
method: "POST",
data: {
id: id,
value: value
},
success: function(response){

}
});	
});

//view collab req


	
//VSPN
$("body").on("click", ".vspn", function(){
$(".viewMyPG").trigger("click");
setTimeout(function(){
$(".viewPgSharedWithMe").trigger("mousedown");
}, 700);
});
//vspn





//SHOW NOTE DELETE
var sndt;
var sndtc = 0;

	
$("body").on("mouseup touchend", ".eachNotification", function(){
clearInterval(sndt);
sndtc = 0;
});

$("body").on("mousedown", ".deletethisnote", function(){
var id = $(this).attr("data-id");
$(".eachNotificationContainer"+id).fadeOut();
setTimeout(function(){
$(".eachNotificationContainer"+id).remove();
}, 700);
$.ajax({
url: "https://troupebase.com/formHandlers/notifications.php",
method: "POST",
data: {
id: id,
delete: 1
}
});	
});	


//show note delete function




//CONFIRM COLLAB
$("body").on("click", ".subconfirmCollab", function(){
var id = $(this).attr("data-id");
$(".notebuttons"+id).slideUp("fast");
$(".confirmnotebutton"+id).slideDown("fast");
setTimeout(function(){
$(".notebuttons"+id).slideDown("fast");
$(".confirmnotebutton"+id).slideUp("fast");
}, 7000);
});
	





$("body").on("click", ".submitigncollab", function(){
var id = $(this).attr("data-id");
$(".notebuttons"+id).slideUp("fast");
$(".confirmnoteignbutton"+id).slideDown("fast");
setTimeout(function(){
$(".notebuttons"+id).slideDown("fast");
$(".confirmnoteignbutton"+id).slideUp("fast");
}, 3000)
});

	
//IGNORE COLLAB
$("body").on("click", ".confirmigncollab", function(){
$(this).fadeOut(10);
var id = $(this).attr("data-id");
var postID = $(this).attr("data-postID");
$(".confirmnoteignbutton"+id).slideUp("fast");
$(".notebuttons"+id).slideDown();
$(".notebuttons"+id).empty();
$(".notebuttons"+id).append("<span style='color: red;'>COLLAB IGNORED</span>");
$.ajax({
url: "https://troupebase.com/formHandlers/noteresponse.php",
method: "POST",
data: {
id: id,
postID: postID,
ignoreCollab: 1
},
success: function(response){

}
});	
});
//
	



//confirm collab
	










	

$("body").on("mousedown", ".eachNotification", function(){
$(this).css("-webkit-box-shadow", "none");
$(this).css("-moz-box-shadow", "none");
$(this).css("box-shadow", "none");
});




//notifications



	

//VIEW LIKED

function conLikedUsers(response, postID, start, time){
if(response == "end"){
clickDelay = 0;
return;
}

var start = parseInt(start) + 14;
$("#likedscroll"+time).attr("data-start", start);
		
var data = JSON.parse(response);	
for(var i = 0; i < data.length; i++){
var liked = data[i];

$("#likedscroll"+time).append("<div class='eachProjectGoal myTroupe"+liked.troupeID+"' style='background-color: transparent;'><div class='projectGoalContent myTroupeContent"+liked.troupeID+"' style='color: white;'><img class='viewProfile' data-id='"+liked.troupeID+"' style='margin-top: 5px; background-color: transparent; border: none;' src='"+liked.profilePic+"'><p>"+liked.name+"<br> "+liked.talent+", "+liked.state+"</p><div style='margin-bottom: 5px;' class='projectGoalIcons myTroupesIcon"+liked.troupeID+"'></div></div></div>");
	console.log(liked.talents);
	
}
	
	
	
	clickDelay = 0;	
}
	



	

$("body").on("mousedown", ".closelikedcon", function(){
var time = $(this).attr("value");
$(".likedContainer"+time).animate({width: "0%"});
setTimeout(function(){
$(".likedContainer"+time).remove();
},1000)
});

//view liked
	

	
	
















//TUTORIAL
if (window.location.href.indexOf("homebase") != -1){
	
	
var didViewTut = $("#viewedtut").attr("value");
var tutorialStepBlinker;
var tutorialStartBlinker;
var currentTutorialStep = 1;
if(didViewTut == 0 || didViewTut == "0"){
loadTut();
}else{

}
	

//LOAD TUTORIAL
function loadTut(){
$("#profileLoaderContainerSlider").slideDown("fast");
$("#profileLoaderContainer").append("<div class='tutorialContainer'><div class='tutorialContent'><div class='startTutorial'><p>Familiarize Yourself With The Base</p><button class='startTutorialButton' style='margin-bottom: 10px; height: 20px;'>START</button><br><button style='background-color: transparent; color: white; margin-bottom: 20px; width: 100%;' class='endTutorial'>I'm already familiar</button></div></div></div>");
	
//1
$(".tutorialContent").append("<div class='tutorialStep tutorialStep1'><p style='font-size: 14px;'>This is your <span class='tutboldhead'>Homebase</span>.<br>Here you can access things like your Posts, Messages, Project Goals, Troupe Requests, view notifications etc..</p><button class='nextTutorialStep'>NEXT</button><br><div class='skiptutcon'></div></div>");
//1
	
//2
$(".tutorialContent").append("<div class='tutorialStep tutorialStep2'><p><span class='tutboldhead'>Troupe Search</span><br>Search other profiles</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//2
	
//3
$(".tutorialContent").append("<div class='tutorialStep tutorialStep3'><p><span class='tutboldhead'>Project Search</span><br>Search & respond to Project Goals<br>posted by other Troupes</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//3
	
	
//4
$(".tutorialContent").append("<div class='tutorialStep tutorialStep4'><p><span class='tutboldhead'>Discover</span> posts from other Troupes</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//4
	
//5
$(".tutorialContent").append("<div class='tutorialStep tutorialStep5'><p>Profile details & other <span class='tutboldhead'>Settings</span></p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//5
	
//6
$(".tutorialContent").append("<div class='tutorialStep tutorialStep6'><p><span class='tutboldhead'>Post</span> new content and view your existing posts.</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//6
	

//7
$(".tutorialContent").append("<div class='tutorialStep tutorialStep7'><p>Create <span class='tutboldhead'>Project Goals</span> for others to respond to</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//7

	
//8
$(".tutorialContent").append("<div class='tutorialStep tutorialStep8'><p><span class='tutboldhead'>Troupe Requests</span><br>View Troupes who want to connect with you</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='skiptutcon'></div></div>");
//8
	

//9
$(".tutorialContent").append("<div class='tutorialStep tutorialStep9'><p><span class='tutboldhead'>Collab Request</span><br>View request from Troupes who want to collaborate with you</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><div class='pstut'></div><div class='skiptutcon'></div></div>");
//9
	


//10
$(".tutorialContent").append("<div class='tutorialStep tutorialStep10'><p><span class='tutboldhead'>Messaging</span><br>Your communications with others on the base</p><button class='prevtutstep'>Previous</button><button class='nextTutorialStep'>NEXT</button><br><br><div class='skiptutcon'></div></div>");
//10
	

$(".skiptutcon").append("<button class='endTutorial' style='background-color: transparent; color: white; border: none; margin-bottom: 20px;'>Skip Tutorial</button><br>")

	
$("#troupeOfTheDayContainerContent").scrollTop(0);	
$(".startTutorial").slideDown();
clearInterval(tutorialStepBlinker);
tutorialStepBlinker = setInterval(function(){
$(".startTutorialButton").fadeTo("fast", .3).fadeTo("slow", 1).fadeTo("slow", .3).fadeTo("slow", 1);
}, 1000);
}
//load tutorial	
	
	
}
	

	

//PREV
$("body").on("mousedown", ".prevtutstep", function(){
$(".tutorialStep"+currentTutorialStep).slideUp(10);
$(".t"+currentTutorialStep).css("border", "1px solid grey");
currentTutorialStep = currentTutorialStep - 1;
$(".tutorialStep"+currentTutorialStep).slideDown(10);
$(".t"+currentTutorialStep).css("border", "2px solid red");
$(".nextTutorialStep").slideDown(10);

});
//


	
//NEXT
$("body").on("mousedown", ".nextTutorialStep", function(){
$(".tutorialStep"+currentTutorialStep).slideUp(10);
$(".t"+currentTutorialStep).css("border", "1px solid grey");
currentTutorialStep = currentTutorialStep + 1;
$(".tutorialStep"+currentTutorialStep).slideDown(10);
$(".t"+currentTutorialStep).css("border", "2px solid red");

	
if(currentTutorialStep>4){
$(".tutorialStep").css("top", "100px");
}else{
$(".tutorialStep").css("top", "20px");
}
	
if(currentTutorialStep == 10){
$(".nextTutorialStep").slideUp(10);
$(".endTutorial").text("End Tutorial");
$(".endTutorial").css("font-weight", "bold");
}else{
$(".endTutorial").text("Skip Tutorial");
$(".endTutorial").css("font-weight", "initial");
}
	
clearInterval(tutorialStepBlinker);
tutorialStepBlinker = setInterval(function(){
$(".t"+currentTutorialStep).fadeTo("fast", .3).fadeTo("fast", 1).fadeTo("fast", .3).fadeTo("fast", 1);
}, 1000);


});
//next









//SHOW TUTORIAL
	
$(".showTutorial").on("click", function(){
$("#done").trigger("click");
loadTut();
});
	
	

	
	










//START TUTORIAL
$("body").on("mousedown", ".startTutorialButton", function(){
$(".startTutorial").slideUp(10);
clearInterval(tutorialStepBlinker);
tutorialStepBlinker = setInterval(function(){
$(".t1").css("border", "2px solid red");
$(".t1").fadeTo("fast", .3).fadeTo("slow", 1).fadeTo("slow", .3).fadeTo("slow", 1);
}, 1000);
$(".tutorialStep1").slideDown();
});
//start tutorial




//END TUTORIAL	
$("body").on("mousedown", ".endTutorial", function(){
currentTutorialStep = 1;
clearInterval(tutorialStepBlinker);
$(".tutorial").css("border", "1px solid grey");
$(".tutorialContainer").fadeOut("fast");
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: black'>You may run the walkthrough again in your settings</p>");
showSuccess();
setTimeout(function(){
$(".tutorialContainer").remove();
closeDivLoader();
}, 300);
$.ajax({
url: "https://troupebase.com/formHandlers/viewedTutorial.php",
method: "POST",
data: {
viewedProfile: 1
},
success: function(response){

}
});
});	

//tutorial

	



//SOMETHING WENT WRONG FUNCTION
function somethingwentwrong(){
$("#successResponseDropDown").empty();
$("#successResponseDropDown").append("<p style='font-weight: bold; color: red'>SOMETHING WENT WRONG PLEASE TRY AGAIN</p>");
showSuccess();
}

	

});
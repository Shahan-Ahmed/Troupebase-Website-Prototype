$(document).ready(function(){
var homebaseIsLoggedIn;
var TroupeBaseID = localStorage.getItem('TroupeBaseID');
var SessionID = localStorage.getItem('SessionID');
var profilePic = localStorage.getItem("profilePic");
$("#goToHomeIcon").attr("src", profilePic);	
	
var scrollTime;
	
var ts_city_filter = "";
var ts_state_filter = "";
var ts_country_filter = "";
var ts_talent_filter = "";	
	


	
	
//LOAD DISCOVER WRAP ON LOAD
$("#profileLoaderContainer").append("<div class='wrapper'><div class='discoverscrollwrap' id='discoverscrollwrap'><div class='scroller discoverScroller' id='discoverScroller' data-start = '0'><div class='discover-suggested flex-wrap-start'></div><div class='discover-allposts flex-wrap-start' id='discover-allposts'></div></div><div class='discovermenuwrap' id='discovermenuwrap'><div class='discovermenuicons' id='discovermenuicons'><img class='hoverimage' id='showDiscSearch' value='hidden' src='../assets/discoversearch.png'></div><div class='discoversearchheading' id='discoversearchheading'>Search Troupes</div><div class='discoversearchinputs' id='discoversearchinputs'><button class='chooseTalentsFilter'>Talent</button><button class='chooseLocationForShare'>Location</button><span class='hoverimage' id='resetDiscFilters' style='color: #214844; font-weight: bold; display: none;'>Show All</span></div></div></div></div>");
var disctalentselector = document.getElementById('talentDiscoverSearch');
$("#profileLoaderContainerSlider").css("display", "initial");	
	
	
	
$("#discoverScroller").on("scroll", function(){
var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+250){
getAllTroupeSearch(start).then(function(response){
var container = "all";
ts_construct_troupes(container, start,response);
});
}
}, 150);
});	
	
	
	
	
	
	
	
//FILTER EVENTS
$("body").on("click", ".eachTalentFilter", function(){
var talent = $(this).attr("data-value");
ts_talent_filter = talent;
$("#talentFiltContainer").fadeOut(100);
$(".chooseTalentsFilter").html(talent);
if(talent == ""){
$(".chooseTalentsFilter").html("Talent");
}
loadFilteredSearchForTS();
});	
$("body").on("click", ".eachLocation", function(){
var id = $(this).attr("data-id");
let location = $("#thisLocationText"+id).html();
let locationString = $("#eachLocationCommaString"+id).text();
let Arr = locationString.split(',');
ts_city_filter = Arr[0];
ts_state_filter = Arr[1];
ts_country_filter = Arr[2];
loadFilteredSearchForTS();
});

	
	
	
	
//LOAD THEN FILTERED CONTAINER	
function loadFilteredSearchForTS(){
$("#resetDiscFilters").css("display", "initial");
$(".discfilteredsearchwrap").remove();
if(ts_country_filter == "" && ts_talent_filter == ""){
return;
}
var time = Date.now();
$("#discoverscrollwrap").append("<div class='universalcontainer discfilteredsearchwrap flex-wrap-start' id='discfilteredsearchwrap"+time+"' style='width: 100%; top: 0px; background-color: white;' data-start = '0'></div>");
var container = document.getElementById('discfilteredsearchwrap'+time);

//SCROLL
$("#discfilteredsearchwrap"+time).on("scroll", function(){
var start = $(this).attr("data-start");
var elmnt = this;
var y = elmnt.scrollHeight;
var t = elmnt.scrollTop;
var c = elmnt.clientHeight;
clearTimeout(scrollTime);
scrollTime = setTimeout(function(){	
if(y - t <= c+250){
ts_get_filtered_troupes(start).then(function(response){
ts_construct_troupes(container, start, response);
});	
}
}, 150);
});		
	
	
	
var start = $("#discfilteredsearchwrap"+time).attr("data-start");
ts_get_filtered_troupes(start).then(function(response){
ts_construct_troupes(container, start, response);
});	
	
}	
	
	
	
	
		
	
//GET FILTERED TROUPES
function ts_get_filtered_troupes(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/filteredtroupesearch.php",
method: "POST",
data: {
start: start,
talent: ts_talent_filter,
city: ts_city_filter,
state: ts_state_filter,
country: ts_country_filter,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 500);
});
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
//GET ALL TROUPES SEARCH
function getAllTroupeSearch(start){
return new Promise(function (resolve,reject) { 
setTimeout(function(){	
$.ajax({
url: "https://troupebase.com/formhandlers/troupesearchall.php",
method: "POST",
data: {
start: start,
isWebsite: 1
},
success: function(response){
resolve(response);
}
});		
}, 150);	
});
}

	
	
	
	
	
	
//CONSTRUCT TROUPES
function ts_construct_troupes(container, start, response){

if(response == "end"){
return;
}
	
var newStart = parseInt(start) + 15;	
if(container == "all"){
var container = document.getElementById('discover-allposts');
$("#discoverScroller").attr("data-start", newStart);
}else{

}	

var data = JSON.parse(response);	
	
for(var i = 0; i < data.length; i++){
var user = data[i];
	
var talentString = 	user.talent;
var talentText = talentString.replace(',', ''); 
talentText = talentText.replace(/,\s*$/, "");
talentText = talentText.replace(/,/g, ', ');
	

	var profilePic = user.profilePic;
	if(profilePic == ""){
	profilePic = "https://troupebase.com/assets/defaultProfilePic.png";
	}
	
$(container).append("<div class='generalUserContainer'><div class='generalUserConProfilePic'><img class='viewProfile' data-id='"+user.troupeID+"' src='"+profilePic+"'></div><div class='generalUserConInfo' id='generalUserConInfo"+user.troupeID+"' style='color: black;'><p style='font-weight: bold;'>"+user.name+"</p><p>"+talentText+", "+user.state+"</p></div></div>");	

}
	
}
	
	

$("#resetDiscFilters").on("click", function(){
resetTroupeSearch();
});
function resetTroupeSearch(){
$(".discfilteredsearchwrap").remove();
$(".chooseTalentsFilter").html("Talent");
$(".chooseLocationForShare").html("Location");
ts_city_filter = "";
ts_state_filter = "";
ts_country_filter = "";
ts_talent_filter = "";	
}
	
	
	
	
getAllTroupeSearch(0).then(function(response){
var container = "all";
ts_construct_troupes(container, 0,response);
});		
	
});
<div style='width: 100%; text-align: center;' class='atbc'>
	<br><br><br>
<p>ABOUT THE BASE</p>
Social Media for the creator.<br>
A platform to discover, share<br>and collaborate with other talents.<br> 
</div>



<br><br>
<script>

</script>

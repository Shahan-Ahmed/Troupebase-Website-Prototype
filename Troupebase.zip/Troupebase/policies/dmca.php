
<p style='font-weight:bold;'>TroupeBase Inc.<br>Digital Millennium Copyright Act Notice</p>


<p>The Digital Millennium Copyright Act of 1998 (the “DMCA”) provides recourse for copyright owners who believe that material appearing on the Internet infringes their rights under U.S. copyright law. If you believe in good faith that materials appearing on our website (collectively, the “Service”) infringe your copyright, you (or your agent) may send us a notice requesting that the material be removed, or access to it blocked. This notice must include:</p>



<li>A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.</li><br>

<li>Identification of the copyrighted work claimed to have been infringed, or, if multiple copyrighted works at a single online site are covered by a single notification, a representative list of such works at that site.</li><br>

<li>Identification of the material that is claimed to be infringing or to be the subject of infringing activity and that is to be removed or access to which is to be disabled, and information reasonably sufficient to permit the service provider to locate the material. We will need direct URLs to the content/image(s) being referenced. If URLs are not available, we will need screenshots.</li>

<li>Information reasonably sufficient to permit the service provider to contact the complaining party, such as an address, telephone number, and, if available, an electronic mail address at which the complaining party may be contacted.</li>

<li>A statement that the complaining party has a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law.</li>

<li>A statement that the information in the notification is accurate, and under penalty of perjury, that the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.</li>



<p>In addition, if you believe in good faith that a notice of copyright infringement has been wrongly filed against you, the DMCA permits you to send us counter-notice. Notices and counter-notices must meet statutory requirements imposed by the DMCA. You acknowledge that if you fail to comply with all of the notice requirements of the DMCA, your notice may not be valid. One place to find more information is the U.S. Copyright Office Web site, currently located at <a href='http://www.loc.gov/copyright'>http://www.loc.gov/copyright.</a></p>
<br>


<p>TROUPEBASE INC.<br>  
Attention: Admin.<br>
6405 Yellowstone Blvd., Suite 111<br>
Forest Hills, NY 11375<br>
E-mail: admin@troupebase.com
</p>


<p>Please note: If you materially misrepresent that online material, product, or activity is infringing your copyrights, you may be liable for damages (including court costs and attorneys’ fees) and could be subject to criminal prosecution for perjury. We suggest that you consult your legal advisor before filing a notice or counter-notice.</p>
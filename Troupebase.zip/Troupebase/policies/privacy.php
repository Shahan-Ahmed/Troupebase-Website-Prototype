<p>Effective: January-1-2020</p>

<p>
Our Privacy Policy describes the types of Personal Data and other information we collect from you when you visit and/or use our Site, TroupeBase.com, and explains what we do with that Personal Data and other information. "Personal Data" for purposes of this Privacy Policy is the information that identifies you as an individual or relates to an identifiable person.  If you do not agree to the terms and conditions of this Privacy Policy, including the use of your Personal Data in any manner described here, you may be prohibited from using much of our websites and services (the “Services”), including revocation of your account.  TroupeBase may update this Privacy Policy from time-to-time in our sole discretion.  In such case, TroupeBase will attempt to provide you with notice to the email address on file for your account, no less than 30 days prior to any such update.  It is your responsibility to check your email for updates, and to review the Privacy Policy for any changes.  You agree that each time that you use the Site and Services you are bound by any such changes. Use of the Site and Services by you following us emailing you or posting a new privacy policy on our Site constitutes your acceptance of the Privacy Policy as modified.
</p>



<p>TroupeBase is a general audience site, limited to users in the greater New York metropolitan area, and we are not targeted to, and do not knowingly collect Personal Data from users outside of the New York Metropolitan area, or minors under the age of 13.  We request that excluded individuals not provide Personal Data through TroupeBase.com.</p>


<p style='font-weight:bold;'>What information do we collect?</p>


	<li><span style='font-weight: bold;'>Registration information</span> - When you sign up for the Site, we ask for Personal Data, including your full name and email address. In some cases, we may also ask you to send us additional information, such as payment information for transactions, or to answer additional questions to help verify your information. </li>	
	<li><span style='font-weight: bold;'>Information obtained from third parties</span> - We may obtain information about you from third parties to verify the information you provide. We also may obtain information from third parties in connection with providing the Services to you.</li>
	<li><span style='font-weight: bold;'>Submission information</span> – When you submit information through the website (such as your “About Me”) we may store that information and also collect and store metadata about that information. We do not screen for Personal Data; to the extent you have included any such information in your submissions, it will be stored and disclosed in the course of our general use of such information.</li>
	<li><span style='font-weight: bold;'>Information about your use of the service</span> - We may collect information about your interaction with the service, your interactions with us and our advertising, and information regarding your computer device used to access to the service. </li>
	<li><span style='font-weight: bold;'>User-provided contact information</span> – TroupeBase may track and/or gather emails of visitors that contact and/or communicate with TroupeBase.</li>
	<li><span style='font-weight: bold;'>User communications</span> – Emails or other communication to us or other Site users.</li>
	<li><span style='font-weight: bold;'>Links</span> – We may present links in a format that enables us to keep track of whether these links have been followed.</li>
	<li><span style='font-weight: bold;'>Information from other sources</span> – We may also obtain information about you, including updated payment information from our third-party services providers and location information.</li>


<p style='font-weight:bold;'>What do we use your information for?</p>

<li><span style='font-weight: bold;'>Everyday business purposes</span> - We use your information to process your transactions, maintain your account and provide you the service.</li>	
<li><span style='font-weight: bold;'>To personalize your experience</span> - Your information helps us better respond to and tailor our Site and Services to your individual needs, including to serve user-specific advertisements based on your use of our Site or web history.</li>
<li><span style='font-weight: bold;'>To improve our Site</span> - We endeavor to continually update and improve our website and Services based on the information and feedback we receive from you.</li>
<li><span style='font-weight: bold;'>To keep you updated and administer promotions, surveys or other Site features</span> - the email address you provide for registration purposes may be used to send you information about this website, in addition to occasional news, updates, related product or service information (including, but not limited to sharing such non-specific information with third parties), etc. Users may opt in to receive promotional communications from TroupeBase or our third-party partners. Users may opt out of receiving emails from TroupeBase by clicking the corresponding "unsubscribe" link found in each and every communication sent from TroupeBase.</li>	
<li>We will not disclose or sell personally identifiable data to third parties, except as necessary to provide the services. If you do not want your data shared, you may write to us at admin@troupebase.com, although this may require us to disable some or all of the services offeredYou understand and agree that any decision you make to withhold any information from TroupeBase may prevent TroupeBase from being able to fulfill your request, your order and/or impair your ability to utilize all functionality of the Site.</li>	



<p style='font-weight:bold;'>How do we protect your information?</p>
<li>The security of your Personal Data is important to us. TroupeBase has implemented various security features to help prevent any unauthorized release of Personal Data. Our features include technical, administrative, and physical security measures to guard against unauthorized access, use and modification to systems where we store personal data.</li>	
<li>Payments are not handled through the Site. TroupeBase uses services such as Stripe, PayPal, Apple Pay and Google Wallet to collect payments. Users are able to select which payment service they want to use. As such, TroupeBase does not handle, collect, or retain any credit card numbers or other payment information.</li>	
<li>Be advised that while TroupeBase has endeavored to make a secure reliable Site for its users, the privacy and confidentiality of communications transmitted to/from TroupeBase via this Site or through email cannot be guaranteed. As such, TroupeBase cannot guarantee the security of any data transmitted via the Internet to/from our website, or the security of your Personal Data. </li>
<li>The security of your account and Personal Data also depends on keeping your account password confidential. You should not share your account name or password with anyone. If you do share your account information with a third party, they will have access to your account and your Personal Data.</li>


<p style='font-weight:bold;'>Accessing and Editing Your Personal Data</p>
<li>You have the ability to access and edit any Personal Data held on the site. You may do so by logging into your profile and changing any user information stored on file there. To the extent that such information is stored in our databases, we will respond to your changes as soon as reasonably possible. Please note that although you may delete this information from your profile, the information may remain stored indefinitely in our backup and archival records. While your Personal Data is protected as outlined above, we reserve the right to use, transfer, sell, and share aggregated, anonymous data about our users as a group for any business purpose, such as analyzing usage trends and seeking compatible advertisers and partners.</li>


<p style='font-weight:bold;'>Third party links</p>

<li>At our discretion, we will be including or offer third party products or services on our Site. These third-party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our Site and welcome any feedback about these sites.</li>

<li>Third party vendors, including Google, use cookies to serve ads based on a user's prior visits to your website or other websites.</li>

<li>Google's use of advertising cookies enables it and its partners to serve ads to your users based on their visit to your sites and/or other sites on the Internet.</li>

<li>Users may opt out of personalized advertising by visiting <a href='https://adssettings.google.com/authenticated'>Ads Settings</a></li>


<p style='font-weight:bold;'>Changes to this policy</p>

<li>Please note that this Privacy Policy may change from time to time. We will post any Policy changes on this page. Each version of this Policy will be identified at the top of the page by its effective date.<br><br>
If you have any questions about this Policy, please feel free to contact us through the Site or write to us at admin@troupebase.com.
</li>


<br><br>
<script>

</script>

<p style='font-weight: bold;'>TROUPEBASE TERMS OF USE<br>Date of Last Revision: <span style='text-decoration: underline;'>6/10/2020</span></p>

<p>Welcome to TroupeBase.  This website and related services are operated by TroupeBase Inc. d/b/a “TroupeBase.com” (hereafter, “us”, “we”, “our”, “TroupeBase”, or the “Company”). By registering, accessing or using our website at www.troupebase.com, any subdomain thereof, or any mobile version thereof, (together the “Site”), you (the “User”) signify that you have read, understand, and agree to be bound by these Terms of Use ("Terms of Use" or “Agreement"), whether or not you are a registered user of the Site.</p>



<p>We reserve the right, at our sole discretion, to change, modify, add, or delete portions of these Terms of Use at any time without further notice, provided that TroupeBase will post the changes to these Terms of Use on this page and will indicate at the top of this page the date these terms were last revised. Your continued use of the Site after any such changes constitutes your acceptance of the new Terms of Use. <span style='font-weight: bold;'>If you do not agree to abide by these or any future Terms of Use, then do not use or access (or continue to use or access) the Site.</span> It is your responsibility to regularly check the Site to determine if there have been changes to these Terms of Use and to review such changes.</p>




<p>PLEASE READ THESE TERMS OF USE CAREFULLY AS THEY CONTAIN IMPORTANT INFORMATION REGARDING YOUR LEGAL RIGHTS, REMEDIES AND OBLIGATIONS. THESE INCLUDE VARIOUS LIMITATIONS AND EXCLUSIONS AND A DISPUTE RESOLUTION CLAUSE THAT GOVERNS HOW DISPUTES WILL BE RESOLVED.</p>






<p>1. <span style='font-weight: bold;'>Eligibility and Registration.</span> As a visitor to the Site, you need not be a registered User of the Site. However, certain sections of this Site may require you to register with the Site, or otherwise may ask you to provide information to participate in certain features or access certain content. In addition to registration, to use the TroupeBase service, you must have Internet access, and a computer or other device that satisfies the hardware and other system requirements that we establish in order to use some or all service. If registration is requested, you agree to provide us with accurate and complete registration information. It shall be your responsibility to inform us of any changes to that information. You must be at least 13 years of age, to become a registered User of the TroupeBase service.  Each registration is for a single individual or business only, unless specifically designated otherwise on the registration page. You are responsible for maintaining the confidentiality of your information and password. You shall be responsible for all uses of your registration, whether or not authorized by you, the User. You agree to immediately notify us of any unauthorized use of your registration or password. When you register with the Site, you will be asked to provide us with certain personal information. In addition to these Terms of Use, in order to understand how we collect and use your information, please visit our Privacy Policy.</p>



<p><span style='font-weight: bold;'>2. Term.</span> This Agreement will remain in full force and effect while you use the Site and/or are a registered User. The Company may terminate your registration, delete your account and any content or information that you have provided on the Site and/or prohibit you from using or accessing the Site (or any portion, aspect or feature of the Site) if you violate this Agreement or are engaged in illegal or fraudulent use of our service, at any time in its sole discretion, with or without notice. You may terminate your registration at any time for any reason; however, the Company may retain Your Registration Data and User Content (as defined herein). Even after your membership is terminated, certain sections of this Agreement will remain in effect; see Section 12 below for a list of the provisions of this Agreement that will survive the termination of your membership.</p>



<p><span style='font-weight: bold;'>3. Registration Data; Account Security. </span> You agree to (a) provide accurate, current, and complete information about yourself during registration, ("Registration Data"); (b) maintain the security of your password and account information; and (d) be fully responsible for all use of your account and for any actions that take place using your account.  You acknowledge that TroupeBase will use the email address you provide with your Registration Data as the primary method for communication.</p>


<p><span style='font-weight: bold;'>4. Restrictions on Your Use of the Site.</span><br>
a. The User has a nonexclusive, nontransferable, limited, and revocable right to use the Site solely for User's personal use, and such other use for which the Site is intended.  The User will not use the Site for any other purpose, without the Company's express prior written consent.<br><br>
b. You represent that no materials of any kind submitted through Your account or otherwise posted, transmitted, or shared by You through the Services will violate or infringe upon the rights of any third party, including copyright, trademark, privacy, publicity, or other personal or proprietary rights; or contain libelous, defamatory or otherwise unlawful material; or violate any other third party website’s terms of use. You also agree to use the Site in a manner consistent with any and all applicable laws and regulations.<br><br>
c. You agree not to use the Site or to authorize any other person to use the Site to:<br>
i. cause the Site, or any portion thereof, to be framed in such a way that the Site, or any portion thereof, appears on the same screen with a portion of another website;<br>
ii. harvest or collect email addresses or other contact information of other users from the Site by electronic or other means for the purposes of sending unsolicited emails or other unsolicited communications;<br>
iii. use the Site in any unlawful manner or in any other manner that could damage, disable, overburden or impair the Site;<br>
iv. use automated scripts to collect information from or otherwise interact with the Site;<br>
v. upload, post, transmit, share, store or otherwise make available any content that the Company deems to be harmful, threatening, unlawful, defamatory, infringing, abusive, inflammatory, harassing, vulgar, obscene, fraudulent, invasive of privacy or publicity rights, hateful, or racially, ethnically or otherwise objectionable;<br>
vi. register for an account on behalf of an individual other than yourself, or register for an account on behalf of any group or entity other than one that you are an authorized representative of;<br>
vii. impersonate any person or entity, or falsely state or otherwise misrepresent yourself, your age or your affiliation with any person or entity;<br>
viii. upload, post, transmit, share or otherwise make available any unsolicited or unauthorized advertising, solicitations, promotional materials, "junk mail," "spam," "chain letters," "pyramid schemes," or any other form of solicitation;<br>
ix. upload, post, transmit, share, store or otherwise make publicly available on the Site any private information of any third party, including, addresses, phone numbers, email addresses, Social Security numbers and credit card numbers;<br>
x. solicit personal information from anyone under 18 or solicit passwords or personally identifying information for commercial or unlawful purposes;<br>
xi. upload, post, transmit, share or otherwise make available any material that contains software viruses or any other computer code, files or programs designed to interrupt, destroy or limit the functionality of any computer software or hardware or telecommunications equipment;<br>
xii. intimidate or harass another User;<br>
xiii. upload, post, transmit, share, store or otherwise make available content that would constitute, encourage or provide instructions for a criminal offense, violate the rights of any party, or that would otherwise create liability or violate any local, state, national or international law;<br>
xiv. use or attempt to use another's account, service or system without authorization from the Company, or create a false identity on the Site;<br>
OR
<br>
xv. upload, post, transmit, share, store or otherwise make available content that, in the sole judgment of the Company, is objectionable or which restricts or inhibits any other person from using or enjoying the Site, or which may expose the Company or its users to any harm or liability of any type.<br>
</p>


<p style='font-weight: bold;'>5. Proprietary Rights in Site Content; Limited License.</p>
<p>
a. Proprietary Rights. The User acknowledges and agrees that all content on the Site, including designs, text, graphics, pictures, photographs, video, information, applications, software, music, sound and other files, and their selection and arrangement (the "Site Content"), are the property of TroupeBase, its content providers, and/or their respective owners, and that the Company, its content providers, and/or the respective owners, retain all right, title, and interest in the Site Content. No Site Content may be modified, copied, distributed, framed, reproduced, republished, downloaded, displayed, posted, transmitted, or sold in any form or by any means, in whole or in part, without TroupeBase’s prior written permission.<br>
b. Limited License. Provided that the User is eligible to use the Site, the User is granted a limited license to access and use the Site and the Site Content and to download or print a copy of any portion of the Site Content to which you have properly gained access solely for your personal, non-commercial use, provided that you keep all copyright, trademark, service mark, or other proprietary notices intact. Except for User Content, you may not upload or republish Site Content on any Internet, Intranet or Extranet site or incorporate any Site Content in any other database or compilation, and any other use of the Site Content is strictly prohibited. The license granted by this Terms of Use does not permit the use of any data mining, robots or similar data gathering or extraction methods. Any use of the Site or the Site Content other than as specifically authorized herein, without the prior written permission of Company, is strictly prohibited and will terminate the license granted herein. Such unauthorized use may also violate applicable laws including copyright and trademark laws and applicable communications regulations and statutes. Unless explicitly stated herein, nothing in these Terms of Use shall be construed as conferring any license to intellectual property rights, whether by estoppel, implication, or otherwise.
</p>


<p style='font-weight: bold;'>6. User Content, Submissions, and Messages.</p>

<p>
a. Publications. TroupeBase allows users to connect and communicate with other users and businesses through direct messages, posts, and other means.  (“Messages”). Users are able to upload and/or link to content from Third Party Sites using Messages, as well as upload additional User Content.  “User Content” consists of any content posted or uploaded to your account, including, but not limited to, photographs, images, music, text, or video, and includes any content first posted on Third Party Sites, but linked or uploaded to TroupeBase, as well as content only posted in a User’s TroupeBase account.<br>
b. Social Media Interactions. When you interact with TroupeBase accounts on     social media websites (including, but not limited to, Twitter, Facebook, and/or Instagram), such interactions are subject to both the terms and conditions of the respective social media websites, as well as these terms and conditions.  From time to time TroupeBase may integrate User Content generated from your interactions with TroupeBase on the Site. Your submission of User Content to these Third Party Sites is additionally subject to the applicable terms and polices of any site to which you submit User Content and from which TroupeBase integrates such content.  Integration of such User Content on this Site does not imply approval or endorsement by us. Reference to any products, services, processes or other information, by trade name, trademark, manufacturer, supplier or otherwise does not constitute or imply endorsement, sponsorship or recommendation thereof, or any affiliation therewith, by the Company.<br>
c. Submissions. You acknowledge and agree that any questions, comments, suggestions, ideas, feedback or other information about the Site ("Submissions"), provided by you to the Company are non-confidential and shall become the sole property of the Company. The Company shall own exclusive rights (including all intellectual property rights) to, and shall be entitled to the unrestricted use and dissemination of, these Submissions for any purpose, commercial or otherwise, without acknowledgment or compensation to you.<br>
</p>



<p style='font-weight: bold;'>7. TroupeBase Fees, and Billing Methods</p>

<p>
a. Except as otherwise noted, creating a user account with TroupeBase is free. Once you have become a registered User you can elect buy any other product or content provided by us through the TroupeBase services (“Platform Content”). The fees to buy Platform Content are specified on the Platform and will be indicated to you before you confirm payment. Fees are subject to change from time to time without notice.  Once you have submitted your order for the purchase any Platform Content you will not be able to cancel your order.<br>
b. Payment processing for buying or renting Platform Content are handled by a third-party payment gateway providers. When buying Platform Content you will need to enter your credit card details into the payment system before you are able to view the Platform Content. All payments via this system are processed using SSL (Secure Socket Layer) protocol, where sensitive information is encrypted to protect your privacy.<br>
c. If you suspect there has been a fraudulent credit card transaction recorded in respect of the Platform you must contact the Company directly to resolve your complaint. The Company will co-operate with the third-party payment gateway to provide reasonable assistance in resolving any complaint. <br>
d. You are responsible for all applicable taxes, costs, hardware, software, services and all other costs and expenses related to your ability to access or use the Site and Services or your activity conducted through the Site. TroupeBase may, in its sole discretion, add, delete or change any of the Services provided, fees charged by TroupeBase or payment terms. TroupeBase’s standard fees and any changes will be posted or otherwise provided to User, and the applicable Services and fees will be binding on the effective date noted. No advance notice is required for any prospectively effective change in Services offered or fees charged therefore.<br>
</p>

<p style='font-weight: bold;'>8. No Liability for Content or Third Party Services</p>

<p>
a. TroupeBase does not guarantee the accuracy, integrity, quality or appropriateness of any Content transmitted to or through the Service. User acknowledges that TroupeBase simply acts as a passive conduit and an interactive computer service provider for the publication and distribution of Content. User understands that all Content posted on, transmitted through or linked through the Service are the sole responsibility of the person or company from whom such Content originated. User understands that TroupeBase does not control, and is not responsible for Content or Third Party Content made available through the Service, and that by using the Service, User may be exposed to Content that is inaccurate, misleading, or offensive. User agrees that User must evaluate and make User’s own judgment, and bear all risks associated with, the use of any Content and Third Party Content.
</p>




<p style='font-weight: bold;'>9. Intellectual Property.</p>

<p>
a. Trademarks. TroupeBase™ and other Company graphics, logos, designs, page headers, button icons, scripts and service names are registered and common law trademarks, service marks or trade dress of the Company in the U.S. and/or other countries. The Company's trademarks and trade dress may not be used, including as part of trademarks and/or as part of domain names, in connection with any product or service in any manner that is likely to cause confusion and may not be copied, imitated, or used, in whole or in part, without the prior written permission of the Company. You shall not purchase search engine or other pay per click keywords (such as Google AdWords), or domain names that use TroupeBase’s trademarks and/or variations and misspellings thereof.<br>
b. No Intellectual Property Infringement Permitted. You may not Post, distribute or reproduce in any way any copyrighted material, trademarks or service marks or other proprietary information owned by another party without obtaining the prior written consent of the copyright owner.
</p>




<p style='font-weight: bold;'>10. Third Party Websites and Content.</p>

<p>
a. The Site contains (or you may be sent through the Site to) links to other web sites ("Third Party Sites") as well as articles, photographs, text, graphics, pictures, designs, music, sound, video, information, applications, software and other content or items belonging to or originating from third parties (the "Third Party Applications, Software or Content"). Such Third Party Sites and Third Party Applications, Software or Content are not investigated, monitored or checked for accuracy, appropriateness, or completeness by us, and we are not responsible for any Third Party Sites accessed through the Site or any Third Party Applications, Software or Content posted on, available through or installed from the Site, including the content, accuracy, offensiveness, opinions, reliability, privacy practices or other policies of or contained in the Third Party Sites or the Third Party Applications, Software or Content. Inclusion of, linking to, or permitting the use or installation of any Third Party Site or any Third Party Applications, Software or Content does not imply approval or endorsement thereof by us. If you decide to leave the Site and access the Third Party Sites or to use or install any Third Party Applications, Software or Content, you do so at your own risk and you should be aware that our terms and policies no longer govern. You should review the applicable terms and policies, including privacy and data gathering practices, of any site to which you navigate from the Site or relating to any applications you use or install from the Site.
</p>


<p style='font-weight: bold;'>11. Disclaimers and Limitations on Liability.</p>


<p style='font-weight: bold;'>PLEASE READ THIS SECTION CAREFULLY SINCE IT LIMITS THE LIABILITY OF TROUPEBASE TO YOU. EACH OF THE SUBSECTIONS BELOW ONLY APPLIES UP TO THE MAXIMUM EXTENT PERMITTED UNDER APPLICABLE LAW. NOTHING HEREIN IS INTENDED TO LIMIT ANY RIGHTS YOU MAY HAVE WHICH MAY NOT BE LAWFULLY LIMITED. IF YOU ARE UNSURE ABOUT THIS OR ANY OTHER SECTION OF THESE TERMS, PLEASE CONSULT WITH A LEGAL PROFESSIONAL PRIOR TO ACCESSING OR USING THE SITE. BY ACCESSING OR USING THE SITE, YOU REPRESENT THAT YOU HAVE READ, UNDERSTOOD, AND AGREE TO THESE TERMS, INCLUDING THIS SECTION. YOU ARE GIVING UP SUBSTANTIAL LEGAL RIGHTS BY AGREEING TO THESE TERMS.</p>


<p>
A. THE SITE IS MADE AVAILABLE TO YOU ON AN "AS IS", "WITH ALL FAULTS" AND "AS AVAILABLE" BASIS, WITH THE EXPRESS UNDERSTANDING THAT TROUPEBASE MAY NOT MONITOR, CONTROL, OR VET USER CONTENT. AS SUCH, YOUR USE OF THE SITE IS AT YOUR OWN DISCRETION AND RISK. TROUPEBASE MAKES NO CLAIMS OR PROMISES ABOUT THE QUALITY, ACCURACY, OR RELIABILITY OF THE SITE, ITS SAFETY OR SECURITY, OR THE SITE CONTENT. ACCORDINGLY, TROUPEBASE IS NOT LIABLE TO YOU FOR ANY LOSS OR DAMAGE THAT MIGHT ARISE, FOR EXAMPLE, FROM THE SITE'S INOPERABILITY, UNAVAILABILITY OR SECURITY VULNERABILITIES OR FROM YOUR RELIANCE ON THE QUALITY, ACCURACY, OR RELIABILITY OF THE BUSINESS LISTINGS, RATINGS, REVIEWS (INCLUDING THEIR CONTENT, ORDER, AND DISPLAY), OR METRICS FOUND ON, USED ON, OR MADE AVAILABLE THROUGH THE SITE.<br><br>
B. TROUPEBASE MAKES NO CLAIMS OR PROMISES WITH RESPECT TO ANY THIRD PARTY, SUCH AS THE BUSINESSES OR ADVERTISERS LISTED ON THE SITE OR THE SITE'S USERS. ACCORDINGLY, TROUPEBASE IS NOT LIABLE TO YOU FOR ANY LOSS OR DAMAGE THAT MIGHT ARISE FROM ITS ACTIONS OR OMISSIONS, INCLUDING, FOR EXAMPLE, IF ANOTHER USER OR BUSINESS MISUSES YOUR CONTENT, IDENTITY OR PERSONAL INFORMATION, OR IF YOU HAVE A NEGATIVE EXPERIENCE WITH ONE OF THE BUSINESSES OR ADVERTISERS LISTED OR FEATURED ON THE SITE. YOUR PURCHASE AND USE OF PRODUCTS OR SERVICES OFFERED BY THIRD PARTIES THROUGH THE SITE IS AT YOUR OWN DISCRETION AND RISK.<br><br>
C. TROUPEBASE EXPRESSLY DISCLAIMS ALL WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING WARRANTIES AS TO THE PRODUCTS OR SERVICES OFFERED BY BUSINESSES LISTED ON THE SITE, AND IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT. NO ORAL OR WRITTEN INFORMATION OR ADVICE PROVIDED TO YOU BY A REPRESENTATIVE OF ONE OF TROUPEBASE SHALL CREATE A REPRESENTATION OR WARRANTY.<br><br>
D. YOUR SOLE AND EXCLUSIVE RIGHT AND REMEDY IN CASE OF DISSATISFACTION WITH THE SITE, RELATED SERVICES, OR ANY OTHER GRIEVANCE SHALL BE YOUR TERMINATION AND DISCONTINUATION OF ACCESS TO, OR USE OF THE SITE.<br><br>
E. IN NO EVENT WILL TROUPEBASE TOTAL LIABILITY TO YOU FOR ALL DAMAGES, LOSSES OR CAUSES OR ACTION EXCEED THE LESSER OF THE AMOUNT WE CHARGED YOU FOR THE TRANSACTION OR TEN UNITED STATES DOLLARS ($10.00).<br><br>
F. TROUPEBASE DISCLAIMS ALL LIABILITY FOR ANY (i) INDIRECT, SPECIAL, INCIDENTAL, PUNITIVE, EXEMPLARY, RELIANCE, OR CONSEQUENTIAL DAMAGES, (ii) LOSS OF PROFITS, (iii) BUSINESS INTERRUPTION, (iv) REPUTATIONAL HARM, OR (v) LOSS OF INFORMATION OR DATA.<br><br>
</p>





<p><span style='font-weight: bold;'>12. Indemnity.</span> You agree to indemnify and hold the Company, its subsidiaries and affiliates, and each of their directors, officers, agents, contractors, partners and employees, harmless from and against any loss, liability, claim, demand, damages, costs and expenses, including reasonable attorney's fees, arising out of or in connection with any User Content, any Third Party Applications, Software or Content you post or share on or through the Site, your use of the Site, your conduct in connection with the Site or with other users of the Site, or any violation of this Agreement or of any law or the rights of any third party.</p>



<p style='font-weight: bold;'>13. Miscellaneous.</p>

<p>
a. Governing Law; Venue and Jurisdiction. By visiting or using the Site, you agree that the laws of the State of New York, without regard to principles of conflict of laws, will govern these Terms of Use and any dispute of any sort that might arise between you and the Company or any of our affiliates. With respect to any disputes or claims not subject to arbitration (as set forth below), you agree not to commence or prosecute any action in connection therewith other than in the state and federal courts in Queens County, New York, and you hereby consent to, and waive all defenses of lack of personal jurisdiction and forum non conveniens with respect to venue and jurisdiction in the state and federal courts in New York, New York.<br>
b. <span style='text-decoration: underline'>Alternative Dispute Resolution.</span> You and the Company agree that all disputes, controversies or differences that may arise between the parties hereto, out of or in relation to or in connection with this Agreement ("Dispute(s)"), and that cannot be resolved between the parties, shall be submitted first to non-binding mediation.  If the Dispute is not resolved through such mediation, then the Dispute shall be submitted for binding arbitration in New York in accordance with the Consumer Procedures and Rules of the American Arbitration Association.  You understand and hereby agree that Disputes shall be arbitrated on an individual basis and that there shall be no right or authority for any Dispute to be arbitrated on a class action basis or in any other representative capacity on behalf of other persons similarly situated.  In addition, Disputes brought to arbitration pursuant to these Terms of Use may not be joined or consolidated in arbitration with Disputes brought by or against any third party, unless agreed to in writing by all parties.  No arbitration result is to be given preclusive or precedential effect as to issues or claims in any Dispute with anyone who is not a party to the arbitration.<br>
c. Privacy. Please review our Privacy Policy, which also governs your visit to the Site, to understand our practices.<br>
d. No Agency. There is no agency, partnership, joint venture, employee-employer or franchisor-franchisee relationship between you and us or between us and any other Member or user of the Website.<br>
e. Survival. Although this Agreement may be terminated by you or us at any time and for any reason, the terms of the following sections of this Agreement will survive any such termination and you and we will continue to be bound by such terms indefinitely: (Term), (Proprietary Rights in Site Content), (Member Disputes), (Disclaimers and Limitation on Liability), (Indemnity), and this (Miscellaneous).<br>
f. Entire Agreement. These Terms of Use constitute the entire agreement between you and Company regarding the use of the Site, superseding any prior agreements between you and the Company relating to your use of the Site.<br>
g. Other. The failure of the Company to exercise or enforce any right or provision of these Terms of Use shall not constitute a waiver of such right or provision in that or any other instance. If any provision of these Terms of Use shall be held invalid or deemed unlawful, void or for any reason unenforceable, then that provision shall be deemed severable from these Terms of Use and shall not affect the validity and enforceability of any remaining provisions.
</p>



<br><br>


